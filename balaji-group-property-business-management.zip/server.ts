import express from 'express';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;

app.use(express.json());

// API route for SMS dispatch (avoids browser CORS issues when connecting to Fast2SMS, Twilio, MSG91)
app.post('/api/sms/send', async (req, res) => {
  try {
    const { mobile, otp, config } = req.body;
    const cleanMobile = String(mobile || '').replace(/\D/g, '').slice(-10);

    if (cleanMobile.length !== 10) {
      return res.status(400).json({
        success: false,
        message: 'Invalid 10-digit mobile number',
      });
    }

    const provider = config?.provider || 'fast2sms';
    const apiKey = config?.apiKey?.trim() || process.env.SMS_API_KEY || '';

    // 1. Fast2SMS (India Quick OTP Route)
    if (provider === 'fast2sms' && apiKey) {
      try {
        const url = `https://www.fast2sms.com/dev/bulkV2?authorization=${encodeURIComponent(
          apiKey
        )}&route=otp&variables_values=${encodeURIComponent(otp)}&numbers=${cleanMobile}`;

        let apiRes = await fetch(url, {
          method: 'GET',
          headers: { 'cache-control': 'no-cache' },
        });
        let data = await apiRes.json().catch(() => null);

        // If GET method didn't return true, try POST fallback
        if (!data || data.return !== true) {
          try {
            const postRes = await fetch('https://www.fast2sms.com/dev/bulkV2', {
              method: 'POST',
              headers: {
                authorization: apiKey,
                'Content-Type': 'application/json',
              },
              body: JSON.stringify({
                route: 'otp',
                variables_values: otp,
                numbers: cleanMobile,
              }),
            });
            const postData = await postRes.json().catch(() => null);
            if (postData && postData.return === true) {
              data = postData;
            }
          } catch {
            // keep original data
          }
        }

        if (data && data.return === true) {
          return res.json({
            success: true,
            isRealSms: true,
            provider: 'Fast2SMS',
            message: `Real-time SMS delivered to +91 ${cleanMobile} via Fast2SMS telecom gateway.`,
            details: data,
          });
        } else {
          const errText = Array.isArray(data?.message)
            ? data.message.join(', ')
            : (data?.message || 'Gateway response received.');
          return res.json({
            success: true,
            isRealSms: false,
            provider: 'Fast2SMS',
            message: `Fast2SMS notice: ${errText}`,
            details: data,
          });
        }
      } catch (err: any) {
        return res.json({
          success: true,
          isRealSms: false,
          provider: 'Fast2SMS',
          message: `Fast2SMS dispatch notice: ${err?.message}`,
        });
      }
    }

    // 2. 2Factor.in (India Direct OTP Route)
    if (provider === '2factor' && apiKey) {
      try {
        const url = `https://2factor.in/API/V1/${encodeURIComponent(apiKey)}/SMS/${cleanMobile}/${encodeURIComponent(otp)}`;
        const apiRes = await fetch(url, { method: 'GET' });
        const data = await apiRes.json().catch(() => null);

        if (data && data.Status === 'Success') {
          return res.json({
            success: true,
            isRealSms: true,
            provider: '2Factor.in',
            message: `Real-time SMS delivered to +91 ${cleanMobile} via 2Factor telecom gateway.`,
            details: data,
          });
        } else {
          return res.json({
            success: true,
            isRealSms: false,
            provider: '2Factor.in',
            message: data?.Details || '2Factor gateway response received.',
            details: data,
          });
        }
      } catch (err: any) {
        return res.json({
          success: true,
          isRealSms: false,
          provider: '2Factor.in',
          message: `2Factor dispatch notice: ${err?.message}`,
        });
      }
    }

    // 3. Textlocal (India Telecom Route)
    if (provider === 'textlocal' && apiKey) {
      try {
        const message = encodeURIComponent(`Your Balaji Group verification code is: ${otp}. Valid for 10 minutes.`);
        const sender = encodeURIComponent(config?.senderId?.trim() || 'TXTLCL');
        const url = `https://api.textlocal.in/send/?apiKey=${encodeURIComponent(apiKey)}&numbers=91${cleanMobile}&message=${message}&sender=${sender}`;
        const apiRes = await fetch(url, { method: 'POST' });
        const data = await apiRes.json().catch(() => null);

        if (data && data.status === 'success') {
          return res.json({
            success: true,
            isRealSms: true,
            provider: 'Textlocal',
            message: `Real-time SMS delivered to +91 ${cleanMobile} via Textlocal gateway.`,
            details: data,
          });
        } else {
          const errText = data?.errors?.[0]?.message || 'Textlocal gateway response received.';
          return res.json({
            success: true,
            isRealSms: false,
            provider: 'Textlocal',
            message: `Textlocal notice: ${errText}`,
            details: data,
          });
        }
      } catch (err: any) {
        return res.json({
          success: true,
          isRealSms: false,
          provider: 'Textlocal',
          message: `Textlocal dispatch notice: ${err?.message}`,
        });
      }
    }

    // 4. Twilio (Global SMS)
    if (
      provider === 'twilio' &&
      config?.twilioAccountSid?.trim() &&
      config?.twilioAuthToken?.trim() &&
      config?.twilioPhoneNumber?.trim()
    ) {
      try {
        const accountSid = config.twilioAccountSid.trim();
        const authToken = config.twilioAuthToken.trim();
        const fromNumber = config.twilioPhoneNumber.trim();
        const toNumber = `+91${cleanMobile}`;

        const auth = Buffer.from(`${accountSid}:${authToken}`).toString('base64');
        const params = new URLSearchParams();
        params.append('To', toNumber);
        params.append('From', fromNumber);
        params.append('Body', `Your Balaji Group verification code is: ${otp}. Valid for 10 minutes.`);

        const twilioRes = await fetch(
          `https://api.twilio.com/2010-04-01/Accounts/${accountSid}/Messages.json`,
          {
            method: 'POST',
            headers: {
              Authorization: `Basic ${auth}`,
              'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: params.toString(),
          }
        );
        const twilioData = await twilioRes.json().catch(() => null);

        if (twilioRes.ok) {
          return res.json({
            success: true,
            isRealSms: true,
            provider: 'Twilio',
            message: `SMS dispatched via Twilio to +91 ${cleanMobile}.`,
            details: twilioData,
          });
        } else {
          return res.json({
            success: false,
            isRealSms: false,
            provider: 'Twilio',
            message: twilioData?.message || 'Twilio delivery failed.',
            details: twilioData,
          });
        }
      } catch (err: any) {
        return res.status(500).json({ success: false, message: err?.message });
      }
    }

    // 3. MSG91
    if (provider === 'msg91' && apiKey) {
      try {
        const templateId = config?.templateId?.trim() || '';
        const url = `https://api.msg91.com/api/v5/otp?template_id=${encodeURIComponent(
          templateId
        )}&mobile=91${cleanMobile}&authkey=${encodeURIComponent(apiKey)}&otp=${encodeURIComponent(otp)}`;

        const apiRes = await fetch(url, { method: 'POST' });
        const data = await apiRes.json().catch(() => null);

        return res.json({
          success: true,
          isRealSms: true,
          provider: 'MSG91',
          message: `SMS sent via MSG91 to +91 ${cleanMobile}.`,
          details: data,
        });
      } catch (err: any) {
        return res.json({
          success: true,
          isRealSms: false,
          provider: 'MSG91',
          message: `MSG91 notice: ${err?.message}`,
        });
      }
    }

    // 4. Meta WhatsApp Cloud API (Official WhatsApp OTP for thousands of users)
    if (
      provider === 'whatsapp_cloud_api' &&
      config?.whatsappPhoneNumberId?.trim() &&
      config?.whatsappAccessToken?.trim()
    ) {
      try {
        const phoneId = config.whatsappPhoneNumberId.trim();
        const token = config.whatsappAccessToken.trim();
        const templateName = config.whatsappTemplateName?.trim();
        const url = `https://graph.facebook.com/v25.0/${phoneId}/messages`;

        // Check if template is a simple test template (no variables expected by Meta)
        const isParamlessTestTemplate =
          templateName === 'hello_world' ||
          templateName === '3p_direct_integration_test_template';

        let payload: any;
        if (templateName) {
          payload = {
            messaging_product: 'whatsapp',
            recipient_type: 'individual',
            to: `91${cleanMobile}`,
            type: 'template',
            template: {
              name: templateName,
              language: { code: 'en_US' },
              ...(isParamlessTestTemplate
                ? {}
                : {
                    components: [
                      {
                        type: 'body',
                        parameters: [{ type: 'text', text: otp }],
                      },
                      {
                        type: 'button',
                        sub_type: 'url',
                        index: '0',
                        parameters: [{ type: 'text', text: otp }],
                      },
                    ],
                  }),
            },
          };
        } else {
          payload = {
            messaging_product: 'whatsapp',
            recipient_type: 'individual',
            to: `91${cleanMobile}`,
            type: 'text',
            text: {
              preview_url: false,
              body: `Your Balaji Group verification OTP code is: *${otp}*\n\nValid for 10 minutes. Do not share this OTP with anyone.`,
            },
          };
        }

        const waRes = await fetch(url, {
          method: 'POST',
          headers: {
            Authorization: `Bearer ${token}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify(payload),
        });

        let waData = await waRes.json().catch(() => null);

        // If template dispatch had an error and template was specified, attempt direct text message fallback
        if ((!waRes.ok || !waData?.messages?.[0]?.id) && templateName) {
          const textPayload = {
            messaging_product: 'whatsapp',
            recipient_type: 'individual',
            to: `91${cleanMobile}`,
            type: 'text',
            text: {
              preview_url: false,
              body: `Your Balaji Group verification OTP code is: *${otp}*\n\nValid for 10 minutes. Do not share this OTP with anyone.`,
            },
          };

          const fallbackRes = await fetch(url, {
            method: 'POST',
            headers: {
              Authorization: `Bearer ${token}`,
              'Content-Type': 'application/json',
            },
            body: JSON.stringify(textPayload),
          });

          const fallbackData = await fallbackRes.json().catch(() => null);
          if (fallbackRes.ok && fallbackData?.messages?.[0]?.id) {
            return res.json({
              success: true,
              isRealSms: true,
              provider: 'WhatsApp Cloud API',
              message: `Official WhatsApp verification code sent to +91 ${cleanMobile}!`,
              details: fallbackData,
            });
          }
        }

        if (waRes.ok && waData?.messages?.[0]?.id) {
          return res.json({
            success: true,
            isRealSms: true,
            provider: 'WhatsApp Cloud API',
            message: `Official WhatsApp verification code sent to +91 ${cleanMobile}!`,
            details: waData,
          });
        } else {
          const errDetail = waData?.error?.message || 'Meta WhatsApp API returned a notice.';
          return res.json({
            success: true,
            isRealSms: false,
            provider: 'WhatsApp Cloud API',
            message: `WhatsApp API response: ${errDetail}`,
            details: waData,
          });
        }
      } catch (err: any) {
        return res.json({
          success: true,
          isRealSms: false,
          provider: 'WhatsApp Cloud API',
          message: `WhatsApp dispatch notice: ${err?.message}`,
        });
      }
    }

    // 5. Custom Webhook / Android SMS Gateway (Free SMS via own Android phone SIM or custom API)
    if (provider === 'custom_webhook' && config?.webhookUrl?.trim()) {
      try {
        const webhookUrl = config.webhookUrl.trim();
        const smsMessage = `Your Balaji Group verification OTP is: ${otp}. Valid for 10 minutes.`;
        const headers: Record<string, string> = {
          'Content-Type': 'application/json',
        };
        if (apiKey) {
          headers['Authorization'] = apiKey.startsWith('Bearer ') ? apiKey : `Bearer ${apiKey}`;
          headers['x-api-key'] = apiKey;
        }

        const webhookRes = await fetch(webhookUrl, {
          method: 'POST',
          headers,
          body: JSON.stringify({
            to: `+91${cleanMobile}`,
            phone: `+91${cleanMobile}`,
            mobile: cleanMobile,
            phoneNumber: `+91${cleanMobile}`,
            message: smsMessage,
            text: smsMessage,
            otp,
            timestamp: new Date().toISOString(),
          }),
        });

        const webhookData = await webhookRes.json().catch(() => null);

        if (webhookRes.ok) {
          return res.json({
            success: true,
            isRealSms: true,
            provider: 'Android Gateway / Webhook',
            message: `Real SMS dispatched to +91 ${cleanMobile} via your SMS Gateway.`,
            details: webhookData,
          });
        } else {
          return res.json({
            success: true,
            isRealSms: false,
            provider: 'SMS Gateway',
            message: `Gateway responded with status ${webhookRes.status}. Check webhook endpoint.`,
            details: webhookData,
          });
        }
      } catch (err: any) {
        return res.json({
          success: true,
          isRealSms: false,
          provider: 'SMS Webhook',
          message: `Webhook connection note: ${err?.message}`,
        });
      }
    }

    // 5. Default / Standard active production delivery
    return res.json({
      success: true,
      isRealSms: false,
      provider: 'Balaji Instant Delivery',
      message: `Real-time OTP generated for +91 ${cleanMobile}. To deliver via telecom cellular towers directly to phone SMS inboxes, enter your free Fast2SMS API key in Admin Settings, or use WhatsApp / On-Screen delivery.`,
      needsGatewayKey: true,
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, message: err?.message });
  }
});

async function startServer() {
  const isProd = process.env.NODE_ENV === 'production';
  if (!isProd) {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer();
