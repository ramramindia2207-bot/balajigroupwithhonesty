import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Users,
  Home,
  CreditCard,
  Clock,
  PlusCircle,
  KeyRound,
  Tag,
  ArrowUpRight,
  TrendingUp,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  QrCode,
  FileText,
} from 'lucide-react';
import { PaymentRecord } from '../../types';
import { ReceiptModal } from '../common/ReceiptModal';

interface AdminDashboardProps {
  onNavigateTab: (tab: string) => void;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({ onNavigateTab }) => {
  const {
    customers,
    properties,
    payments,
    coupons,
    supportTickets,
    approvePayment,
    rejectPayment,
  } = useApp();

  const [selectedReceipt, setSelectedReceipt] = useState<PaymentRecord | null>(null);

  // Financial aggregates
  const totalCustomersCount = customers.length;
  const totalPropertiesCount = properties.length;
  const approvedPayments = payments.filter((p) => p.status === 'Approved');
  const totalAmountCollected = approvedPayments.reduce((acc, p) => acc + p.amount, 0);

  const pendingPayments = payments.filter((p) => p.status === 'Pending Verification');
  const pendingKistsCount = customers.reduce((acc, c) => acc + Math.max(0, (c.totalKists || 24) - (c.paidKists || 0)), 0);
  const overdueCustomers = customers.filter((c) => c.status === 'Due');
  const openTickets = supportTickets.filter((t) => t.status !== 'Resolved');

  return (
    <div className="space-y-6">
      {/* Top Banner Alert if Pending Verifications exist */}
      {pendingPayments.length > 0 && (
        <div className="bg-amber-50 border border-amber-200 rounded-2xl p-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-100 text-amber-800 flex items-center justify-center shrink-0">
              <QrCode className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-xs font-bold text-amber-900">
                {pendingPayments.length} Payment Verification Request{pendingPayments.length > 1 ? 's' : ''} Pending
              </h4>
              <p className="text-xs text-amber-700">
                Customers have submitted UPI QR payment proofs awaiting your review.
              </p>
            </div>
          </div>
          <button
            onClick={() => onNavigateTab('payments')}
            className="px-4 py-2 bg-amber-600 hover:bg-amber-700 text-white rounded-xl text-xs font-bold transition-colors cursor-pointer shrink-0"
          >
            Review Queue
          </button>
        </div>
      )}

      {/* KPI Stats Grid (Matching Wireframe Center "Admin Portal") */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Total Customers */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs hover:border-orange-300 transition-colors">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
              Total Customers
            </span>
            <div className="w-10 h-10 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center">
              <Users className="w-5 h-5" />
            </div>
          </div>
          <div className="flex items-baseline justify-between">
            <span className="text-3xl font-extrabold text-slate-900 font-mono tabular-nums">
              {totalCustomersCount}
            </span>
            <span className="text-xs font-semibold text-emerald-600 flex items-center">
              <TrendingUp className="w-3.5 h-3.5 mr-0.5" />
              <span>+12% mo</span>
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            {customers.filter((c) => c.status === 'Active').length} Active · {overdueCustomers.length} Due
          </p>
        </div>

        {/* Total Properties */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs hover:border-orange-300 transition-colors">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
              Total Properties
            </span>
            <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center">
              <Home className="w-5 h-5" />
            </div>
          </div>
          <div className="flex items-baseline justify-between">
            <span className="text-3xl font-extrabold text-slate-900 font-mono tabular-nums">
              {totalPropertiesCount}
            </span>
            <span className="text-xs font-semibold text-emerald-600">
              {properties.filter((p) => p.status === 'Sold').length} Allotted
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            {properties.filter((p) => p.status === 'Available').length} Available Plots
          </p>
        </div>

        {/* Total Payments Collected */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs hover:border-orange-300 transition-colors">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
              Total Collected
            </span>
            <div className="w-10 h-10 rounded-xl bg-orange-50 text-orange-600 flex items-center justify-center">
              <CreditCard className="w-5 h-5" />
            </div>
          </div>
          <div className="flex items-baseline justify-between">
            <div className="flex items-baseline gap-1">
              <span className="text-xl font-bold text-orange-600">₹</span>
              <span className="text-2xl font-extrabold text-slate-900 font-mono tabular-nums truncate max-w-[150px]">
                {totalAmountCollected.toLocaleString('en-IN')}
              </span>
            </div>
            <span className="text-[10px] font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded">
              Verified
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            {approvedPayments.length} successful transactions
          </p>
        </div>

        {/* Pending Kists / Action Items */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs hover:border-orange-300 transition-colors">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
              Pending Kists
            </span>
            <div className="w-10 h-10 rounded-xl bg-rose-50 text-rose-600 flex items-center justify-center">
              <Clock className="w-5 h-5" />
            </div>
          </div>
          <div className="flex items-baseline justify-between">
            <span className="text-3xl font-extrabold text-slate-900 font-mono tabular-nums">
              {pendingKistsCount}
            </span>
            <span className="text-xs font-semibold text-rose-600">
              {overdueCustomers.length} Overdue
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            {openTickets.length} Open Support Tickets
          </p>
        </div>
      </div>

      {/* Quick Actions (Matching Wireframe Center) */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs">
        <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-3">
          Quick Administrative Actions
        </h4>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          <button
            onClick={() => onNavigateTab('customers')}
            className="p-3.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-2 cursor-pointer shadow-xs"
          >
            <PlusCircle className="w-4 h-4" />
            <span>Add New Customer</span>
          </button>

          <button
            onClick={() => onNavigateTab('properties')}
            className="p-3.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-2 cursor-pointer shadow-xs"
          >
            <Home className="w-4 h-4" />
            <span>Add Property</span>
          </button>

          <button
            onClick={() => onNavigateTab('assign_property')}
            className="p-3.5 bg-orange-600 hover:bg-orange-700 text-white rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-2 cursor-pointer shadow-xs"
          >
            <KeyRound className="w-4 h-4" />
            <span>Assign Property</span>
          </button>

          <button
            onClick={() => onNavigateTab('coupons')}
            className="p-3.5 bg-purple-600 hover:bg-purple-700 text-white rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-2 cursor-pointer shadow-xs"
          >
            <Tag className="w-4 h-4" />
            <span>Manage Coupons</span>
          </button>
        </div>
      </div>

      {/* 2-Column Split: Recent Customers & Recent Payments (Matching Wireframe Center) */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Recent Customers Table */}
        <div className="bg-white rounded-2xl border border-slate-200 shadow-2xs overflow-hidden flex flex-col">
          <div className="p-4 border-b border-slate-100 flex items-center justify-between">
            <h4 className="font-bold text-sm text-slate-900">Recent Customers</h4>
            <button
              onClick={() => onNavigateTab('customers')}
              className="text-xs font-bold text-orange-600 hover:underline cursor-pointer"
            >
              View All ({customers.length})
            </button>
          </div>

          <div className="overflow-x-auto flex-1">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 text-slate-500 font-semibold border-b border-slate-100">
                <tr>
                  <th className="py-2.5 px-4">Name</th>
                  <th className="py-2.5 px-3">Mobile</th>
                  <th className="py-2.5 px-3">Plot No.</th>
                  <th className="py-2.5 px-3">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {customers.slice(0, 5).map((c) => (
                  <tr key={c.id} className="hover:bg-slate-50/70 transition-colors">
                    <td className="py-3 px-4 font-semibold text-slate-900">
                      <div>
                        <span>{c.name}</span>
                        <span className="block text-[10px] text-slate-400 font-mono">
                          {c.id}
                        </span>
                      </div>
                    </td>
                    <td className="py-3 px-3 text-slate-600 font-mono">+91 {c.mobile}</td>
                    <td className="py-3 px-3 font-mono font-bold text-slate-800">
                      {c.propertyId === 'prop-1' ? '12A' : c.propertyId === 'prop-2' ? '15B' : c.propertyId === 'prop-3' ? '22C' : c.propertyId === 'prop-4' ? '28A' : c.propertyId === 'prop-5' ? '31D' : 'Unassigned'}
                    </td>
                    <td className="py-3 px-3">
                      <span
                        className={`px-2 py-0.5 rounded-full text-[10px] font-bold uppercase ${
                          c.status === 'Active'
                            ? 'bg-emerald-100 text-emerald-800'
                            : c.status === 'Due'
                            ? 'bg-rose-100 text-rose-800'
                            : 'bg-amber-100 text-amber-800'
                        }`}
                      >
                        {c.status}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Recent Payments Table */}
        <div className="bg-white rounded-2xl border border-slate-200 shadow-2xs overflow-hidden flex flex-col">
          <div className="p-4 border-b border-slate-100 flex items-center justify-between">
            <h4 className="font-bold text-sm text-slate-900">Recent Payments</h4>
            <button
              onClick={() => onNavigateTab('payments')}
              className="text-xs font-bold text-orange-600 hover:underline cursor-pointer"
            >
              View All ({payments.length})
            </button>
          </div>

          <div className="overflow-x-auto flex-1">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 text-slate-500 font-semibold border-b border-slate-100">
                <tr>
                  <th className="py-2.5 px-4">Customer</th>
                  <th className="py-2.5 px-3">Amount</th>
                  <th className="py-2.5 px-3">Date</th>
                  <th className="py-2.5 px-3">Status</th>
                  <th className="py-2.5 px-3 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {payments.slice(0, 5).map((p) => {
                  const isPending = p.status === 'Pending Verification';
                  const isApproved = p.status === 'Approved';

                  return (
                    <tr key={p.id} className="hover:bg-slate-50/70 transition-colors">
                      <td className="py-3 px-4 font-semibold text-slate-900">
                        <div>
                          <span>{p.customerName}</span>
                          <span className="block text-[10px] text-slate-400 font-mono">
                            Plot {p.plotNumber} · {p.paymentMethod}
                          </span>
                        </div>
                      </td>
                      <td className="py-3 px-3 font-mono font-bold text-slate-900">
                        ₹{p.amount.toLocaleString('en-IN')}
                      </td>
                      <td className="py-3 px-3 text-slate-500 text-[11px] whitespace-nowrap">
                        {p.paymentDate}
                      </td>
                      <td className="py-3 px-3">
                        <span
                          className={`px-2 py-0.5 rounded-full text-[10px] font-bold uppercase ${
                            isApproved
                              ? 'bg-emerald-100 text-emerald-800'
                              : isPending
                              ? 'bg-amber-100 text-amber-800'
                              : 'bg-rose-100 text-rose-800'
                          }`}
                        >
                          {p.status}
                        </span>
                      </td>
                      <td className="py-3 px-3 text-right">
                        {isPending ? (
                          <div className="flex items-center justify-end gap-1">
                            <button
                              onClick={() => approvePayment(p.id)}
                              className="p-1 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 rounded-md transition-colors cursor-pointer"
                              title="Approve Payment"
                            >
                              <CheckCircle2 className="w-4 h-4" />
                            </button>
                            <button
                              onClick={() => {
                                const reason = prompt('Rejection reason (sent to customer):', 'UTR could not be reconciled');
                                if (reason) rejectPayment(p.id, reason);
                              }}
                              className="p-1 bg-rose-50 hover:bg-rose-100 text-rose-700 rounded-md transition-colors cursor-pointer"
                              title="Reject Payment"
                            >
                              <XCircle className="w-4 h-4" />
                            </button>
                          </div>
                        ) : isApproved ? (
                          <button
                            onClick={() => setSelectedReceipt(p)}
                            className="p-1 text-slate-500 hover:text-orange-600 rounded-md transition-colors cursor-pointer"
                            title="View Receipt"
                          >
                            <FileText className="w-4 h-4" />
                          </button>
                        ) : (
                          <span className="text-slate-400 text-[11px]">—</span>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* Selected Receipt Modal */}
      {selectedReceipt && (
        <ReceiptModal
          payment={selectedReceipt}
          onClose={() => setSelectedReceipt(null)}
        />
      )}
    </div>
  );
};
