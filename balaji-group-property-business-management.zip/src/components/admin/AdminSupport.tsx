import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { Ticket, Search, MessageSquare, Send, CheckCircle2, Clock, X, User } from 'lucide-react';
import { SupportTicket } from '../../types';

export const AdminSupport: React.FC = () => {
  const { supportTickets, replyToSupportTicket } = useApp();
  const [selectedTicket, setSelectedTicket] = useState<SupportTicket | null>(null);
  const [replyText, setReplyText] = useState('');
  const [ticketStatus, setTicketStatus] = useState<any>('Resolved');

  const handleReply = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedTicket || !replyText.trim()) return;

    replyToSupportTicket(selectedTicket.id, replyText.trim(), ticketStatus);
    setSelectedTicket(null);
    setReplyText('');
    alert('Administrative response sent to customer!');
  };

  return (
    <div className="space-y-5">
      <div>
        <h3 className="font-bold text-base text-slate-900">Customer Support Desk</h3>
        <p className="text-xs text-slate-500">
          Review customer inquiries regarding plot visits, installment clarifications, and registry documents.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Ticket List Column */}
        <div className="lg:col-span-2 space-y-3">
          {supportTickets.map((tkt) => {
            const isResolved = tkt.status === 'Resolved';
            const isPending = tkt.status === 'Pending';

            return (
              <div
                key={tkt.id}
                onClick={() => setSelectedTicket(tkt)}
                className={`p-4 rounded-2xl border transition-all cursor-pointer bg-white shadow-2xs ${
                  selectedTicket?.id === tkt.id
                    ? 'border-orange-500 ring-2 ring-orange-500/20'
                    : 'border-slate-200 hover:border-orange-200'
                }`}
              >
                <div className="flex items-start justify-between gap-3 mb-2">
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <span className="font-mono font-bold text-xs text-orange-600">
                        {tkt.ticketNumber}
                      </span>
                      <span className="bg-slate-100 text-slate-700 px-2 py-0.5 rounded text-[10px] font-semibold">
                        {tkt.category}
                      </span>
                      <span
                        className={`px-2 py-0.5 rounded-full text-[10px] font-bold uppercase ${
                          isResolved
                            ? 'bg-emerald-100 text-emerald-800'
                            : isPending
                            ? 'bg-amber-100 text-amber-800'
                            : 'bg-blue-100 text-blue-800'
                        }`}
                      >
                        {tkt.status}
                      </span>
                    </div>
                    <h4 className="font-bold text-sm text-slate-900">{tkt.subject}</h4>
                  </div>
                  <span className="text-[10px] text-slate-400 whitespace-nowrap">
                    {tkt.createdAt}
                  </span>
                </div>

                <p className="text-xs text-slate-600 line-clamp-2 leading-relaxed mb-3">
                  {tkt.message}
                </p>

                <div className="flex items-center justify-between text-xs text-slate-500 pt-2 border-t border-slate-100">
                  <span className="font-medium text-slate-800">
                    {tkt.customerName} (+91 {tkt.customerMobile})
                  </span>
                  <span className="text-orange-600 font-semibold text-[11px]">
                    {tkt.adminReply ? '✓ Replied' : 'Reply Now →'}
                  </span>
                </div>
              </div>
            );
          })}
        </div>

        {/* Reply Action Card */}
        <div className="bg-white rounded-3xl p-5 border border-slate-200 shadow-sm h-fit">
          {selectedTicket ? (
            <form onSubmit={handleReply} className="space-y-4 text-xs">
              <div className="flex items-center justify-between pb-3 border-b border-slate-100">
                <span className="font-mono font-bold text-orange-600">
                  {selectedTicket.ticketNumber}
                </span>
                <span className="text-slate-500">{selectedTicket.category}</span>
              </div>

              <div className="p-3 bg-slate-50 rounded-xl space-y-1">
                <span className="font-bold text-slate-900 block">
                  {selectedTicket.customerName}
                </span>
                <p className="text-slate-600 leading-relaxed italic">
                  "{selectedTicket.message}"
                </p>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Update Ticket Status
                </label>
                <select
                  value={ticketStatus}
                  onChange={(e) => setTicketStatus(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl"
                >
                  <option value="Resolved">Resolved / Closed</option>
                  <option value="Pending">In Progress / Pending Followup</option>
                  <option value="Open">Keep Open</option>
                </select>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Official Response Message *
                </label>
                <textarea
                  rows={4}
                  required
                  placeholder="Type official response to customer..."
                  value={replyText}
                  onChange={(e) => setReplyText(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl resize-none"
                />
              </div>

              <button
                type="submit"
                className="w-full py-2.5 bg-orange-600 hover:bg-orange-700 text-white font-bold rounded-xl text-xs flex items-center justify-center gap-1.5 cursor-pointer shadow-sm"
              >
                <Send className="w-3.5 h-3.5" />
                <span>Send Response to Customer</span>
              </button>
            </form>
          ) : (
            <div className="text-center py-12 text-slate-400">
              <MessageSquare className="w-10 h-10 mx-auto mb-2 opacity-30" />
              <p className="text-xs">Select a support ticket from the list to view and reply.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
