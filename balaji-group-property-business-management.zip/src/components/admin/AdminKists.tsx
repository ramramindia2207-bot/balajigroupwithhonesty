import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Clock,
  Send,
  Calendar,
  CheckCircle2,
  AlertTriangle,
  Users,
  Edit,
  X,
  ArrowRight,
  TrendingDown,
  ShieldAlert,
} from 'lucide-react';
import { Customer } from '../../types';

export const AdminKists: React.FC = () => {
  const { customers, properties, updateCustomerKistSchedule } = useApp();

  const [remindedCustomerId, setRemindedCustomerId] = useState<string | null>(null);
  const [editingCustomer, setEditingCustomer] = useState<Customer | null>(null);

  // Edit Kist Schedule Form State
  const [kistStatusChoice, setKistStatusChoice] = useState<'Due' | 'Next' | 'Advance' | 'Paid'>('Next');
  const [dueDateInput, setDueDateInput] = useState<string>('15 Oct 2026');
  const [dueAmountInput, setDueAmountInput] = useState<number>(12500);
  const [paidKistsInput, setPaidKistsInput] = useState<number>(1);
  const [monthlyKistInput, setMonthlyKistInput] = useState<number>(12500);
  const [saveSuccessMsg, setSaveSuccessMsg] = useState<string>('');

  const handleOpenEditModal = (cust: Customer) => {
    setEditingCustomer(cust);
    const initialStatus = cust.kistStatus || (cust.status === 'Due' ? 'Due' : 'Next');
    setKistStatusChoice(initialStatus);
    setDueDateInput(cust.nextDueDate || '15 Oct 2026');
    setDueAmountInput(
      cust.customDueAmount !== undefined
        ? cust.customDueAmount
        : cust.status === 'Due'
        ? cust.monthlyKistAmount * 2
        : cust.monthlyKistAmount
    );
    setPaidKistsInput(cust.paidKists || 0);
    setMonthlyKistInput(cust.monthlyKistAmount || 12500);
    setSaveSuccessMsg('');
  };

  const handleSaveKistSchedule = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingCustomer) return;

    const mappedCustomerStatus = kistStatusChoice === 'Due' ? 'Due' : 'Active';

    updateCustomerKistSchedule(editingCustomer.id, {
      status: mappedCustomerStatus,
      kistStatus: kistStatusChoice,
      nextDueDate: dueDateInput,
      customDueAmount: dueAmountInput,
      paidKists: paidKistsInput,
      monthlyKistAmount: monthlyKistInput,
    });

    setSaveSuccessMsg(`✓ Updated Kist schedule for ${editingCustomer.name}! Marked as "${kistStatusChoice}".`);
    setTimeout(() => {
      setEditingCustomer(null);
      setSaveSuccessMsg('');
    }, 1200);
  };

  const handleSendReminder = (customerName: string, customerMobile: string, amount: number, id: string) => {
    setRemindedCustomerId(id);
    setTimeout(() => {
      alert(`Payment reminder notification sent to ${customerName} (+91 ${customerMobile}) for upcoming kist of ₹${amount.toLocaleString('en-IN')}`);
      setRemindedCustomerId(null);
    }, 400);
  };

  return (
    <div className="space-y-5">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h3 className="font-bold text-base text-slate-900">Kist & Installment Monitoring</h3>
          <p className="text-xs text-slate-500">
            Admin power to configure each customer's kist schedule: mark installments as <strong>Due</strong> or <strong>Next Scheduled</strong>, modify due amounts, and dispatch reminders.
          </p>
        </div>
      </div>

      <div className="bg-white rounded-2xl border border-slate-200 shadow-2xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-slate-500 font-semibold border-b border-slate-200">
              <tr>
                <th className="py-3 px-4">Customer</th>
                <th className="py-3 px-3">Plot</th>
                <th className="py-3 px-3">Installment Plan</th>
                <th className="py-3 px-3">Monthly Kist</th>
                <th className="py-3 px-3">Next Due Date</th>
                <th className="py-3 px-3">Kist Status (Due / Next)</th>
                <th className="py-3 px-4 text-right">Admin Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {customers.map((c) => {
                const prop = properties.find((p) => p.id === c.propertyId);
                const isOverdue = c.kistStatus === 'Due' || c.status === 'Due';
                const remaining = Math.max(0, (c.totalKists || 24) - (c.paidKists || 0));
                const currentStatusLabel = c.kistStatus || (isOverdue ? 'Due' : remaining === 0 ? 'Completed' : 'Next');

                return (
                  <tr key={c.id} className="hover:bg-slate-50/70 transition-colors">
                    <td className="py-3 px-4">
                      <span className="font-bold text-slate-900 block">{c.name}</span>
                      <span className="font-mono text-[10px] text-slate-400">
                        {c.id} · +91 {c.mobile}
                      </span>
                    </td>

                    <td className="py-3 px-3 font-semibold text-slate-800">
                      {prop ? `Plot ${prop.plotNumber}` : 'Unassigned'}
                    </td>

                    <td className="py-3 px-3">
                      <span className="font-mono font-bold text-slate-800">
                        {c.paidKists} of {c.totalKists} Paid
                      </span>
                      <span className="block text-[10px] text-slate-400">
                        {remaining} installments left
                      </span>
                    </td>

                    <td className="py-3 px-3 font-mono font-bold text-slate-900">
                      ₹{c.monthlyKistAmount.toLocaleString('en-IN')}
                    </td>

                    <td className="py-3 px-3 font-mono text-slate-600">
                      {c.nextDueDate}
                    </td>

                    <td className="py-3 px-3">
                      <span
                        className={`px-2 py-0.5 rounded-full text-[10px] font-bold uppercase ${
                          currentStatusLabel === 'Due'
                            ? 'bg-rose-100 text-rose-800 animate-pulse'
                            : currentStatusLabel === 'Next'
                            ? 'bg-orange-100 text-orange-800'
                            : currentStatusLabel === 'Advance'
                            ? 'bg-blue-100 text-blue-800'
                            : 'bg-emerald-100 text-emerald-800'
                        }`}
                      >
                        {currentStatusLabel === 'Due' ? 'Kist Due' : currentStatusLabel === 'Next' ? 'Next Kist' : currentStatusLabel}
                      </span>
                    </td>

                    <td className="py-3 px-4 text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        {/* Power to edit Kist Due or Next */}
                        <button
                          onClick={() => handleOpenEditModal(c)}
                          className="inline-flex items-center gap-1 px-2.5 py-1.5 bg-slate-100 hover:bg-orange-50 hover:text-orange-700 text-slate-700 font-bold rounded-lg text-xs transition-colors cursor-pointer border border-slate-200"
                          title="Configure Due / Next Kist"
                        >
                          <Edit className="w-3 h-3 text-orange-600" />
                          <span>Due / Next</span>
                        </button>

                        {remaining > 0 ? (
                          <button
                            onClick={() => handleSendReminder(c.name, c.mobile, c.monthlyKistAmount, c.id)}
                            disabled={remindedCustomerId === c.id}
                            className="inline-flex items-center gap-1 px-2.5 py-1.5 bg-orange-50 hover:bg-orange-100 text-orange-700 font-bold rounded-lg text-xs transition-colors cursor-pointer border border-orange-200"
                          >
                            <Send className="w-3 h-3" />
                            <span>Remind</span>
                          </button>
                        ) : (
                          <span className="text-emerald-600 font-semibold text-xs flex items-center justify-end gap-0.5">
                            <CheckCircle2 className="w-3 h-3" />
                            <span>Paid</span>
                          </span>
                        )}
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Admin Power Modal: Update Kist (Due or Next) */}
      {editingCustomer && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-lg rounded-3xl shadow-2xl border border-slate-200 p-6 animate-in fade-in">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-4">
              <div>
                <h4 className="font-bold text-base text-slate-900">
                  Update Kist Schedule · {editingCustomer.name}
                </h4>
                <p className="font-mono text-xs text-orange-600">Customer ID: {editingCustomer.id}</p>
              </div>
              <button
                onClick={() => setEditingCustomer(null)}
                className="p-1 text-slate-400 hover:text-slate-800"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {saveSuccessMsg && (
              <div className="mb-4 p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-xs text-emerald-800 font-semibold flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                <span>{saveSuccessMsg}</span>
              </div>
            )}

            <form onSubmit={handleSaveKistSchedule} className="space-y-4 text-xs">
              {/* Option: Kist Due or Next */}
              <div>
                <label className="block font-bold text-slate-800 mb-2">
                  Select Kist Status Option *
                </label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      setKistStatusChoice('Due');
                      setDueAmountInput(editingCustomer.monthlyKistAmount * 2);
                    }}
                    className={`p-3 rounded-xl border font-bold text-xs flex items-center justify-center gap-2 transition-all cursor-pointer ${
                      kistStatusChoice === 'Due'
                        ? 'border-rose-500 bg-rose-50 text-rose-800 ring-2 ring-rose-500/20 shadow-xs'
                        : 'border-slate-200 hover:bg-slate-50 text-slate-700'
                    }`}
                  >
                    <AlertTriangle className="w-4 h-4 text-rose-600" />
                    <span>Mark as Kist Due</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      setKistStatusChoice('Next');
                      setDueAmountInput(editingCustomer.monthlyKistAmount);
                    }}
                    className={`p-3 rounded-xl border font-bold text-xs flex items-center justify-center gap-2 transition-all cursor-pointer ${
                      kistStatusChoice === 'Next'
                        ? 'border-orange-500 bg-orange-50 text-orange-800 ring-2 ring-orange-500/20 shadow-xs'
                        : 'border-slate-200 hover:bg-slate-50 text-slate-700'
                    }`}
                  >
                    <Clock className="w-4 h-4 text-orange-600" />
                    <span>Next Scheduled Kist</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      setKistStatusChoice('Advance');
                      setDueAmountInput(0);
                    }}
                    className={`p-3 rounded-xl border font-bold text-xs flex items-center justify-center gap-2 transition-all cursor-pointer ${
                      kistStatusChoice === 'Advance'
                        ? 'border-blue-500 bg-blue-50 text-blue-800 ring-2 ring-blue-500/20 shadow-xs'
                        : 'border-slate-200 hover:bg-slate-50 text-slate-700'
                    }`}
                  >
                    <span>Advance Payment</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      setKistStatusChoice('Paid');
                      setDueAmountInput(0);
                      setPaidKistsInput(editingCustomer.totalKists);
                    }}
                    className={`p-3 rounded-xl border font-bold text-xs flex items-center justify-center gap-2 transition-all cursor-pointer ${
                      kistStatusChoice === 'Paid'
                        ? 'border-emerald-500 bg-emerald-50 text-emerald-800 ring-2 ring-emerald-500/20 shadow-xs'
                        : 'border-slate-200 hover:bg-slate-50 text-slate-700'
                    }`}
                  >
                    <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                    <span>Paid in Full</span>
                  </button>
                </div>
              </div>

              {/* Due Date & Due Amount */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    Next Due Date *
                  </label>
                  <input
                    type="text"
                    required
                    value={dueDateInput}
                    onChange={(e) => setDueDateInput(e.target.value)}
                    placeholder="e.g. 15 Oct 2026"
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl font-mono text-slate-900"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    Current Due Amount (₹) *
                  </label>
                  <input
                    type="number"
                    required
                    value={dueAmountInput}
                    onChange={(e) => setDueAmountInput(parseFloat(e.target.value) || 0)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl font-mono font-bold text-slate-900"
                  />
                </div>
              </div>

              {/* Paid Kists Counter and Monthly Kist */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    Completed Kists (out of {editingCustomer.totalKists})
                  </label>
                  <input
                    type="number"
                    min={0}
                    max={editingCustomer.totalKists}
                    value={paidKistsInput}
                    onChange={(e) => setPaidKistsInput(parseInt(e.target.value) || 0)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl font-mono text-slate-900"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    Monthly Installment Rate (₹)
                  </label>
                  <input
                    type="number"
                    value={monthlyKistInput}
                    onChange={(e) => setMonthlyKistInput(parseFloat(e.target.value) || 0)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl font-mono text-slate-900"
                  />
                </div>
              </div>

              <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 text-[11px] text-slate-500">
                <p>
                  <strong>Customer Notification:</strong> Saving will immediately reflect on{' '}
                  {editingCustomer.name}'s mobile dashboard, upcoming dues card, and payment notifications.
                </p>
              </div>

              <div className="pt-2 flex gap-3">
                <button
                  type="button"
                  onClick={() => setEditingCustomer(null)}
                  className="flex-1 py-2.5 bg-slate-100 text-slate-700 font-semibold rounded-xl text-xs cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 bg-orange-600 hover:bg-orange-700 text-white font-bold rounded-xl text-xs cursor-pointer shadow-md shadow-orange-600/20"
                >
                  Save Kist Status
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
