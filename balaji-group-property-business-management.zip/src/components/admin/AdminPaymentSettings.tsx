import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  QrCode,
  CheckCircle2,
  Save,
  Link,
  Smartphone,
  Eye,
  Copy,
  Check,
  AlertCircle,
  HelpCircle,
  ShieldCheck,
  Building,
  RefreshCw,
  Send,
  EyeOff,
  Radio,
  ExternalLink,
  MessageCircle,
} from 'lucide-react';
import { SmsProvider } from '../../types';
import { sendRealTimeOtp, getWhatsAppOtpUrl } from '../../services/smsService';

export const AdminPaymentSettings: React.FC = () => {
  const { settings, updateSettings, t } = useApp();

  const [upiId, setUpiId] = useState<string>(settings.upiId || 'balajigroup@icici');
  const [qrCodeUrl, setQrCodeUrl] = useState<string>(settings.qrCodeUrl || '');
  const [qrPaymentEnabled, setQrPaymentEnabled] = useState<boolean>(settings.qrPaymentEnabled ?? true);
  const [paymentInstructions, setPaymentInstructions] = useState<string>(
    settings.paymentInstructions || 'Scan with Google Pay, PhonePe, Paytm or any BHIM UPI app and enter the 12-digit UTR/Txn ID.'
  );
  const [enableOtpLogin, setEnableOtpLogin] = useState<boolean>(settings.enableOtpLogin ?? true);

  // SMS Gateway Real-Time OTP State
  const [smsProvider, setSmsProvider] = useState<SmsProvider>(settings.smsGateway?.provider || 'fast2sms');
  const [smsEnabled, setSmsEnabled] = useState<boolean>(settings.smsGateway?.enabled ?? true);
  const [smsApiKey, setSmsApiKey] = useState<string>(settings.smsGateway?.apiKey || '');
  const [smsSenderId, setSmsSenderId] = useState<string>(settings.smsGateway?.senderId || 'BALAJI');
  const [smsTemplateId, setSmsTemplateId] = useState<string>(settings.smsGateway?.templateId || '');
  const [smsWebhookUrl, setSmsWebhookUrl] = useState<string>(settings.smsGateway?.webhookUrl || '');
  const [twilioAccountSid, setTwilioAccountSid] = useState<string>(settings.smsGateway?.twilioAccountSid || '');
  const [twilioAuthToken, setTwilioAuthToken] = useState<string>(settings.smsGateway?.twilioAuthToken || '');
  const [twilioPhoneNumber, setTwilioPhoneNumber] = useState<string>(settings.smsGateway?.twilioPhoneNumber || '');
  const [whatsappPhoneNumberId, setWhatsappPhoneNumberId] = useState<string>(settings.smsGateway?.whatsappPhoneNumberId || '');
  const [whatsappAccessToken, setWhatsappAccessToken] = useState<string>(settings.smsGateway?.whatsappAccessToken || '');
  const [whatsappTemplateName, setWhatsappTemplateName] = useState<string>(settings.smsGateway?.whatsappTemplateName || 'balaji_otp');

  // Testing SMS state
  const [testMobile, setTestMobile] = useState<string>('');
  const [isTestingSms, setIsTestingSms] = useState<boolean>(false);
  const [testSmsResult, setTestSmsResult] = useState<{ success: boolean; message: string; otp?: string; isRealSms?: boolean } | null>(null);
  const [showApiKey, setShowApiKey] = useState<boolean>(false);
  const [savedSuccess, setSavedSuccess] = useState<boolean>(false);
  const [testCopied, setTestCopied] = useState<boolean>(false);

  // Preset QR templates for quick admin selection
  const presetQRs = [
    {
      name: 'Balaji Group ICICI Current A/C QR',
      url: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=500&auto=format&fit=crop&q=80',
    },
    {
      name: 'Balaji Group HDFC Branch QR',
      url: 'https://images.unsplash.com/photo-1557683316-973673baf926?w=500&auto=format&fit=crop&q=80',
    },
  ];

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    updateSettings({
      upiId: upiId.trim(),
      qrCodeUrl: qrCodeUrl.trim(),
      qrPaymentEnabled,
      paymentInstructions: paymentInstructions.trim(),
      enableOtpLogin,
      smsGateway: {
        provider: smsProvider,
        enabled: smsEnabled,
        apiKey: smsApiKey.trim(),
        senderId: smsSenderId.trim(),
        templateId: smsTemplateId.trim(),
        webhookUrl: smsWebhookUrl.trim(),
        twilioAccountSid: twilioAccountSid.trim(),
        twilioAuthToken: twilioAuthToken.trim(),
        twilioPhoneNumber: twilioPhoneNumber.trim(),
        whatsappPhoneNumberId: whatsappPhoneNumberId.trim(),
        whatsappAccessToken: whatsappAccessToken.trim(),
        whatsappTemplateName: whatsappTemplateName.trim(),
      },
    });
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 3000);
  };

  const handleTestSms = async () => {
    const cleanNumber = testMobile.replace(/\D/g, '').slice(-10);
    if (!cleanNumber || cleanNumber.length < 10) {
      setTestSmsResult({
        success: false,
        message: 'Please enter a valid 10-digit mobile number to test.',
        isRealSms: false,
      });
      return;
    }
    setIsTestingSms(true);
    setTestSmsResult(null);

    try {
      const res = await sendRealTimeOtp(cleanNumber, {
        provider: smsProvider,
        enabled: smsEnabled,
        apiKey: smsApiKey.trim(),
        senderId: smsSenderId.trim(),
        templateId: smsTemplateId.trim(),
        webhookUrl: smsWebhookUrl.trim(),
        twilioAccountSid: twilioAccountSid.trim(),
        twilioAuthToken: twilioAuthToken.trim(),
        twilioPhoneNumber: twilioPhoneNumber.trim(),
        whatsappPhoneNumberId: whatsappPhoneNumberId.trim(),
        whatsappAccessToken: whatsappAccessToken.trim(),
        whatsappTemplateName: whatsappTemplateName.trim(),
      });
      setTestSmsResult(res);
    } catch (err: any) {
      setTestSmsResult({
        success: false,
        message: err.message || 'SMS test delivery failed.',
      });
    } finally {
      setIsTestingSms(false);
    }
  };

  const handleCopyUPI = () => {
    navigator.clipboard.writeText(upiId);
    setTestCopied(true);
    setTimeout(() => setTestCopied(false), 2000);
  };

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h3 className="font-bold text-lg text-slate-900 flex items-center gap-2">
            <QrCode className="w-5 h-5 text-orange-600" />
            <span>Admin Payment & Real-Time SMS Settings</span>
          </h3>
          <p className="text-xs text-slate-500">
            Configure official QR code image URL, UPI ID, and Real-Time SMS OTP Gateway. Changes saved here take effect immediately in the Customer App.
          </p>
        </div>

        {savedSuccess && (
          <div className="flex items-center gap-1.5 px-3 py-1.5 bg-emerald-50 border border-emerald-200 text-emerald-700 text-xs font-bold rounded-xl animate-in fade-in">
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
            <span>Saved to database & Customer App updated!</span>
          </div>
        )}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: Form */}
        <form onSubmit={handleSave} className="lg:col-span-2 space-y-5 text-xs">
          {/* Main Payment Settings Card */}
          <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-2xs space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <h4 className="font-bold text-sm text-slate-900 flex items-center gap-2">
                <Building className="w-4 h-4 text-orange-600" />
                <span>UPI ID & QR Code Configuration</span>
              </h4>

              {/* QR Toggle */}
              <label className="flex items-center gap-2 cursor-pointer select-none">
                <input
                  type="checkbox"
                  checked={qrPaymentEnabled}
                  onChange={(e) => setQrPaymentEnabled(e.target.checked)}
                  className="w-4 h-4 text-orange-600 rounded focus:ring-orange-500 cursor-pointer"
                />
                <span className="font-bold text-slate-700">QR Payment Active</span>
              </label>
            </div>

            {/* UPI ID Field */}
            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Official UPI ID (VPA) <span className="text-rose-500">*</span>
              </label>
              <div className="relative flex items-center">
                <input
                  type="text"
                  required
                  placeholder="e.g. balajigroup@icici"
                  value={upiId}
                  onChange={(e) => setUpiId(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl font-mono text-sm font-bold text-orange-600 focus:bg-white focus:ring-2 focus:ring-orange-500 focus:outline-hidden"
                />
                <button
                  type="button"
                  onClick={handleCopyUPI}
                  className="absolute right-2 px-2.5 py-1 text-slate-400 hover:text-slate-700 text-[11px] font-semibold flex items-center gap-1 cursor-pointer"
                >
                  {testCopied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{testCopied ? 'Copied' : 'Copy'}</span>
                </button>
              </div>
              <p className="text-[11px] text-slate-400 mt-1">
                Used in the customer app's UPI payment links and QR generation for GPay, PhonePe, Paytm, etc.
              </p>
            </div>

            {/* QR Code Image URL Field */}
            <div>
              <label className="block font-semibold text-slate-700 mb-1 flex items-center justify-between">
                <span>Custom QR Code Image URL</span>
                {qrCodeUrl && (
                  <button
                    type="button"
                    onClick={() => setQrCodeUrl('')}
                    className="text-[11px] text-rose-600 hover:underline font-normal cursor-pointer"
                  >
                    Clear to use dynamic QR
                  </button>
                )}
              </label>
              <div className="flex gap-2">
                <div className="relative flex-1">
                  <Link className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                  <input
                    type="url"
                    placeholder="https://yourbank.com/balaji_upi_qr.png"
                    value={qrCodeUrl}
                    onChange={(e) => setQrCodeUrl(e.target.value)}
                    className="w-full pl-9 pr-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl font-mono text-xs focus:bg-white focus:ring-2 focus:ring-orange-500 focus:outline-hidden"
                  />
                </div>
              </div>
              <p className="text-[11px] text-slate-400 mt-1">
                Paste the URL of your bank branch's official QR code image. If left blank, the app will generate a smart dynamic QR code.
              </p>

              {/* Quick Preset Buttons */}
              <div className="mt-3 flex flex-wrap items-center gap-2">
                <span className="text-[11px] text-slate-500 font-medium">Quick Presets:</span>
                {presetQRs.map((preset, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => setQrCodeUrl(preset.url)}
                    className="px-2.5 py-1 bg-slate-100 hover:bg-orange-50 hover:text-orange-600 hover:border-orange-200 border border-slate-200 rounded-lg text-[11px] font-medium transition-colors cursor-pointer"
                  >
                    {preset.name}
                  </button>
                ))}
              </div>
            </div>

            {/* Payment Instructions for Customer */}
            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Payment Instructions for Customers
              </label>
              <textarea
                rows={2}
                value={paymentInstructions}
                onChange={(e) => setPaymentInstructions(e.target.value)}
                placeholder="Instructions shown to customers below QR code..."
                className="w-full px-3.5 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs focus:bg-white focus:ring-2 focus:ring-orange-500 focus:outline-hidden"
              />
            </div>
          </div>

          {/* Customer Authentication Control: Enable OTP Login & Real-Time SMS Gateway */}
          <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-2xs space-y-4">
            <h4 className="font-bold text-sm text-slate-900 flex items-center gap-2">
              <Smartphone className="w-4 h-4 text-orange-600" />
              <span>Authentication & Real-Time SMS Gateway</span>
            </h4>

            {/* OTP Login Toggle */}
            <div className="flex items-center justify-between p-4 bg-slate-50 rounded-2xl border border-slate-200">
              <div>
                <span className="font-bold text-slate-900 block text-xs">Enable OTP Mobile Login</span>
                <span className="text-[11px] text-slate-500 block mt-0.5">
                  Allows customers to log in by entering their registered mobile number.
                </span>
              </div>
              <button
                type="button"
                onClick={() => setEnableOtpLogin(!enableOtpLogin)}
                className={`w-12 h-6 flex items-center rounded-full p-1 transition-colors cursor-pointer ${
                  enableOtpLogin ? 'bg-orange-600' : 'bg-slate-300'
                }`}
              >
                <div
                  className={`bg-white w-4 h-4 rounded-full shadow-md transform transition-transform ${
                    enableOtpLogin ? 'translate-x-6' : 'translate-x-0'
                  }`}
                />
              </button>
            </div>

            {/* Real-time SMS Gateway Toggle */}
            <div className="flex items-center justify-between p-4 bg-orange-50/70 rounded-2xl border border-orange-200">
              <div className="pr-4">
                <span className="font-bold text-slate-900 block text-xs flex items-center gap-1.5">
                  <Radio className="w-4 h-4 text-orange-600 animate-pulse" />
                  <span>Real-Time SMS Delivery to Phone Number</span>
                </span>
                <span className="text-[11px] text-slate-600 block mt-0.5">
                  When enabled, real SMS text messages containing the 6-digit OTP are dispatched directly to the customer's mobile phone via your SMS gateway.
                </span>
              </div>
              <button
                type="button"
                onClick={() => setSmsEnabled(!smsEnabled)}
                className={`w-12 h-6 flex items-center rounded-full p-1 transition-colors cursor-pointer shrink-0 ${
                  smsEnabled ? 'bg-orange-600' : 'bg-slate-300'
                }`}
              >
                <div
                  className={`bg-white w-4 h-4 rounded-full shadow-md transform transition-transform ${
                    smsEnabled ? 'translate-x-6' : 'translate-x-0'
                  }`}
                />
              </button>
            </div>

            {/* Provider and Credentials Section */}
            {smsEnabled && (
              <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 space-y-4 animate-in fade-in">
                {/* Gateway Provider Select */}
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    Select SMS Gateway Provider
                  </label>
                  <select
                    value={smsProvider}
                    onChange={(e) => setSmsProvider(e.target.value as SmsProvider)}
                    className="w-full px-3.5 py-2.5 bg-white border border-slate-300 rounded-xl font-medium cursor-pointer"
                  >
                    <option value="2factor">2Factor.in (Specialized for Indian OTP - Fast & Reliable)</option>
                    <option value="whatsapp_cloud_api">Meta WhatsApp Cloud API (Official WhatsApp OTP for 2000+ Customers)</option>
                    <option value="fast2sms">Fast2SMS (Quick OTP Route for India)</option>
                    <option value="textlocal">Textlocal (India Leading SMS Gateway - textlocal.in)</option>
                    <option value="msg91">MSG91 (Enterprise Indian SMS)</option>
                    <option value="twilio">Twilio (Global Carrier Network)</option>
                    <option value="custom_webhook">Android Phone SIM Gateway / Custom HTTP Webhook</option>
                  </select>
                </div>

                {/* API Key / Auth Key (for non-whatsapp providers) */}
                {smsProvider !== 'whatsapp_cloud_api' && (
                  <div>
                    <label className="block font-semibold text-slate-700 mb-1 flex items-center justify-between">
                      <span>
                        {smsProvider === '2factor'
                          ? '2Factor.in API Key'
                          : smsProvider === 'textlocal'
                          ? 'Textlocal API Key'
                          : smsProvider === 'fast2sms'
                          ? 'Fast2SMS Authorization API Key'
                          : smsProvider === 'msg91'
                          ? 'MSG91 Auth Key'
                          : 'SMS API Key / Token'}
                      </span>
                      <button
                        type="button"
                        onClick={() => setShowApiKey(!showApiKey)}
                        className="text-[11px] text-orange-600 font-normal hover:underline flex items-center gap-1 cursor-pointer"
                      >
                        {showApiKey ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                        <span>{showApiKey ? 'Hide' : 'Show Key'}</span>
                      </button>
                    </label>
                    <input
                      type={showApiKey ? 'text' : 'password'}
                      placeholder={
                        smsProvider === 'fast2sms'
                          ? 'Paste Fast2SMS API Key here (e.g. jhg768...)'
                          : 'Paste your SMS gateway key'
                      }
                      value={smsApiKey}
                      onChange={(e) => setSmsApiKey(e.target.value)}
                      className="w-full px-3.5 py-2.5 bg-white border border-slate-300 rounded-xl font-mono text-xs focus:ring-2 focus:ring-orange-500"
                    />
                  </div>
                )}

                {/* DLT Configuration for Indian Gateways */}
                {['msg91', 'fast2sms', '2factor', 'textlocal'].includes(smsProvider) && (
                  <div className="p-3 bg-amber-50/60 border border-amber-200/80 rounded-xl space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-[11px] font-bold text-amber-950 flex items-center gap-1.5">
                        <ShieldCheck className="w-3.5 h-3.5 text-amber-700" />
                        DLT (TRAI India) Configuration {smsProvider === 'fast2sms' || smsProvider === '2factor' ? '(Optional)' : '(Required)'}
                      </span>
                      <span className="text-[10px] text-amber-800 bg-amber-100 px-2 py-0.5 rounded-full font-medium">
                        TRAI Compliant
                      </span>
                    </div>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                      <div>
                        <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                          DLT Template ID (Content ID)
                        </label>
                        <input
                          type="text"
                          placeholder="e.g. 1207161829384729102"
                          value={smsTemplateId}
                          onChange={(e) => setSmsTemplateId(e.target.value)}
                          className="w-full px-3 py-1.5 bg-white border border-slate-300 rounded-lg font-mono text-xs"
                        />
                      </div>
                      <div>
                        <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                          DLT Sender ID / Header (6 chars)
                        </label>
                        <input
                          type="text"
                          maxLength={6}
                          placeholder="e.g. BALAJI or BLJGRP"
                          value={smsSenderId}
                          onChange={(e) => setSmsSenderId(e.target.value.toUpperCase())}
                          className="w-full px-3 py-1.5 bg-white border border-slate-300 rounded-lg font-mono text-xs uppercase"
                        />
                      </div>
                    </div>
                    <p className="text-[10px] text-slate-500 leading-tight">
                      {smsProvider === 'fast2sms' || smsProvider === '2factor'
                        ? 'Leave blank to use the gateway default approved DLT OTP template, or provide your registered DLT IDs for custom branded SMS.'
                        : 'Enter your TRAI DLT approved 6-character Header (Sender ID) and approved OTP Template ID.'}
                    </p>
                  </div>
                )}

                {smsProvider === 'custom_webhook' && (
                  <div className="space-y-2">
                    <div>
                      <label className="block font-semibold text-slate-700 mb-1">
                        Webhook POST URL (Android SMS Gateway / Custom API)
                      </label>
                      <input
                        type="url"
                        placeholder="e.g. https://api.sms-gateway.app/v1/message or http://192.168.1.50:8080/sms"
                        value={smsWebhookUrl}
                        onChange={(e) => setSmsWebhookUrl(e.target.value)}
                        className="w-full px-3.5 py-2 bg-white border border-slate-300 rounded-xl font-mono text-xs"
                      />
                    </div>
                    <div className="p-3 bg-blue-50 border border-blue-200 rounded-xl text-blue-900 text-[11px] leading-relaxed">
                      <strong className="block mb-1 text-blue-950 font-bold">📱 Free SMS from your own Android Phone:</strong>
                      Install a free Android app like <strong>Android SMS Gateway</strong> (android-sms-gateway.com) or <strong>TextBee</strong> (textbee.dev) on any Android phone with your Jio/Airtel SIM. Paste the webhook URL here. It sends real cellular SMS directly from your SIM card's daily 100 free SMS pack!
                    </div>
                  </div>
                )}

                {smsProvider === 'twilio' && (
                  <div className="space-y-3">
                    <div>
                      <label className="block font-semibold text-slate-700 mb-1">
                        Twilio Account SID
                      </label>
                      <input
                        type="text"
                        placeholder="e.g. ACxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"
                        value={twilioAccountSid}
                        onChange={(e) => setTwilioAccountSid(e.target.value)}
                        className="w-full px-3.5 py-2 bg-white border border-slate-300 rounded-xl font-mono text-xs"
                      />
                    </div>
                    <div>
                      <label className="block font-semibold text-slate-700 mb-1">
                        Twilio Auth Token
                      </label>
                      <input
                        type={showApiKey ? 'text' : 'password'}
                        placeholder="e.g. 1a2b3c4d..."
                        value={twilioAuthToken}
                        onChange={(e) => setTwilioAuthToken(e.target.value)}
                        className="w-full px-3.5 py-2 bg-white border border-slate-300 rounded-xl font-mono text-xs"
                      />
                    </div>
                    <div>
                      <label className="block font-semibold text-slate-700 mb-1">
                        Twilio Phone Number (Sender)
                      </label>
                      <input
                        type="text"
                        placeholder="e.g. +12025550143"
                        value={twilioPhoneNumber}
                        onChange={(e) => setTwilioPhoneNumber(e.target.value)}
                        className="w-full px-3.5 py-2 bg-white border border-slate-300 rounded-xl font-mono text-xs"
                      />
                    </div>
                  </div>
                )}

                {/* WhatsApp Cloud API Configuration (For 2,000+ Customers) */}
                {smsProvider === 'whatsapp_cloud_api' && (
                  <div className="space-y-3 p-3.5 bg-emerald-50/70 border border-emerald-200 rounded-xl animate-in fade-in">
                    <div className="flex items-center justify-between border-b border-emerald-200/80 pb-2">
                      <span className="font-bold text-emerald-950 text-xs flex items-center gap-1.5">
                        <MessageCircle className="w-4 h-4 text-emerald-600 fill-emerald-600/20" />
                        Meta Official WhatsApp Cloud API (For 2,000+ Customers)
                      </span>
                      <span className="text-[10px] bg-emerald-100 text-emerald-900 px-2 py-0.5 rounded-full font-bold">
                        Official Meta API
                      </span>
                    </div>

                    <div>
                      <div className="flex items-center justify-between mb-1">
                        <label className="block text-xs font-semibold text-slate-700">
                          WhatsApp Phone Number ID
                        </label>
                        {!whatsappPhoneNumberId && (
                          <button
                            type="button"
                            onClick={() => setWhatsappPhoneNumberId('1351975251337815')}
                            className="text-[10px] text-emerald-700 hover:underline font-bold"
                          >
                            Use ID from curl: 1351975251337815
                          </button>
                        )}
                      </div>
                      <input
                        type="text"
                        placeholder="e.g. 1351975251337815"
                        value={whatsappPhoneNumberId}
                        onChange={(e) => setWhatsappPhoneNumberId(e.target.value)}
                        className="w-full px-3.5 py-2 bg-white border border-slate-300 rounded-xl font-mono text-xs"
                      />
                      <p className="text-[10px] text-slate-500 mt-1">
                        Found in Meta Developer Center under <strong>API Setup &gt; Step 1: Phone number ID</strong> (From your curl: <code className="bg-slate-100 px-1 rounded">1351975251337815</code>).
                      </p>
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1">
                        Access Token (Bearer Token from Meta)
                      </label>
                      <input
                        type={showApiKey ? 'text' : 'password'}
                        placeholder="Paste your Access Token here (starts with EAAB...)"
                        value={whatsappAccessToken}
                        onChange={(e) => setWhatsappAccessToken(e.target.value)}
                        className="w-full px-3.5 py-2 bg-white border border-slate-300 rounded-xl font-mono text-xs"
                      />
                      <p className="text-[10px] text-slate-500 mt-1">
                        In Meta Developer Center, click <strong>"Copy"</strong> next to <strong>Temporary access token</strong> (under Step 1) and paste here.
                      </p>
                    </div>

                    <div>
                      <div className="flex items-center justify-between mb-1">
                        <label className="block text-xs font-semibold text-slate-700">
                          WhatsApp Template Name
                        </label>
                        <div className="flex gap-1.5 text-[10px]">
                          <button
                            type="button"
                            onClick={() => setWhatsappTemplateName('3p_direct_integration_test_template')}
                            className="text-emerald-700 hover:underline font-medium"
                          >
                            3p_test
                          </button>
                          <span className="text-slate-300">·</span>
                          <button
                            type="button"
                            onClick={() => setWhatsappTemplateName('hello_world')}
                            className="text-emerald-700 hover:underline font-medium"
                          >
                            hello_world
                          </button>
                        </div>
                      </div>
                      <input
                        type="text"
                        placeholder="e.g. 3p_direct_integration_test_template or balaji_otp"
                        value={whatsappTemplateName}
                        onChange={(e) => setWhatsappTemplateName(e.target.value)}
                        className="w-full px-3.5 py-2 bg-white border border-slate-300 rounded-xl font-mono text-xs"
                      />
                      <p className="text-[10px] text-slate-500 mt-1">
                        In Developer Center, select your template from the <strong>"Select template"</strong> dropdown.
                      </p>
                    </div>

                    {/* Developer Center Screen Navigation Guide */}
                    <div className="p-3 bg-white rounded-xl border border-emerald-200 text-[11px] text-slate-700 space-y-2">
                      <strong className="text-emerald-950 block font-bold text-xs">
                        🧭 How to Select Inside Meta Developer Center (Step-by-Step):
                      </strong>
                      <ol className="list-decimal list-inside space-y-1 text-[10px] text-slate-600">
                        <li>
                          <strong>Left Menu:</strong> Click on <strong>WhatsApp</strong> &gt; <strong>API Setup</strong>.
                        </li>
                        <li>
                          <strong>Step 1 (Send and receive messages):</strong>
                          <ul className="list-disc list-inside ml-3 mt-0.5 space-y-0.5">
                            <li><strong>Temporary access token:</strong> Click the <span className="bg-slate-100 px-1 py-0.5 rounded font-mono">Copy</span> button and paste it into the <em>Access Token</em> field above.</li>
                            <li><strong>From:</strong> Shows your Phone number ID: <code className="bg-emerald-50 text-emerald-800 font-bold px-1 rounded">1351975251337815</code>.</li>
                            <li><strong>To:</strong> Select or add your mobile number (<code className="bg-slate-100 px-1 rounded">919754165466</code>). Click <em>"Manage phone number list"</em> to add and verify your phone with an SMS code if not added yet.</li>
                          </ul>
                        </li>
                        <li>
                          <strong>Step 2 (Select template):</strong>
                          In the dropdown, select <code className="bg-slate-100 px-1 rounded">3p_direct_integration_test_template</code> or <code className="bg-slate-100 px-1 rounded">hello_world</code>.
                        </li>
                        <li>
                          <strong>Click "Send message" in Meta:</strong> Your phone will receive the test message directly in WhatsApp!
                        </li>
                      </ol>
                    </div>
                  </div>
                )}

                {/* Gateway Delivery Status Indicator */}
                {(() => {
                  const isGatewayActive =
                    smsProvider === 'twilio'
                      ? Boolean(twilioAccountSid && twilioAuthToken)
                      : smsProvider === 'whatsapp_cloud_api'
                      ? Boolean(whatsappPhoneNumberId && whatsappAccessToken)
                      : smsProvider === 'custom_webhook'
                      ? Boolean(smsWebhookUrl.trim())
                      : Boolean(smsApiKey.trim());

                  return (
                    <div
                      className={`p-3 rounded-xl border ${
                        isGatewayActive
                          ? 'bg-emerald-50 border-emerald-200 text-emerald-800'
                          : 'bg-amber-50 border-amber-200 text-amber-800'
                      }`}
                    >
                      <div className="flex items-center gap-2 font-bold text-[11px] mb-1">
                        <span
                          className={`w-2 h-2 rounded-full ${
                            isGatewayActive ? 'bg-emerald-600 animate-pulse' : 'bg-amber-600'
                          }`}
                        ></span>
                        <span>
                          {isGatewayActive
                            ? `Live Gateway Configured & Active (${smsProvider === 'whatsapp_cloud_api' ? 'Official Meta WhatsApp API' : smsProvider})`
                            : 'Real-Time Simulated / Visual Mode Active (No API Key Yet)'}
                        </span>
                      </div>
                      <p className="text-[10px] leading-relaxed">
                        {isGatewayActive
                          ? `Live OTP requests will be dispatched to customers via ${smsProvider === 'whatsapp_cloud_api' ? 'Meta Official WhatsApp' : 'the configured telecom carrier'}.`
                          : 'Real-time 6-digit OTP codes are generated instantly with a 1-tap fill button and WhatsApp link. Enter your credentials above to deliver messages directly to physical phone numbers.'}
                      </p>
                    </div>
                  );
                })()}

                {/* Real SMS Delivery, DLT & Gateway Knowledge Guide */}
                <div className="p-3.5 bg-white rounded-xl border border-slate-200 space-y-3">
                  <div className="flex items-center justify-between border-b border-slate-100 pb-2">
                    <span className="font-bold text-slate-800 text-[11px] flex items-center gap-1.5">
                      <HelpCircle className="w-3.5 h-3.5 text-orange-600" />
                      Telecom SMS, DLT & Gateway Guide
                    </span>
                    <span className="text-[10px] text-slate-400 font-mono">India (+91) Rules</span>
                  </div>
                  
                  {/* Important: OnlineSIM clarification */}
                  <div className="p-2.5 bg-rose-50/80 border border-rose-200 rounded-xl text-[11px]">
                    <div className="flex items-center gap-1.5 font-bold text-rose-900 mb-1">
                      <AlertCircle className="w-3.5 h-3.5 text-rose-600 shrink-0" />
                      <span>Can we use OnlineSIM.io? — NO (Common Misconception)</span>
                    </div>
                    <p className="text-rose-800 text-[10px] leading-relaxed">
                      <strong>OnlineSIM.io is strictly an INBOUND SMS receiver</strong> (it provides temporary burner numbers to <em>receive</em> OTPs when creating accounts on Telegram/WhatsApp). <strong>It CANNOT send outbound SMS to customers' mobile phones.</strong> To send OTPs to customers, you need an outbound SMS gateway (Fast2SMS, 2Factor, MSG91) or your Android phone.
                    </p>
                  </div>

                  {/* DLT Explained */}
                  <div className="p-2.5 bg-amber-50/80 border border-amber-200 rounded-xl text-[11px]">
                    <div className="flex items-center gap-1.5 font-bold text-amber-950 mb-1">
                      <ShieldCheck className="w-3.5 h-3.5 text-amber-700 shrink-0" />
                      <span>Can we use DLT? — YES, and it is the Official Way in India</span>
                    </div>
                    <p className="text-amber-900 text-[10px] leading-relaxed">
                      <strong>What is DLT?</strong> TRAI (Govt. of India) mandates Distributed Ledger Technology (DLT) for all commercial SMS to prevent fraud and spam. You can register on <strong>Jio TrueConnect (DLT)</strong>, <strong>Airtel IQ DLT</strong>, or <strong>Vodafone VilPower</strong>.
                    </p>
                    <ul className="mt-1.5 space-y-0.5 text-[10px] text-amber-900 list-disc list-inside">
                      <li><strong>Entity Registration:</strong> Register your company (PAN / Aadhaar / Business registration).</li>
                      <li><strong>Sender Header (6 letters):</strong> e.g., <code className="bg-amber-100 px-1 rounded">BALAJI</code> or <code className="bg-amber-100 px-1 rounded">BLJGRP</code>.</li>
                      <li><strong>Content Template:</strong> <code className="bg-amber-100 px-1 rounded">Your OTP for Balaji Group is {'{#var#}'}. Valid for 10 mins.</code></li>
                    </ul>
                    <p className="mt-1 text-[10px] text-amber-800">
                      <strong>Don't have DLT yet?</strong> Use <strong>Fast2SMS Quick OTP</strong> (they use their pre-approved DLT templates) or <strong>Android Phone Gateway</strong> (no DLT required for personal SIM).
                    </p>
                  </div>

                  {/* Gateway Breakdown */}
                  <div className="space-y-1.5 text-[10px] text-slate-600">
                    <span className="font-bold text-slate-800 text-[11px] block">
                      Recommended Outbound SMS Gateways:
                    </span>

                    <div className="p-2 bg-slate-50 border border-slate-200 rounded-lg">
                      <strong className="text-slate-900 font-bold block">
                        1. 2Factor.in (Best Dedicated OTP Gateway in India)
                      </strong>
                      <span>
                        Gives free trial balance. High delivery speed (2-4 seconds) and automatic fallback to Voice Call OTP if SMS fails.
                      </span>
                    </div>

                    <div className="p-2 bg-slate-50 border border-slate-200 rounded-lg">
                      <strong className="text-slate-900 font-bold block">
                        2. Fast2SMS (Quickest Setup without DLT)
                      </strong>
                      <span>
                        Free trial credits on sign-up at fast2sms.com. Quick OTP route works immediately with zero paperwork.
                      </span>
                    </div>

                    <div className="p-2 bg-slate-50 border border-slate-200 rounded-lg">
                      <strong className="text-slate-900 font-bold block">
                        3. Android SMS Gateway (100% Free - 100 SMS/Day from your SIM)
                      </strong>
                      <span>
                        Install open-source <strong>Android SMS Gateway</strong> (android-sms-gateway.com) on your Android phone with Jio/Airtel SIM. Select "Custom Webhook" above. Completely free, no DLT required!
                      </span>
                    </div>

                    <div className="p-2 bg-slate-50 border border-slate-200 rounded-lg">
                      <strong className="text-slate-900 font-bold block">
                        4. Google Firebase Phone Auth (10,000 Free OTPs / Month)
                      </strong>
                      <span>
                        Google sends real SMS OTPs globally. Free tier allows 10,000 authentications every month.
                      </span>
                    </div>
                  </div>
                </div>

                {/* Test Live SMS Tool */}
                <div className="pt-2 border-t border-slate-200">
                  <label className="block font-bold text-slate-800 mb-1.5">
                    Test Real-Time SMS Delivery
                  </label>
                  <div className="flex gap-2">
                    <div className="relative flex-1">
                      <span className="absolute left-3 top-2.5 text-slate-400 font-bold text-xs">+91</span>
                      <input
                        type="tel"
                        maxLength={10}
                        placeholder="Your 10-digit mobile number"
                        value={testMobile}
                        onChange={(e) => setTestMobile(e.target.value.replace(/\D/g, ''))}
                        className="w-full pl-11 pr-3 py-2 bg-white border border-slate-300 rounded-xl font-mono text-xs"
                      />
                    </div>
                    <div className="flex gap-1.5 shrink-0">
                      <button
                        type="button"
                        disabled={isTestingSms}
                        onClick={handleTestSms}
                        className="px-3.5 py-2 bg-slate-900 hover:bg-slate-800 disabled:bg-slate-400 text-white font-bold rounded-xl text-xs flex items-center gap-1.5 transition-colors cursor-pointer"
                      >
                        {isTestingSms ? (
                          <>
                            <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                            <span>Sending...</span>
                          </>
                        ) : (
                          <>
                            <Send className="w-3.5 h-3.5" />
                            <span>Carrier SMS</span>
                          </>
                        )}
                      </button>
                      <a
                        href={getWhatsAppOtpUrl(testMobile || '9876543210', '123456')}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl text-xs flex items-center gap-1.5 transition-colors cursor-pointer"
                      >
                        <MessageCircle className="w-3.5 h-3.5" />
                        <span>WhatsApp</span>
                      </a>
                    </div>
                  </div>

                  {testSmsResult && (
                    <div
                      className={`mt-2.5 p-3 rounded-xl border text-xs flex items-start gap-2 ${
                        testSmsResult.success
                          ? 'bg-emerald-50 border-emerald-200 text-emerald-800'
                          : 'bg-rose-50 border-rose-200 text-rose-800'
                      }`}
                    >
                      {testSmsResult.success ? (
                        <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                      ) : (
                        <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
                      )}
                      <div>
                        <span className="font-bold block">{testSmsResult.message}</span>
                        {testSmsResult.otp && (
                          <span className="font-mono text-[11px] block mt-0.5">
                            Dispatched OTP: <strong>{testSmsResult.otp}</strong>
                          </span>
                        )}
                      </div>
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>

          {/* Submit Button */}
          <div className="flex items-center justify-end gap-3 pt-2">
            <button
              type="submit"
              className="px-6 py-3.5 bg-orange-600 hover:bg-orange-700 text-white font-bold rounded-2xl text-xs flex items-center gap-2 shadow-lg shadow-orange-600/20 transition-all active:scale-[0.98] cursor-pointer"
            >
              <Save className="w-4 h-4" />
              <span>Save Payment Settings to Database</span>
            </button>
          </div>
        </form>

        {/* Right 1 Col: Dynamic Live Preview */}
        <div className="space-y-4">
          <div className="bg-white rounded-3xl p-5 border border-slate-200 shadow-2xs">
            <div className="flex items-center justify-between mb-3 pb-2 border-b border-slate-100">
              <span className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                <Eye className="w-4 h-4 text-orange-600" />
                <span>Customer App Live Preview</span>
              </span>
              <span className="text-[10px] bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded-full font-bold">
                Dynamic Sync
              </span>
            </div>

            <p className="text-[11px] text-slate-500 mb-4">
              Here is exactly how the customer will see your configured UPI ID and QR code during installment checkout:
            </p>

            {/* Simulated Customer App QR Card */}
            <div className="bg-slate-50 rounded-2xl p-4 border border-slate-200 text-center">
              <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400 block mb-1">
                Installment Payment
              </span>
              <span className="text-xl font-extrabold text-slate-900 font-mono block mb-3">
                ₹12,500
              </span>

              {/* QR Code Container */}
              <div className="p-3 bg-white rounded-xl shadow-xs border border-slate-200 inline-block mb-3">
                {qrCodeUrl ? (
                  <img
                    src={qrCodeUrl}
                    alt="Custom QR Preview"
                    onError={(e) => {
                      (e.target as HTMLElement).style.display = 'none';
                    }}
                    className="w-36 h-36 object-contain rounded-md mx-auto"
                  />
                ) : (
                  <div className="w-36 h-36 bg-slate-900 rounded-md flex flex-col items-center justify-center p-2 text-white text-[10px]">
                    <QrCode className="w-16 h-16 text-orange-500 mb-1" />
                    <span className="font-mono text-[9px] text-slate-300">Auto-Generated Dynamic QR</span>
                  </div>
                )}
              </div>

              {/* UPI ID Pill */}
              <div className="bg-white px-3 py-1.5 rounded-xl border border-slate-200 inline-flex items-center gap-2 max-w-full">
                <span className="text-[10px] text-slate-400">UPI ID:</span>
                <span className="font-mono font-bold text-xs text-orange-600 truncate">{upiId}</span>
              </div>

              <p className="text-[10px] text-slate-500 mt-3 italic line-clamp-2">
                "{paymentInstructions}"
              </p>
            </div>

            {/* Verification Notice */}
            <div className="mt-4 p-3 bg-orange-50/60 rounded-xl border border-orange-100 flex items-start gap-2 text-[11px] text-orange-800">
              <ShieldCheck className="w-4 h-4 text-orange-600 shrink-0 mt-0.5" />
              <span>
                Manual payments submitted by customers with their 12-digit UTR will appear in the <strong>Admin Payments</strong> queue for verification before receipts are approved.
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
