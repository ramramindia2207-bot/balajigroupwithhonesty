import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Home,
  Plus,
  Search,
  MapPin,
  FileText,
  Upload,
  Trash2,
  Edit,
  CheckCircle,
  X,
  ExternalLink,
} from 'lucide-react';
import { Property, PropertyType, PropertyStatus } from '../../types';

export const AdminProperties: React.FC = () => {
  const { properties, addProperty, updateProperty, deleteProperty, addPropertyDocument } = useApp();

  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('All');
  const [showAddModal, setShowAddModal] = useState(false);
  const [showUploadModal, setShowUploadModal] = useState<string | null>(null);

  // New Property Form State
  const [plotNumber, setPlotNumber] = useState('');
  const [title, setTitle] = useState('');
  const [location, setLocation] = useState('Green Valley, Chhatarpur, New Delhi');
  const [propertyType, setPropertyType] = useState<PropertyType>('Residential Plot');
  const [propertySize, setPropertySize] = useState('1000 Sq. Ft.');
  const [dimensions, setDimensions] = useState('25 x 40 Ft.');
  const [totalValue, setTotalValue] = useState(1250000);
  const [bookingAmount, setBookingAmount] = useState(150000);
  const [registryNumber, setRegistryNumber] = useState('REG-DL-2026-');
  const [status, setStatus] = useState<PropertyStatus>('Available');

  // Upload Doc Form State
  const [docName, setDocName] = useState('');
  const [docType, setDocType] = useState<any>('Registry Copy');

  const filteredProperties = properties.filter((p) => {
    const matchesSearch =
      p.plotNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
      p.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      p.location.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === 'All' || p.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const handleCreateProperty = (e: React.FormEvent) => {
    e.preventDefault();
    if (!plotNumber.trim() || !title.trim()) {
      alert('Please enter plot number and title.');
      return;
    }

    addProperty({
      plotNumber: plotNumber.trim(),
      title: title.trim(),
      location: location.trim(),
      propertyType,
      propertySize,
      dimensions,
      totalValue,
      bookingAmount,
      bookingDate: new Date().toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' }),
      registrationDate: status === 'Registered' ? '15 Oct 2026' : 'Pending',
      registryNumber,
      status,
      imageUrl: '/src/assets/images/balaji_plot_greenvalley_1791042223890.jpg',
      documents: [],
      features: ['30 Ft. Wide Road', 'Gated Security', 'Underground Electricity'],
    });

    setShowAddModal(false);
    setPlotNumber('');
    setTitle('');
  };

  const handleUploadDoc = (e: React.FormEvent) => {
    e.preventDefault();
    if (!showUploadModal || !docName.trim()) return;

    addPropertyDocument(showUploadModal, {
      name: docName.trim().endsWith('.pdf') ? docName.trim() : `${docName.trim()}.pdf`,
      type: docType,
      fileSize: '2.1 MB',
    });

    setShowUploadModal(null);
    setDocName('');
  };

  return (
    <div className="space-y-5">
      {/* Top Header & Search Bar */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
        <div className="flex-1 flex items-center gap-3">
          <div className="relative flex-1 max-w-md">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
            <input
              type="text"
              placeholder="Search by Plot Number, Project, or Location..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2.5 bg-white border border-slate-200 rounded-xl text-xs focus:ring-2 focus:ring-orange-500 shadow-2xs"
            />
          </div>

          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="px-3 py-2.5 bg-white border border-slate-200 rounded-xl text-xs text-slate-700 shadow-2xs cursor-pointer"
          >
            <option value="All">All Statuses</option>
            <option value="Available">Available</option>
            <option value="Sold">Sold / Allotted</option>
            <option value="Booked">Booked</option>
            <option value="Registered">Registered</option>
          </select>
        </div>

        <button
          onClick={() => setShowAddModal(true)}
          className="px-4 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold transition-colors flex items-center justify-center gap-1.5 cursor-pointer shadow-sm"
        >
          <Plus className="w-4 h-4" />
          <span>Add New Property</span>
        </button>
      </div>

      {/* Property Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {filteredProperties.map((prop) => (
          <div
            key={prop.id}
            className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-2xs hover:shadow-md transition-shadow flex flex-col"
          >
            {/* Image Preview */}
            <div className="relative h-44 bg-slate-100">
              <img
                src={prop.imageUrl || '/src/assets/images/balaji_plot_greenvalley_1791042223890.jpg'}
                alt={prop.title}
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover"
              />
              <span className="absolute top-2.5 left-2.5 bg-slate-900/80 backdrop-blur-xs text-white text-[10px] font-bold px-2 py-0.5 rounded-md uppercase">
                {prop.propertyType}
              </span>
              <span
                className={`absolute top-2.5 right-2.5 text-[10px] font-bold px-2 py-0.5 rounded-md uppercase ${
                  prop.status === 'Available'
                    ? 'bg-emerald-500 text-white'
                    : prop.status === 'Sold'
                    ? 'bg-orange-600 text-white'
                    : 'bg-blue-600 text-white'
                }`}
              >
                {prop.status}
              </span>
              <div className="absolute bottom-2 left-2.5 bg-black/60 backdrop-blur-xs px-2 py-0.5 rounded text-white text-xs font-bold font-mono">
                Plot {prop.plotNumber}
              </div>
            </div>

            {/* Info Body */}
            <div className="p-4 flex-1 flex flex-col justify-between space-y-3">
              <div>
                <h4 className="font-bold text-sm text-slate-900 line-clamp-1">{prop.title}</h4>
                <p className="text-xs text-slate-500 flex items-center gap-1 mt-0.5">
                  <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                  <span className="truncate">{prop.location}</span>
                </p>

                <div className="grid grid-cols-2 gap-2 mt-3 pt-3 border-t border-slate-100 text-xs">
                  <div>
                    <span className="text-slate-400 block text-[10px]">Size / Dim</span>
                    <span className="font-semibold text-slate-800 font-mono">
                      {prop.propertySize}
                    </span>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-[10px]">Total Value</span>
                    <span className="font-bold text-orange-600 font-mono">
                      ₹{prop.totalValue.toLocaleString('en-IN')}
                    </span>
                  </div>
                </div>

                {prop.assignedCustomerName && (
                  <div className="mt-2 p-2 bg-slate-50 rounded-lg text-xs">
                    <span className="text-slate-400 block text-[10px]">Allotted Customer:</span>
                    <span className="font-semibold text-slate-900">
                      {prop.assignedCustomerName}
                    </span>
                  </div>
                )}
              </div>

              {/* Documents & Actions Footer */}
              <div className="pt-3 border-t border-slate-100 flex items-center justify-between text-xs">
                <button
                  onClick={() => setShowUploadModal(prop.id)}
                  className="inline-flex items-center gap-1 text-slate-600 hover:text-orange-600 font-semibold cursor-pointer"
                >
                  <Upload className="w-3.5 h-3.5" />
                  <span>Docs ({prop.documents.length})</span>
                </button>

                <div className="flex items-center gap-1">
                  <select
                    value={prop.status}
                    onChange={(e) => updateProperty(prop.id, { status: e.target.value as any })}
                    className="text-[11px] bg-slate-50 border border-slate-200 rounded px-1.5 py-1 text-slate-700"
                  >
                    <option value="Available">Available</option>
                    <option value="Booked">Booked</option>
                    <option value="Sold">Sold</option>
                    <option value="Registered">Registered</option>
                  </select>

                  <button
                    onClick={() => {
                      if (confirm(`Delete Plot ${prop.plotNumber}?`)) {
                        deleteProperty(prop.id);
                      }
                    }}
                    className="p-1 text-slate-400 hover:text-rose-600 cursor-pointer"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Add Property Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-lg rounded-2xl shadow-xl border border-slate-200 p-6 animate-in fade-in">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-4">
              <h4 className="font-bold text-base text-slate-900">Add New Property</h4>
              <button
                onClick={() => setShowAddModal(false)}
                className="p-1 text-slate-400 hover:text-slate-800"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateProperty} className="space-y-3 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Plot Number *</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. 45E"
                    value={plotNumber}
                    onChange={(e) => setPlotNumber(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl font-mono uppercase"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Property Type</label>
                  <select
                    value={propertyType}
                    onChange={(e) => setPropertyType(e.target.value as any)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl"
                  >
                    <option value="Residential Plot">Residential Plot</option>
                    <option value="Commercial Plot">Commercial Plot</option>
                    <option value="Villa Plot">Villa Plot</option>
                    <option value="Farmhouse">Farmhouse</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Title</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Green Valley Corner Villa Plot"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Location</label>
                <input
                  type="text"
                  value={location}
                  onChange={(e) => setLocation(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Plot Size</label>
                  <input
                    type="text"
                    value={propertySize}
                    onChange={(e) => setPropertySize(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl font-mono"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Dimensions</label>
                  <input
                    type="text"
                    value={dimensions}
                    onChange={(e) => setDimensions(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl font-mono"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Total Value (₹)</label>
                  <input
                    type="number"
                    value={totalValue}
                    onChange={(e) => setTotalValue(parseFloat(e.target.value) || 0)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl font-mono"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Status</label>
                  <select
                    value={status}
                    onChange={(e) => setStatus(e.target.value as any)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl"
                  >
                    <option value="Available">Available</option>
                    <option value="Booked">Booked</option>
                    <option value="Sold">Sold</option>
                  </select>
                </div>
              </div>

              <button
                type="submit"
                className="w-full mt-2 py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl text-xs cursor-pointer shadow-sm"
              >
                Create Property Record
              </button>
            </form>
          </div>
        </div>
      )}

      {/* Upload Property Document Modal */}
      {showUploadModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-sm rounded-2xl shadow-xl border border-slate-200 p-6 animate-in fade-in">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-4">
              <h4 className="font-bold text-sm text-slate-900">Upload Property Document</h4>
              <button
                onClick={() => setShowUploadModal(null)}
                className="p-1 text-slate-400 hover:text-slate-800"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleUploadDoc} className="space-y-3 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Document Title</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Registered Sale Deed Plot 12A"
                  value={docName}
                  onChange={(e) => setDocName(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Document Type</label>
                <select
                  value={docType}
                  onChange={(e) => setDocType(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl"
                >
                  <option value="Registry Copy">Registry Copy</option>
                  <option value="Allotment Letter">Allotment Letter</option>
                  <option value="Possession Deed">Possession Deed</option>
                  <option value="Site Plan">Site Plan / Blueprint</option>
                  <option value="Agreement">Allotment Agreement</option>
                </select>
              </div>

              <div className="border border-dashed border-slate-300 rounded-xl p-4 text-center bg-slate-50">
                <FileText className="w-6 h-6 text-slate-400 mx-auto mb-1" />
                <span className="text-[11px] text-slate-500 block">
                  Click to select PDF file (max 10MB)
                </span>
              </div>

              <button
                type="submit"
                className="w-full py-2.5 bg-orange-600 hover:bg-orange-700 text-white font-bold rounded-xl text-xs cursor-pointer shadow-sm"
              >
                Upload & Assign to Customer
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
