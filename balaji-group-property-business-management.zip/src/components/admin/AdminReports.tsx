import React from 'react';
import { useApp } from '../../context/AppContext';
import { FileSpreadsheet, Download, Printer, TrendingUp, Users, Home, CreditCard } from 'lucide-react';

export const AdminReports: React.FC = () => {
  const { customers, properties, payments } = useApp();

  const approvedPayments = payments.filter((p) => p.status === 'Approved');
  const totalCollections = approvedPayments.reduce((sum, p) => sum + p.amount, 0);

  const downloadCSV = (content: string, filename: string) => {
    const blob = new Blob([content], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', filename);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const exportCustomersCSV = () => {
    const headers = ['CustomerID', 'Name', 'Mobile', 'Email', 'City', 'Status', 'TotalValue', 'MonthlyKist', 'PaidKists', 'TotalKists', 'NextDueDate'];
    const rows = customers.map((c) => [
      c.id,
      `"${c.name}"`,
      c.mobile,
      c.email,
      `"${c.city}"`,
      c.status,
      c.totalPropertyValue,
      c.monthlyKistAmount,
      c.paidKists,
      c.totalKists,
      c.nextDueDate,
    ]);
    const csv = [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
    downloadCSV(csv, `balaji_customers_${new Date().toISOString().slice(0, 10)}.csv`);
  };

  const exportPaymentsCSV = () => {
    const headers = ['ReceiptNo', 'CustomerID', 'CustomerName', 'PlotNo', 'Amount', 'Date', 'Method', 'TxnID', 'Status'];
    const rows = payments.map((p) => [
      p.receiptNumber,
      p.customerId,
      `"${p.customerName}"`,
      p.plotNumber,
      p.amount,
      p.paymentDate,
      p.paymentMethod,
      p.transactionId,
      p.status,
    ]);
    const csv = [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
    downloadCSV(csv, `balaji_payments_ledger_${new Date().toISOString().slice(0, 10)}.csv`);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h3 className="font-bold text-base text-slate-900">Reports & Analytics</h3>
          <p className="text-xs text-slate-500">
            Export audit-ready Excel/CSV spreadsheets and print certified collection summaries.
          </p>
        </div>

        <button
          onClick={() => window.print()}
          className="inline-flex items-center gap-1.5 px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-semibold cursor-pointer shadow-xs"
        >
          <Printer className="w-3.5 h-3.5" />
          <span>Print Financial Summary</span>
        </button>
      </div>

      {/* Export Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Customer Database Export */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center shrink-0">
              <Users className="w-6 h-6" />
            </div>
            <div>
              <h4 className="font-bold text-sm text-slate-900">Customer Roster CSV</h4>
              <p className="text-xs text-slate-500">
                All {customers.length} customer accounts with plot allotment numbers and installment tracking.
              </p>
            </div>
          </div>
          <button
            onClick={exportCustomersCSV}
            className="px-3.5 py-2 bg-slate-100 hover:bg-blue-50 hover:text-blue-700 text-slate-700 rounded-xl text-xs font-bold transition-colors flex items-center gap-1.5 cursor-pointer"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export CSV</span>
          </button>
        </div>

        {/* Payments Ledger Export */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center shrink-0">
              <CreditCard className="w-6 h-6" />
            </div>
            <div>
              <h4 className="font-bold text-sm text-slate-900">Payment Ledger CSV</h4>
              <p className="text-xs text-slate-500">
                Complete log of {payments.length} transactions including approved receipts and pending QR submissions.
              </p>
            </div>
          </div>
          <button
            onClick={exportPaymentsCSV}
            className="px-3.5 py-2 bg-slate-100 hover:bg-emerald-50 hover:text-emerald-700 text-slate-700 rounded-xl text-xs font-bold transition-colors flex items-center gap-1.5 cursor-pointer"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export CSV</span>
          </button>
        </div>
      </div>

      {/* Summary Matrix Sheet */}
      <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm text-xs">
        <h4 className="font-bold text-slate-900 uppercase tracking-wider text-xs mb-4">
          Balaji Group Key Business Indicators
        </h4>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 pb-6 border-b border-slate-100">
          <div>
            <span className="text-slate-400 block mb-0.5">Total Property Value Allotted</span>
            <span className="font-mono text-base font-extrabold text-slate-900">
              ₹{customers.reduce((acc, c) => acc + (c.totalPropertyValue || 0), 0).toLocaleString('en-IN')}
            </span>
          </div>
          <div>
            <span className="text-slate-400 block mb-0.5">Total Collections Verified</span>
            <span className="font-mono text-base font-extrabold text-emerald-600">
              ₹{totalCollections.toLocaleString('en-IN')}
            </span>
          </div>
          <div>
            <span className="text-slate-400 block mb-0.5">Receivable Balance</span>
            <span className="font-mono text-base font-extrabold text-orange-600">
              ₹{Math.max(0, customers.reduce((acc, c) => acc + (c.totalPropertyValue || 0), 0) - totalCollections).toLocaleString('en-IN')}
            </span>
          </div>
          <div>
            <span className="text-slate-400 block mb-0.5">Overall Collection Ratio</span>
            <span className="font-mono text-base font-extrabold text-blue-600">
              {Math.round((totalCollections / (customers.reduce((acc, c) => acc + (c.totalPropertyValue || 0), 0) || 1)) * 100)}%
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};
