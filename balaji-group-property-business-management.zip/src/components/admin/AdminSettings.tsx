import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Settings,
  Building,
  QrCode,
  Shield,
  Globe,
  Bell,
  CheckCircle2,
  RefreshCw,
  History,
  Save,
} from 'lucide-react';

interface AdminSettingsProps {
  onNavigateTab?: (tab: string) => void;
}

export const AdminSettings: React.FC<AdminSettingsProps> = ({ onNavigateTab }) => {
  const { settings, updateSettings, auditLogs, resetAllDataToDemo } = useApp();

  const [businessName, setBusinessName] = useState(settings.businessName);
  const [tagline, setTagline] = useState(settings.tagline);
  const [address, setAddress] = useState(settings.address);
  const [phone, setPhone] = useState(settings.phone);
  const [email, setEmail] = useState(settings.email);
  const [whatsapp, setWhatsapp] = useState(settings.whatsapp);
  const [officeHours, setOfficeHours] = useState(settings.officeHours);

  const [upiId, setUpiId] = useState(settings.upiId);
  const [qrCodeUrl, setQrCodeUrl] = useState(settings.qrCodeUrl || '');
  const [qrPaymentEnabled, setQrPaymentEnabled] = useState(settings.qrPaymentEnabled);
  const [paymentInstructions, setPaymentInstructions] = useState(settings.paymentInstructions);
  const [enableOtpLogin, setEnableOtpLogin] = useState(settings.enableOtpLogin ?? true);
  const [enablePasswordLogin, setEnablePasswordLogin] = useState(settings.enablePasswordLogin ?? true);
  const [savedSuccess, setSavedSuccess] = useState(false);

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    updateSettings({
      businessName,
      tagline,
      address,
      phone,
      email,
      whatsapp,
      officeHours,
      upiId,
      qrCodeUrl,
      qrPaymentEnabled,
      paymentInstructions,
      enableOtpLogin,
      enablePasswordLogin,
    });
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 2000);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="font-bold text-base text-slate-900">System & Business Settings</h3>
          <p className="text-xs text-slate-500">
            Configure business profile, payment UPI gateways, QR codes, and review administrative audit logs.
          </p>
        </div>

        {savedSuccess && (
          <span className="text-xs text-emerald-600 font-bold flex items-center gap-1 bg-emerald-50 px-3 py-1.5 rounded-xl border border-emerald-200">
            <CheckCircle2 className="w-4 h-4" />
            <span>Settings Saved!</span>
          </span>
        )}
      </div>

      <form onSubmit={handleSave} className="space-y-6 text-xs">
        {/* Business Information Section */}
        <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-2xs space-y-4">
          <h4 className="font-bold text-sm text-slate-900 flex items-center gap-2">
            <Building className="w-4 h-4 text-orange-600" />
            <span>Company Profile & Contact Information</span>
          </h4>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Business Name</label>
              <input
                type="text"
                value={businessName}
                onChange={(e) => setBusinessName(e.target.value)}
                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">Company Tagline</label>
              <input
                type="text"
                value={tagline}
                onChange={(e) => setTagline(e.target.value)}
                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl"
              />
            </div>

            <div className="sm:col-span-2">
              <label className="block font-semibold text-slate-700 mb-1">Registered Office Address</label>
              <input
                type="text"
                value={address}
                onChange={(e) => setAddress(e.target.value)}
                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">Official Helpline Phone</label>
              <input
                type="text"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl font-mono"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">Support Email</label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">WhatsApp Business Number</label>
              <input
                type="text"
                value={whatsapp}
                onChange={(e) => setWhatsapp(e.target.value)}
                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl font-mono"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">Office Hours</label>
              <input
                type="text"
                value={officeHours}
                onChange={(e) => setOfficeHours(e.target.value)}
                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl"
              />
            </div>
          </div>
        </div>

        {/* QR Code & Payment Gateway Configuration */}
        <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-2xs space-y-4">
          <div className="flex items-center justify-between">
            <h4 className="font-bold text-sm text-slate-900 flex items-center gap-2">
              <QrCode className="w-4 h-4 text-orange-600" />
              <span>UPI Payment & QR Code Configuration</span>
            </h4>

            <label className="flex items-center gap-2 cursor-pointer">
              <input
                type="checkbox"
                checked={qrPaymentEnabled}
                onChange={(e) => setQrPaymentEnabled(e.target.checked)}
                className="w-4 h-4 text-orange-600 rounded"
              />
              <span className="font-bold text-slate-700">Enable QR Payments for Customers</span>
            </label>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Configured UPI ID</label>
              <input
                type="text"
                value={upiId}
                onChange={(e) => setUpiId(e.target.value)}
                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl font-mono font-bold text-orange-600"
              />
              <p className="text-[11px] text-slate-400 mt-1">
                Linked to Balaji Group Current Account at ICICI Bank.
              </p>
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">Payment Instructions for Customer</label>
              <input
                type="text"
                value={paymentInstructions}
                onChange={(e) => setPaymentInstructions(e.target.value)}
                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl"
              />
            </div>

            {/* Admin QR Code URL power */}
            <div className="sm:col-span-2 pt-2 border-t border-slate-100">
              <label className="block font-semibold text-slate-700 mb-1">
                Custom QR Code Image URL (Admin Power)
              </label>
              <div className="flex gap-2">
                <input
                  type="url"
                  placeholder="https://example.com/balaji_group_upi_qr.png (leave blank for dynamic generated QR)"
                  value={qrCodeUrl}
                  onChange={(e) => setQrCodeUrl(e.target.value)}
                  className="flex-1 px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl font-mono text-xs"
                />
                {qrCodeUrl && (
                  <button
                    type="button"
                    onClick={() => setQrCodeUrl('')}
                    className="px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl font-semibold cursor-pointer"
                  >
                    Clear URL
                  </button>
                )}
              </div>
              <p className="text-[11px] text-slate-400 mt-1">
                When provided, the customer app displays your custom bank/branch QR code image directly in the Scan & Pay screen.
              </p>

              {/* QR Preview Box */}
              {qrCodeUrl && (
                <div className="mt-3 p-3 bg-slate-50 rounded-xl border border-slate-200 flex items-center gap-4">
                  <img
                    src={qrCodeUrl}
                    alt="Custom QR Preview"
                    onError={(e) => {
                      (e.target as HTMLElement).style.display = 'none';
                    }}
                    className="w-20 h-20 object-contain rounded-lg border border-slate-200 bg-white"
                  />
                  <div>
                    <span className="font-bold text-slate-900 block">Custom QR Code Active</span>
                    <span className="text-[11px] text-slate-500">
                      Customers will scan this image when paying installments.
                    </span>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Login & Authentication Settings (Enable OTP Login) */}
        <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-2xs space-y-4">
          <h4 className="font-bold text-sm text-slate-900 flex items-center gap-2">
            <Shield className="w-4 h-4 text-orange-600" />
            <span>Customer Authentication & Login Controls</span>
          </h4>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {/* Enable OTP Login Switch */}
            <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 flex items-center justify-between">
              <div>
                <span className="font-bold text-slate-900 text-xs block">Enable OTP Login</span>
                <span className="text-[11px] text-slate-500">
                  Allow customers to log in using 6-digit SMS OTP verification.
                </span>
              </div>
              <button
                type="button"
                onClick={() => setEnableOtpLogin(!enableOtpLogin)}
                className={`w-12 h-6 flex items-center rounded-full p-1 transition-colors cursor-pointer shrink-0 ${
                  enableOtpLogin ? 'bg-orange-600' : 'bg-slate-300'
                }`}
              >
                <div
                  className={`bg-white w-4 h-4 rounded-full shadow-md transform transition-transform ${
                    enableOtpLogin ? 'translate-x-6' : 'translate-x-0'
                  }`}
                ></div>
              </button>
            </div>

            {/* Enable Password/PIN Login Switch */}
            <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 flex items-center justify-between">
              <div>
                <span className="font-bold text-slate-900 text-xs block">Enable Password / PIN Login</span>
                <span className="text-[11px] text-slate-500">
                  Allow customers to log in using their secure 4-digit PIN.
                </span>
              </div>
              <button
                type="button"
                onClick={() => setEnablePasswordLogin(!enablePasswordLogin)}
                className={`w-12 h-6 flex items-center rounded-full p-1 transition-colors cursor-pointer shrink-0 ${
                  enablePasswordLogin ? 'bg-orange-600' : 'bg-slate-300'
                }`}
              >
                <div
                  className={`bg-white w-4 h-4 rounded-full shadow-md transform transition-transform ${
                    enablePasswordLogin ? 'translate-x-6' : 'translate-x-0'
                  }`}
                ></div>
              </button>
            </div>
            {/* Configure SMS Gateway Shortcut */}
            <div className="sm:col-span-2 p-4 bg-orange-50/70 rounded-2xl border border-orange-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <span className="font-bold text-orange-950 text-xs block">
                  Real-Time SMS Gateway Configuration (Fast2SMS / MSG91 / Webhook)
                </span>
                <span className="text-[11px] text-orange-800">
                  Configure real SMS carrier API keys, sender ID, DLT templates, and test live SMS delivery.
                </span>
              </div>
              {onNavigateTab && (
                <button
                  type="button"
                  onClick={() => onNavigateTab('payment_settings')}
                  className="px-4 py-2 bg-orange-600 hover:bg-orange-700 text-white rounded-xl text-xs font-bold transition-all cursor-pointer whitespace-nowrap shadow-xs"
                >
                  Open Payment & SMS Settings →
                </button>
              )}
            </div>
          </div>
        </div>

        {/* Save Button */}
        <button
          type="submit"
          className="px-6 py-3 bg-orange-600 hover:bg-orange-700 text-white font-bold rounded-xl text-xs flex items-center gap-2 cursor-pointer shadow-md shadow-orange-600/20"
        >
          <Save className="w-4 h-4" />
          <span>Save Settings Changes</span>
        </button>
      </form>

      {/* Audit Logs Section */}
      <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-2xs space-y-4">
        <div className="flex items-center justify-between pb-3 border-b border-slate-100">
          <h4 className="font-bold text-sm text-slate-900 flex items-center gap-2">
            <History className="w-4 h-4 text-orange-600" />
            <span>Administrative Audit Logs</span>
          </h4>
          <span className="text-xs text-slate-400 font-mono">{auditLogs.length} events logged</span>
        </div>

        <div className="space-y-2 text-xs">
          {auditLogs.map((log) => (
            <div
              key={log.id}
              className="p-3 bg-slate-50 rounded-xl border border-slate-200/80 flex items-start justify-between gap-3"
            >
              <div>
                <div className="flex items-center gap-2 mb-0.5">
                  <span className="font-bold text-slate-900">{log.action}</span>
                  <span className="text-[10px] bg-slate-200 text-slate-700 px-1.5 py-0.5 rounded font-medium">
                    {log.user}
                  </span>
                </div>
                <p className="text-slate-600">{log.details}</p>
              </div>
              <span className="text-[10px] text-slate-400 font-mono shrink-0 whitespace-nowrap">
                {log.timestamp}
              </span>
            </div>
          ))}
        </div>
      </div>

      {/* Reset Default Samples Action */}
      <div className="p-5 bg-slate-50 border border-slate-200 rounded-3xl flex items-center justify-between">
        <div>
          <h4 className="font-bold text-xs text-slate-900">Restore Initial Samples</h4>
          <p className="text-xs text-slate-500">
            Reset records back to initial standard customers, properties, and coupons.
          </p>
        </div>
        <button
          onClick={() => {
            if (confirm('Restore records to standard default state?')) {
              resetAllDataToDemo();
            }
          }}
          className="px-4 py-2 bg-slate-200 hover:bg-slate-300 text-slate-700 rounded-xl text-xs font-bold transition-colors cursor-pointer"
        >
          Restore Defaults
        </button>
      </div>
    </div>
  );
};
