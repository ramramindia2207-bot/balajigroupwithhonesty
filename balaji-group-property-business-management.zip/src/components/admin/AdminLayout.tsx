import React, { useState } from 'react';
import { BalajiLogo } from '../common/BalajiLogo';
import { useApp } from '../../context/AppContext';
import {
  LayoutDashboard,
  Users,
  Home,
  KeyRound,
  CreditCard,
  Tag,
  Clock,
  Headphones,
  FileSpreadsheet,
  Settings,
  LogOut,
  Smartphone,
  Shield,
  ChevronDown,
  Bell,
  Menu,
  X,
} from 'lucide-react';
import { AdminDashboard } from './AdminDashboard';
import { AdminCustomers } from './AdminCustomers';
import { AdminProperties } from './AdminProperties';
import { AdminAssignProperty } from './AdminAssignProperty';
import { AdminPayments } from './AdminPayments';
import { AdminCoupons } from './AdminCoupons';
import { AdminKists } from './AdminKists';
import { AdminSupport } from './AdminSupport';
import { AdminReports } from './AdminReports';
import { AdminSettings } from './AdminSettings';
import { AdminPaymentSettings } from './AdminPaymentSettings';
import { UserRole } from '../../types';
import { QrCode } from 'lucide-react';

export const AdminLayout: React.FC = () => {
  const {
    adminUser,
    setAdminRole,
    setAppMode,
    logoutAdmin,
    payments,
    supportTickets,
  } = useApp();

  const [activeTab, setActiveTab] = useState<string>('dashboard');
  const [mobileSidebarOpen, setMobileSidebarOpen] = useState<boolean>(false);
  const [roleDropdownOpen, setRoleDropdownOpen] = useState<boolean>(false);

  const pendingPaymentsCount = payments.filter((p) => p.status === 'Pending Verification').length;
  const openTicketsCount = supportTickets.filter((t) => t.status === 'Open').length;

  const navItems = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'customers', label: 'Customers', icon: Users },
    { id: 'properties', label: 'Properties', icon: Home },
    { id: 'assign_property', label: 'Assign Property', icon: KeyRound },
    { id: 'payments', label: 'Payments', icon: CreditCard, badge: pendingPaymentsCount },
    { id: 'payment_settings', label: 'Payment & SMS Settings', icon: QrCode },
    { id: 'coupons', label: 'Coupons', icon: Tag },
    { id: 'kists', label: 'Kist Management', icon: Clock },
    { id: 'support', label: 'Support Desk', icon: Headphones, badge: openTicketsCount },
    { id: 'reports', label: 'Reports', icon: FileSpreadsheet },
    { id: 'settings', label: 'System Settings', icon: Settings },
  ];

  const renderContent = () => {
    switch (activeTab) {
      case 'dashboard':
        return <AdminDashboard onNavigateTab={setActiveTab} />;
      case 'customers':
        return <AdminCustomers />;
      case 'properties':
        return <AdminProperties />;
      case 'assign_property':
        return <AdminAssignProperty onSuccess={() => setActiveTab('customers')} />;
      case 'payments':
        return <AdminPayments />;
      case 'payment_settings':
        return <AdminPaymentSettings />;
      case 'coupons':
        return <AdminCoupons />;
      case 'kists':
        return <AdminKists />;
      case 'support':
        return <AdminSupport />;
      case 'reports':
        return <AdminReports />;
      case 'settings':
        return <AdminSettings onNavigateTab={setActiveTab} />;
      default:
        return <AdminDashboard onNavigateTab={setActiveTab} />;
    }
  };

  return (
    <div className="min-h-screen bg-slate-100 flex flex-col md:flex-row antialiased">
      {/* Mobile Header Bar */}
      <div className="md:hidden bg-slate-900 text-white px-4 py-3 flex items-center justify-between z-30 sticky top-0">
        <div className="flex items-center gap-2">
          <button
            onClick={() => setMobileSidebarOpen(!mobileSidebarOpen)}
            className="p-1 text-slate-300 hover:text-white"
          >
            {mobileSidebarOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
          <span className="font-bold text-sm tracking-tight">Balaji Group Admin</span>
        </div>
        <button
          onClick={() => setAppMode('customer')}
          className="flex items-center gap-1.5 px-2.5 py-1 bg-orange-600 rounded-lg text-xs font-semibold text-white"
        >
          <Smartphone className="w-3.5 h-3.5" />
          <span>Customer App</span>
        </button>
      </div>

      {/* Desktop Left-Side Navigation Sidebar (Matching Wireframe Center) */}
      <aside
        className={`fixed md:sticky top-0 left-0 h-screen w-64 bg-slate-900 text-slate-300 flex flex-col justify-between z-40 transition-transform duration-200 shrink-0 ${
          mobileSidebarOpen ? 'translate-x-0' : '-translate-x-full md:translate-x-0'
        }`}
      >
        <div>
          {/* Top Brand Lockup: Balaji Group Admin */}
          <div className="p-5 border-b border-slate-800">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-lg bg-orange-600 flex items-center justify-center shrink-0">
                <svg viewBox="0 0 48 48" fill="none" className="w-5 h-5 text-white">
                  <path d="M24 6L5 22H11L24 10.5L37 22H43L24 6Z" fill="#FFFFFF" />
                  <path d="M13 23V41H35V23L24 13.5L13 23Z" stroke="#FFFFFF" strokeWidth="3" strokeLinejoin="round" />
                </svg>
              </div>
              <div className="flex flex-col leading-none">
                <span className="text-base font-extrabold text-white tracking-wide uppercase font-heading">
                  BALAJI <span className="text-orange-500">GROUP</span>
                </span>
                <span className="text-[10px] text-slate-400 font-semibold uppercase tracking-wider mt-0.5">
                  Admin Portal
                </span>
              </div>
            </div>
          </div>

          {/* Navigation Links List */}
          <nav className="p-3 space-y-1 overflow-y-auto max-h-[calc(100vh-210px)] text-xs">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = activeTab === item.id;

              return (
                <button
                  key={item.id}
                  onClick={() => {
                    setActiveTab(item.id);
                    setMobileSidebarOpen(false);
                  }}
                  className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl font-semibold transition-all cursor-pointer ${
                    isActive
                      ? 'bg-orange-600 text-white shadow-md shadow-orange-600/20'
                      : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <Icon className="w-4 h-4 shrink-0" />
                    <span>{item.label}</span>
                  </div>

                  {item.badge !== undefined && item.badge > 0 && (
                    <span
                      className={`text-[10px] font-bold px-1.5 py-0.2 rounded-full ${
                        isActive ? 'bg-white text-orange-600' : 'bg-orange-500 text-white'
                      }`}
                    >
                      {item.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </nav>
        </div>

        {/* Sidebar Bottom Footer: Switch to Customer App & User Profile */}
        <div className="p-3 border-t border-slate-800 space-y-2">
          {/* Switch to Customer App Button */}
          <button
            onClick={() => setAppMode('customer')}
            className="w-full py-2.5 px-3 bg-slate-800 hover:bg-slate-700/80 text-orange-400 font-semibold rounded-xl text-xs flex items-center justify-center gap-2 transition-colors cursor-pointer border border-slate-700/50"
          >
            <Smartphone className="w-4 h-4" />
            <span>Open Customer App</span>
          </button>

          {/* Admin User Profile */}
          <div className="p-2.5 rounded-xl bg-slate-800/40 flex items-center justify-between">
            <div className="flex items-center gap-2.5 min-w-0">
              <div className="w-7 h-7 rounded-lg bg-orange-600 text-white text-xs font-bold flex items-center justify-center shrink-0">
                {adminUser.name.charAt(0)}
              </div>
              <div className="min-w-0">
                <span className="text-xs font-bold text-white block truncate">
                  {adminUser.name}
                </span>
                <span className="text-[10px] text-slate-400 uppercase font-mono block">
                  {adminUser.role.replace('_', ' ')}
                </span>
              </div>
            </div>

            <button
              onClick={logoutAdmin}
              className="p-1 text-slate-400 hover:text-rose-400 cursor-pointer"
              title="Logout Admin"
            >
              <LogOut className="w-4 h-4" />
            </button>
          </div>
        </div>
      </aside>

      {/* Main Content Viewport */}
      <main className="flex-1 flex flex-col min-w-0">
        {/* Desktop Top Header Bar */}
        <header className="hidden md:flex h-16 bg-white border-b border-slate-200 px-6 items-center justify-between sticky top-0 z-30 shadow-2xs">
          <div className="flex items-center gap-2 text-xs">
            <span className="font-semibold text-slate-400">Admin</span>
            <span className="text-slate-300">/</span>
            <span className="font-bold text-slate-900 capitalize">
              {activeTab.replace('_', ' ')}
            </span>
          </div>

          <div className="flex items-center gap-4">
            {/* Quick Role Selector for testing permissions */}
            <div className="relative">
              <button
                onClick={() => setRoleDropdownOpen(!roleDropdownOpen)}
                className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded-xl text-xs font-bold text-slate-800 cursor-pointer"
              >
                <Shield className="w-3.5 h-3.5 text-orange-600" />
                <span className="capitalize">{adminUser.role.replace('_', ' ')}</span>
                <ChevronDown className="w-3 h-3 text-slate-400" />
              </button>

              {roleDropdownOpen && (
                <div className="absolute right-0 mt-2 w-44 bg-white rounded-xl shadow-xl border border-slate-200 py-1 z-50 text-xs">
                  <span className="px-3 py-1.5 text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
                    Switch Test Role
                  </span>
                  {(['super_admin', 'admin', 'staff'] as UserRole[]).map((r) => (
                    <button
                      key={r}
                      onClick={() => {
                        setAdminRole(r);
                        setRoleDropdownOpen(false);
                      }}
                      className={`w-full text-left px-3 py-2 font-medium hover:bg-slate-50 capitalize cursor-pointer ${
                        adminUser.role === r ? 'text-orange-600 font-bold' : 'text-slate-700'
                      }`}
                    >
                      {r.replace('_', ' ')}
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Switch to Customer App */}
            <button
              onClick={() => setAppMode('customer')}
              className="flex items-center gap-1.5 px-3.5 py-1.5 bg-orange-50 hover:bg-orange-100 text-orange-700 border border-orange-200 rounded-xl text-xs font-bold transition-colors cursor-pointer"
            >
              <Smartphone className="w-3.5 h-3.5" />
              <span>Preview Customer App</span>
            </button>
          </div>
        </header>

        {/* Tab Page Container */}
        <div className="flex-1 p-4 sm:p-6 lg:p-8 max-w-7xl w-full mx-auto">
          {renderContent()}
        </div>
      </main>
    </div>
  );
};
