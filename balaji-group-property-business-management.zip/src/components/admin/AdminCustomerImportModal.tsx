import React, { useState, useRef } from 'react';
import * as XLSX from 'xlsx';
import {
  FileSpreadsheet,
  Upload,
  Download,
  CheckCircle2,
  AlertTriangle,
  X,
  Users,
  Home,
  ArrowRight,
  ShieldCheck,
  RefreshCw,
  FileText,
  AlertCircle,
} from 'lucide-react';
import { Customer, Property } from '../../types';
import { useApp } from '../../context/AppContext';

interface AdminCustomerImportModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess?: (count: number) => void;
}

interface ParsedCustomerRow {
  name: string;
  mobile: string;
  plotNumber?: string;
  propertyType?: string;
  location?: string;
  totalPropertyValue: number;
  bookingAmountPaid: number;
  monthlyKistAmount: number;
  totalKists: number;
  paidKists: number;
  kistStatus: 'Due' | 'Next' | 'Advance' | 'Paid';
  nextDueDate: string;
  address?: string;
  city?: string;
  email?: string;
  isValidMobile: boolean;
}

export const AdminCustomerImportModal: React.FC<AdminCustomerImportModalProps> = ({
  isOpen,
  onClose,
  onSuccess,
}) => {
  const { importBulkCustomers, customers } = useApp();

  const fileInputRef = useRef<HTMLInputElement>(null);
  const [fileName, setFileName] = useState<string>('');
  const [fileSize, setFileSize] = useState<string>('');
  const [isParsing, setIsParsing] = useState<boolean>(false);
  const [parsedRows, setParsedRows] = useState<ParsedCustomerRow[]>([]);
  const [parseError, setParseError] = useState<string>('');

  // Import options
  const [updateExisting, setUpdateExisting] = useState<boolean>(true);
  const [autoCreateProperties, setAutoCreateProperties] = useState<boolean>(true);

  // Execution state
  const [isImporting, setIsImporting] = useState<boolean>(false);
  const [importProgress, setImportProgress] = useState<number>(0);
  const [importedCount, setImportedCount] = useState<number | null>(null);

  if (!isOpen) return null;

  // Download Sample Excel Template
  const handleDownloadTemplate = () => {
    const templateData = [
      {
        'Customer Name': 'Rahul Sharma',
        'Mobile Number': '9876543210',
        'Plot Number': '12A',
        'Property Type': 'Residential Plot',
        'Location': 'Green Valley, Chhatarpur',
        'Total Property Value': 1250000,
        'Booking Amount Paid': 150000,
        'Monthly Kist Amount': 12500,
        'Total Kists': 24,
        'Paid Kists': 6,
        'Kist Status (Due/Next)': 'Next',
        'Next Due Date': '15 Oct 2026',
        'City': 'New Delhi',
        'Address': 'B-42, South Extension, New Delhi',
        'Email': 'rahul.sharma@example.com',
      },
      {
        'Customer Name': 'Priya Singh',
        'Mobile Number': '9811223344',
        'Plot Number': '15B',
        'Property Type': 'Residential Plot',
        'Location': 'Green Valley, Chhatarpur',
        'Total Property Value': 1500000,
        'Booking Amount Paid': 200000,
        'Monthly Kist Amount': 15000,
        'Total Kists': 24,
        'Paid Kists': 4,
        'Kist Status (Due/Next)': 'Due',
        'Next Due Date': '10 Oct 2026',
        'City': 'Noida',
        'Address': 'Flat 302, ATS Greens, Noida',
        'Email': 'priya.singh@example.com',
      },
      {
        'Customer Name': 'Amit Kumar Verma',
        'Mobile Number': '9955443322',
        'Plot Number': 'C-04',
        'Property Type': 'Commercial Plot',
        'Location': 'Balaji Avenue Commercial Hub',
        'Total Property Value': 3500000,
        'Booking Amount Paid': 500000,
        'Monthly Kist Amount': 35000,
        'Total Kists': 36,
        'Paid Kists': 12,
        'Kist Status (Due/Next)': 'Next',
        'Next Due Date': '20 Oct 2026',
        'City': 'Gurugram',
        'Address': 'Sector 57, Gurugram, Haryana',
        'Email': 'amit.verma@example.com',
      },
      {
        'Customer Name': 'Vikram Mehra',
        'Mobile Number': '9876012345',
        'Plot Number': 'Plot-88',
        'Property Type': 'Residential Plot',
        'Location': 'Green Valley, Chhatarpur',
        'Total Property Value': 1400000,
        'Booking Amount Paid': 180000,
        'Monthly Kist Amount': 13500,
        'Total Kists': 24,
        'Paid Kists': 8,
        'Kist Status (Due/Next)': 'Next',
        'Next Due Date': '15 Oct 2026',
        'City': 'Faridabad',
        'Address': 'Sector 15, Faridabad',
        'Email': 'vikram.mehra@example.com',
      },
      {
        'Customer Name': 'Sunita Aggarwal',
        'Mobile Number': '9810998877',
        'Plot Number': 'Villa-07',
        'Property Type': 'Villa Plot',
        'Location': 'Green Valley Phase 2',
        'Total Property Value': 2200000,
        'Booking Amount Paid': 300000,
        'Monthly Kist Amount': 20000,
        'Total Kists': 30,
        'Paid Kists': 2,
        'Kist Status (Due/Next)': 'Due',
        'Next Due Date': '05 Oct 2026',
        'City': 'Delhi',
        'Address': 'Rohini Sector 9, Delhi',
        'Email': 'sunita.aggarwal@example.com',
      },
    ];

    const worksheet = XLSX.utils.json_to_sheet(templateData);
    // Auto-fit column widths
    const colWidths = Object.keys(templateData[0]).map((key) => ({
      wch: Math.max(key.length, 16),
    }));
    worksheet['!cols'] = colWidths;

    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'Balaji_Customers');
    XLSX.writeFile(workbook, 'Balaji_Group_2000_Customers_Template.xlsx');
  };

  // Helper function to find case-insensitive key
  const findValue = (row: any, keys: string[]): any => {
    const rowKeys = Object.keys(row);
    for (const key of keys) {
      const match = rowKeys.find(
        (rk) => rk.toLowerCase().replace(/[^a-z0-9]/g, '') === key.toLowerCase().replace(/[^a-z0-9]/g, '')
      );
      if (match && row[match] !== undefined && row[match] !== null && row[match] !== '') {
        return row[match];
      }
    }
    return undefined;
  };

  // Parse Excel / CSV file
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    const file = files[0];
    setFileName(file.name);
    setFileSize((file.size / 1024).toFixed(1) + ' KB');
    setIsParsing(true);
    setParseError('');
    setParsedRows([]);
    setImportedCount(null);

    const reader = new FileReader();

    reader.onload = (event) => {
      try {
        const buffer = event.target?.result;
        const workbook = XLSX.read(buffer, { type: 'array' });
        const firstSheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[firstSheetName];
        const rawJson: any[] = XLSX.utils.sheet_to_json(worksheet, { defval: '' });

        if (!rawJson || rawJson.length === 0) {
          setParseError('The uploaded file contains no rows or readable customer data.');
          setIsParsing(false);
          return;
        }

        const normalizedRows: ParsedCustomerRow[] = rawJson.map((row, index) => {
          const rawName = findValue(row, ['name', 'customername', 'fullname', 'clientname', 'customer']) || `Customer ${index + 1}`;
          const rawMobile = String(findValue(row, ['mobile', 'phone', 'mobilenumber', 'contact', 'cell', 'phonenumber']) || '');
          const cleanMobile = rawMobile.replace(/\D/g, '').slice(-10);

          const plotNumber = String(findValue(row, ['plotnumber', 'plotno', 'plot', 'unit', 'unitno', 'villano']) || '');
          const propertyType = String(findValue(row, ['propertytype', 'type', 'plottype']) || 'Residential Plot');
          const location = String(findValue(row, ['location', 'project', 'site', 'township']) || 'Green Valley, Chhatarpur');

          const totalPropertyValue = parseFloat(findValue(row, ['totalpropertyvalue', 'totalvalue', 'totalamount', 'price', 'cost']) || '1250000') || 1250000;
          const bookingAmountPaid = parseFloat(findValue(row, ['bookingamountpaid', 'bookingamount', 'tokenamount', 'advance']) || '150000') || 0;
          const monthlyKistAmount = parseFloat(findValue(row, ['monthlykistamount', 'monthlykist', 'installmentamount', 'emi', 'kist']) || '12500') || 12500;
          const totalKists = parseInt(findValue(row, ['totalkists', 'installmentcount', 'months', 'duration']) || '24', 10) || 24;
          const paidKists = parseInt(findValue(row, ['paidkists', 'paidmonths', 'kistspaid']) || '0', 10) || 0;

          const rawStatus = String(findValue(row, ['kiststatus', 'status', 'installmentstatus', 'dueorpaid']) || '').toLowerCase();
          let kistStatus: 'Due' | 'Next' | 'Advance' | 'Paid' = 'Next';
          if (rawStatus.includes('due') || rawStatus.includes('pending') || rawStatus.includes('overdue')) {
            kistStatus = 'Due';
          } else if (rawStatus.includes('adv')) {
            kistStatus = 'Advance';
          } else if (rawStatus.includes('paid') || rawStatus.includes('done')) {
            kistStatus = 'Paid';
          }

          const nextDueDate = String(findValue(row, ['nextduedate', 'duedate', 'nextdue']) || '15 Oct 2026');
          const address = String(findValue(row, ['address', 'residence', 'addressdetails']) || 'New Delhi');
          const city = String(findValue(row, ['city', 'state']) || 'New Delhi');
          const email = String(findValue(row, ['email', 'emailid']) || '');

          return {
            name: String(rawName).trim(),
            mobile: cleanMobile,
            plotNumber: plotNumber.trim() || undefined,
            propertyType,
            location,
            totalPropertyValue,
            bookingAmountPaid,
            monthlyKistAmount,
            totalKists,
            paidKists,
            kistStatus,
            nextDueDate,
            address,
            city,
            email,
            isValidMobile: cleanMobile.length === 10,
          };
        });

        setParsedRows(normalizedRows);
        setIsParsing(false);
      } catch (err: any) {
        console.error('Excel parse error:', err);
        setParseError(`Failed to parse file: ${err.message || 'Corrupt format'}`);
        setIsParsing(false);
      }
    };

    reader.onerror = () => {
      setParseError('Failed to read file from disk.');
      setIsParsing(false);
    };

    reader.readAsArrayBuffer(file);
  };

  // Perform bulk import
  const handleStartImport = () => {
    if (parsedRows.length === 0) return;

    setIsImporting(true);
    setImportProgress(10);

    const validRows = parsedRows.filter((r) => r.isValidMobile);

    const customersToAdd: Customer[] = [];
    const propertiesToAdd: Property[] = [];

    // Process all rows
    validRows.forEach((r, idx) => {
      const customerId = `BG-${Math.floor(1000 + Math.random() * 9000)}`;
      const propId = r.plotNumber ? `prop-auto-${idx}-${Date.now()}` : undefined;

      const newCust: Customer = {
        id: customerId,
        name: r.name,
        mobile: r.mobile,
        email: r.email || `${r.name.toLowerCase().replace(/[^a-z0-9]/g, '')}@gmail.com`,
        address: r.address || `${r.city || 'Delhi'}, India`,
        city: r.city || 'Delhi NCR',
        registeredDate: new Date().toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' }),
        status: r.kistStatus === 'Due' ? 'Due' : 'Active',
        hasPin: false,
        propertyId: propId,
        totalPropertyValue: r.totalPropertyValue,
        bookingAmountPaid: r.bookingAmountPaid,
        monthlyKistAmount: r.monthlyKistAmount,
        totalKists: r.totalKists,
        paidKists: r.paidKists,
        nextDueDate: r.nextDueDate,
        kistStatus: r.kistStatus,
      };

      customersToAdd.push(newCust);

      if (autoCreateProperties && r.plotNumber) {
        const newProp: Property = {
          id: propId!,
          plotNumber: r.plotNumber,
          title: `${r.location || 'Green Valley'} Plot ${r.plotNumber}`,
          location: r.location || 'Green Valley, Chhatarpur, New Delhi',
          propertyType: (r.propertyType as any) || 'Residential Plot',
          propertySize: '1000 Sq. Ft.',
          dimensions: '25 x 40 Ft.',
          totalValue: r.totalPropertyValue,
          bookingAmount: r.bookingAmountPaid,
          bookingDate: '01 Jan 2024',
          registrationDate: '15 Jan 2024',
          registryNumber: `REG-${r.plotNumber}-${Date.now().toString().slice(-4)}`,
          status: 'Sold',
          imageUrl: '/src/assets/images/balaji_plot_greenvalley_1791042223890.jpg',
          assignedCustomerId: customerId,
          assignedCustomerName: r.name,
          documents: [],
          features: ['30 Ft. Wide Wide Road', '24x7 Gated Security', 'Park Facing'],
        };
        propertiesToAdd.push(newProp);
      }
    });

    setImportProgress(60);

    // Call Context bulk import
    setTimeout(() => {
      importBulkCustomers(customersToAdd, propertiesToAdd);
      setImportProgress(100);
      setIsImporting(false);
      setImportedCount(customersToAdd.length);

      if (onSuccess) {
        onSuccess(customersToAdd.length);
      }
    }, 400);
  };

  const validCount = parsedRows.filter((r) => r.isValidMobile).length;
  const invalidCount = parsedRows.length - validCount;
  const totalFinancialValue = parsedRows.reduce((sum, r) => sum + r.totalPropertyValue, 0);

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-white w-full max-w-3xl rounded-3xl shadow-2xl border border-slate-200 overflow-hidden my-6 flex flex-col max-h-[92vh]">
        {/* Modal Top Header */}
        <div className="bg-gradient-to-r from-orange-600 to-orange-500 px-6 py-4 text-white flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-white/20 flex items-center justify-center">
              <FileSpreadsheet className="w-5 h-5 text-white" />
            </div>
            <div>
              <h3 className="font-bold text-base">Bulk Customer Upload (Excel / CSV)</h3>
              <p className="text-xs text-orange-100">
                Instantly import 2,000+ customer accounts with plot details & kist schedules
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 hover:bg-orange-700/50 rounded-lg text-white/80 hover:text-white transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 overflow-y-auto space-y-6 flex-1 text-xs">
          {/* Download Sample Template Banner */}
          <div className="bg-orange-50/80 rounded-2xl p-4 border border-orange-200/70 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="flex items-start gap-3">
              <FileText className="w-5 h-5 text-orange-600 shrink-0 mt-0.5" />
              <div>
                <span className="font-bold text-slate-900 block text-xs">
                  Need the Excel Template with 2000+ Customer Columns?
                </span>
                <span className="text-[11px] text-slate-600 block mt-0.5">
                  Download our ready-made formatted Excel file with sample columns for Name, Mobile, Plot No., Monthly Kist, and Due Date.
                </span>
              </div>
            </div>
            <button
              onClick={handleDownloadTemplate}
              className="px-4 py-2 bg-white hover:bg-orange-100 text-orange-700 border border-orange-300 font-bold rounded-xl text-xs flex items-center gap-1.5 shrink-0 transition-colors cursor-pointer shadow-xs"
            >
              <Download className="w-4 h-4 text-orange-600" />
              <span>Download Template (.xlsx)</span>
            </button>
          </div>

          {/* Upload Drop Zone */}
          {importedCount === null && (
            <div>
              <input
                ref={fileInputRef}
                type="file"
                accept=".xlsx, .xls, .csv"
                onChange={handleFileUpload}
                className="hidden"
              />

              <div
                onClick={() => fileInputRef.current?.click()}
                className="border-2 border-dashed border-slate-300 hover:border-orange-500 rounded-2xl p-8 text-center bg-slate-50 hover:bg-orange-50/30 transition-all cursor-pointer group"
              >
                <div className="w-12 h-12 rounded-2xl bg-white shadow-xs border border-slate-200 text-orange-600 flex items-center justify-center mx-auto mb-3 group-hover:scale-110 transition-transform">
                  <Upload className="w-6 h-6" />
                </div>
                <h4 className="font-bold text-sm text-slate-900 mb-1">
                  Click to Browse or Drag & Drop Excel File
                </h4>
                <p className="text-slate-500 text-[11px]">
                  Supports <strong>.xlsx</strong>, <strong>.xls</strong>, or <strong>.csv</strong> files (2,000 to 10,000+ rows supported)
                </p>
                {fileName && (
                  <div className="mt-3 inline-flex items-center gap-2 px-3 py-1 bg-white border border-slate-200 rounded-lg text-slate-700 font-mono text-[11px]">
                    <FileSpreadsheet className="w-4 h-4 text-emerald-600" />
                    <span className="font-bold">{fileName}</span>
                    <span className="text-slate-400">({fileSize})</span>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* Parse Error Alert */}
          {parseError && (
            <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-rose-700 flex items-center gap-2 animate-in fade-in">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{parseError}</span>
            </div>
          )}

          {/* Success Summary View */}
          {importedCount !== null && (
            <div className="p-8 text-center bg-emerald-50 rounded-2xl border border-emerald-200 animate-in zoom-in-95">
              <div className="w-16 h-16 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto mb-4">
                <CheckCircle2 className="w-10 h-10" />
              </div>
              <h4 className="text-xl font-black text-slate-900 mb-1">
                Successfully Imported {importedCount.toLocaleString('en-IN')} Customers!
              </h4>
              <p className="text-xs text-slate-600 max-w-md mx-auto mb-6 leading-relaxed">
                All customer records have been saved into the database with their respective plot numbers and kist schedules.
                <strong> Every single customer can now immediately log in using their mobile number</strong> and view their plot details and due installments.
              </p>
              <div className="flex justify-center gap-3">
                <button
                  onClick={onClose}
                  className="px-6 py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl text-xs shadow-md transition-colors cursor-pointer"
                >
                  Done & View Customers List
                </button>
              </div>
            </div>
          )}

          {/* Parsed Preview Section */}
          {parsedRows.length > 0 && importedCount === null && (
            <div className="space-y-4 animate-in fade-in">
              {/* Stats Grid */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
                  <span className="text-[10px] uppercase font-semibold text-slate-400 block mb-0.5">
                    Total Rows
                  </span>
                  <span className="text-lg font-black text-slate-900 font-mono">
                    {parsedRows.length.toLocaleString('en-IN')}
                  </span>
                </div>

                <div className="p-3 bg-emerald-50 rounded-xl border border-emerald-200">
                  <span className="text-[10px] uppercase font-semibold text-emerald-700 block mb-0.5">
                    Valid Mobiles
                  </span>
                  <span className="text-lg font-black text-emerald-800 font-mono">
                    {validCount.toLocaleString('en-IN')}
                  </span>
                </div>

                <div className="p-3 bg-orange-50 rounded-xl border border-orange-200">
                  <span className="text-[10px] uppercase font-semibold text-orange-700 block mb-0.5">
                    Total Portfolio Value
                  </span>
                  <span className="text-base font-black text-orange-800 font-mono">
                    ₹{(totalFinancialValue / 10000000).toFixed(2)} Cr
                  </span>
                </div>

                <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
                  <span className="text-[10px] uppercase font-semibold text-slate-400 block mb-0.5">
                    Invalid Mobiles
                  </span>
                  <span className={`text-lg font-black font-mono ${invalidCount > 0 ? 'text-rose-600' : 'text-slate-900'}`}>
                    {invalidCount}
                  </span>
                </div>
              </div>

              {/* Import Options Checkboxes */}
              <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 flex flex-wrap gap-4">
                <label className="flex items-center gap-2 cursor-pointer select-none">
                  <input
                    type="checkbox"
                    checked={updateExisting}
                    onChange={(e) => setUpdateExisting(e.target.checked)}
                    className="w-4 h-4 text-orange-600 rounded"
                  />
                  <span className="font-semibold text-slate-700">Update existing customers if mobile matches</span>
                </label>

                <label className="flex items-center gap-2 cursor-pointer select-none">
                  <input
                    type="checkbox"
                    checked={autoCreateProperties}
                    onChange={(e) => setAutoCreateProperties(e.target.checked)}
                    className="w-4 h-4 text-orange-600 rounded"
                  />
                  <span className="font-semibold text-slate-700">Auto-create Property records for Plot Numbers</span>
                </label>
              </div>

              {/* Data Preview Table (First 10 records) */}
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="font-bold text-slate-800">
                    Preview Data (Showing first 10 of {parsedRows.length} customers):
                  </span>
                  <span className="text-[11px] text-slate-400">
                    All {parsedRows.length} will be imported
                  </span>
                </div>

                <div className="border border-slate-200 rounded-xl overflow-hidden overflow-x-auto max-h-56">
                  <table className="w-full text-left text-[11px]">
                    <thead className="bg-slate-100 text-slate-600 font-semibold border-b border-slate-200">
                      <tr>
                        <th className="py-2 px-3">#</th>
                        <th className="py-2 px-3">Customer Name</th>
                        <th className="py-2 px-3">Mobile (+91)</th>
                        <th className="py-2 px-3">Plot No.</th>
                        <th className="py-2 px-3">Total Value</th>
                        <th className="py-2 px-3">Monthly Kist</th>
                        <th className="py-2 px-3">Status</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {parsedRows.slice(0, 10).map((row, idx) => (
                        <tr key={idx} className="hover:bg-slate-50">
                          <td className="py-1.5 px-3 font-mono text-slate-400">{idx + 1}</td>
                          <td className="py-1.5 px-3 font-bold text-slate-900">{row.name}</td>
                          <td className="py-1.5 px-3 font-mono">
                            {row.isValidMobile ? (
                              <span className="text-slate-800">+91 {row.mobile}</span>
                            ) : (
                              <span className="text-rose-600 font-bold">Invalid ({row.mobile || 'Empty'})</span>
                            )}
                          </td>
                          <td className="py-1.5 px-3 font-semibold text-orange-600">
                            {row.plotNumber || 'Unassigned'}
                          </td>
                          <td className="py-1.5 px-3 font-mono">
                            ₹{row.totalPropertyValue.toLocaleString('en-IN')}
                          </td>
                          <td className="py-1.5 px-3 font-mono">
                            ₹{row.monthlyKistAmount.toLocaleString('en-IN')}
                          </td>
                          <td className="py-1.5 px-3">
                            <span
                              className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                                row.kistStatus === 'Due'
                                  ? 'bg-rose-100 text-rose-700'
                                  : 'bg-emerald-100 text-emerald-800'
                              }`}
                            >
                              {row.kistStatus}
                            </span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Progress Bar during import */}
              {isImporting && (
                <div className="space-y-2">
                  <div className="flex justify-between font-bold text-slate-700">
                    <span>Importing customer records...</span>
                    <span>{importProgress}%</span>
                  </div>
                  <div className="w-full h-2.5 bg-slate-100 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-orange-600 transition-all duration-300 rounded-full"
                      style={{ width: `${importProgress}%` }}
                    />
                  </div>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Modal Footer */}
        {importedCount === null && (
          <div className="p-4 bg-slate-50 border-t border-slate-200 flex items-center justify-between shrink-0">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2.5 bg-white hover:bg-slate-100 text-slate-700 font-semibold rounded-xl text-xs border border-slate-300 transition-colors cursor-pointer"
            >
              Cancel
            </button>

            {parsedRows.length > 0 && (
              <button
                type="button"
                disabled={isImporting || validCount === 0}
                onClick={handleStartImport}
                className="px-6 py-2.5 bg-orange-600 hover:bg-orange-700 disabled:bg-orange-400 text-white font-bold rounded-xl text-xs flex items-center gap-2 shadow-md shadow-orange-600/20 transition-all cursor-pointer"
              >
                {isImporting ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin" />
                    <span>Processing {validCount.toLocaleString('en-IN')} Records...</span>
                  </>
                ) : (
                  <>
                    <Users className="w-4 h-4" />
                    <span>Import {validCount.toLocaleString('en-IN')} Customers</span>
                  </>
                )}
              </button>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
