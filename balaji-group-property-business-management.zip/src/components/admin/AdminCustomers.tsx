import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Users,
  Search,
  Plus,
  Filter,
  MoreVertical,
  KeyRound,
  ShieldAlert,
  ShieldCheck,
  Trash2,
  Edit,
  Eye,
  X,
  Phone,
  Mail,
  MapPin,
  CheckCircle2,
  FileSpreadsheet,
  ChevronLeft,
  ChevronRight,
} from 'lucide-react';
import { Customer } from '../../types';
import { AdminCustomerImportModal } from './AdminCustomerImportModal';

export const AdminCustomers: React.FC = () => {
  const {
    customers,
    properties,
    payments,
    addCustomer,
    updateCustomer,
    deleteCustomer,
    resetCustomerPin,
  } = useApp();

  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('All');
  const [showAddModal, setShowAddModal] = useState(false);
  const [showImportModal, setShowImportModal] = useState(false);
  const [selectedCustomer, setSelectedCustomer] = useState<Customer | null>(null);
  const [currentPage, setCurrentPage] = useState<number>(1);
  const pageSize = 25;

  // New Customer Form State
  const [name, setName] = useState('');
  const [mobile, setMobile] = useState('');
  const [email, setEmail] = useState('');
  const [address, setAddress] = useState('');
  const [city, setCity] = useState('New Delhi');
  const [totalValue, setTotalValue] = useState(1500000);
  const [bookingAmount, setBookingAmount] = useState(200000);
  const [monthlyKist, setMonthlyKist] = useState(15000);
  const [totalKists, setTotalKists] = useState(24);
  const [paidKists, setPaidKists] = useState(1);
  const [selectedPropertyId, setSelectedPropertyId] = useState('');

  const filteredCustomers = customers.filter((c) => {
    const matchesSearch =
      c.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      c.mobile.includes(searchTerm) ||
      c.id.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === 'All' || c.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const totalPages = Math.max(1, Math.ceil(filteredCustomers.length / pageSize));
  const paginatedCustomers = filteredCustomers.slice(
    (currentPage - 1) * pageSize,
    currentPage * pageSize
  );

  const handleCreateCustomer = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !mobile.trim()) {
      alert('Please fill customer name and 10-digit mobile number.');
      return;
    }

    addCustomer({
      name: name.trim(),
      mobile: mobile.replace(/\D/g, '').slice(-10),
      email: email.trim() || `${name.toLowerCase().replace(/\s+/g, '')}@gmail.com`,
      address: address.trim() || 'Chhatarpur, New Delhi',
      city: city.trim(),
      registeredDate: new Date().toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' }),
      status: 'Active',
      hasPin: false,
      propertyId: selectedPropertyId || undefined,
      totalPropertyValue: totalValue,
      bookingAmountPaid: bookingAmount,
      monthlyKistAmount: monthlyKist,
      totalKists,
      paidKists,
      nextDueDate: '15 Nov 2026',
    });

    setShowAddModal(false);
    // Reset form
    setName('');
    setMobile('');
    setEmail('');
    setAddress('');
  };

  return (
    <div className="space-y-5">
      {/* Top Header & Search Bar */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
        <div className="flex-1 flex items-center gap-3">
          <div className="relative flex-1 max-w-md">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
            <input
              type="text"
              placeholder="Search by Name, Mobile (+91), or Customer ID..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2.5 bg-white border border-slate-200 rounded-xl text-xs focus:ring-2 focus:ring-orange-500 shadow-2xs"
            />
          </div>

          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="px-3 py-2.5 bg-white border border-slate-200 rounded-xl text-xs text-slate-700 shadow-2xs cursor-pointer"
          >
            <option value="All">All Statuses</option>
            <option value="Active">Active</option>
            <option value="Due">Due / Overdue</option>
            <option value="Pending Approval">Pending Approval</option>
            <option value="Suspended">Suspended</option>
          </select>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setShowImportModal(true)}
            className="px-4 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold transition-colors flex items-center justify-center gap-1.5 cursor-pointer shadow-sm"
          >
            <FileSpreadsheet className="w-4 h-4" />
            <span>Upload Excel File (2000+ Customers)</span>
          </button>

          <button
            onClick={() => setShowAddModal(true)}
            className="px-4 py-2.5 bg-orange-600 hover:bg-orange-700 text-white rounded-xl text-xs font-bold transition-colors flex items-center justify-center gap-1.5 cursor-pointer shadow-sm"
          >
            <Plus className="w-4 h-4" />
            <span>Add New Customer</span>
          </button>
        </div>
      </div>

      {/* Customer Data Table */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-2xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-slate-500 font-semibold border-b border-slate-200">
              <tr>
                <th className="py-3 px-4">Customer Info</th>
                <th className="py-3 px-3">Contact</th>
                <th className="py-3 px-3">Allotted Plot</th>
                <th className="py-3 px-3">Kist Progress</th>
                <th className="py-3 px-3">Next Due</th>
                <th className="py-3 px-3">Status</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredCustomers.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-8 text-center text-slate-400">
                    No customers found matching your search.
                  </td>
                </tr>
              ) : (
                paginatedCustomers.map((cust) => {
                  const prop = properties.find((p) => p.id === cust.propertyId);
                  const isDue = cust.status === 'Due';

                  return (
                    <tr key={cust.id} className="hover:bg-slate-50/70 transition-colors">
                      <td className="py-3 px-4">
                        <div className="font-bold text-slate-900">{cust.name}</div>
                        <div className="font-mono text-[11px] text-orange-600">{cust.id}</div>
                      </td>

                      <td className="py-3 px-3 font-mono text-slate-600">
                        <div>+91 {cust.mobile}</div>
                        <div className="text-[10px] text-slate-400 font-sans truncate max-w-[130px]">
                          {cust.email}
                        </div>
                      </td>

                      <td className="py-3 px-3">
                        {prop ? (
                          <div>
                            <span className="font-bold text-slate-800">Plot {prop.plotNumber}</span>
                            <span className="block text-[10px] text-slate-400 truncate max-w-[120px]">
                              {prop.location}
                            </span>
                          </div>
                        ) : (
                          <span className="text-slate-400 italic">Unassigned</span>
                        )}
                      </td>

                      <td className="py-3 px-3">
                        <div className="font-mono font-semibold text-slate-800">
                          {cust.paidKists} / {cust.totalKists} Kists
                        </div>
                        <div className="w-24 bg-slate-100 h-1.5 rounded-full overflow-hidden mt-1">
                          <div
                            className="bg-orange-600 h-full rounded-full"
                            style={{
                              width: `${Math.min(100, ((cust.paidKists || 0) / (cust.totalKists || 1)) * 100)}%`,
                            }}
                          ></div>
                        </div>
                      </td>

                      <td className="py-3 px-3 font-mono text-[11px] text-slate-600">
                        {cust.nextDueDate}
                      </td>

                      <td className="py-3 px-3">
                        <span
                          className={`px-2 py-0.5 rounded-full text-[10px] font-bold uppercase ${
                            cust.status === 'Active'
                              ? 'bg-emerald-100 text-emerald-800'
                              : isDue
                              ? 'bg-rose-100 text-rose-800'
                              : 'bg-amber-100 text-amber-800'
                          }`}
                        >
                          {cust.status}
                        </span>
                      </td>

                      <td className="py-3 px-4 text-right">
                        <div className="flex items-center justify-end gap-1">
                          <button
                            onClick={() => setSelectedCustomer(cust)}
                            className="p-1.5 text-slate-500 hover:text-orange-600 hover:bg-slate-100 rounded-lg cursor-pointer"
                            title="View Full Profile"
                          >
                            <Eye className="w-4 h-4" />
                          </button>

                          <button
                            onClick={() => {
                              if (confirm(`Reset login PIN for ${cust.name}? Customer can then login with OTP.`)) {
                                resetCustomerPin(cust.id);
                                alert('PIN reset. Customer can login with OTP.');
                              }
                            }}
                            className="p-1.5 text-slate-500 hover:text-blue-600 hover:bg-slate-100 rounded-lg cursor-pointer"
                            title="Reset Customer PIN"
                          >
                            <KeyRound className="w-4 h-4" />
                          </button>

                          <button
                            onClick={() => {
                              const newStatus = cust.status === 'Suspended' ? 'Active' : 'Suspended';
                              updateCustomer(cust.id, { status: newStatus as any });
                            }}
                            className="p-1.5 text-slate-500 hover:text-amber-600 hover:bg-slate-100 rounded-lg cursor-pointer"
                            title={cust.status === 'Suspended' ? 'Activate Account' : 'Suspend Account'}
                          >
                            {cust.status === 'Suspended' ? (
                              <ShieldCheck className="w-4 h-4 text-emerald-600" />
                            ) : (
                              <ShieldAlert className="w-4 h-4" />
                            )}
                          </button>

                          <button
                            onClick={() => {
                              if (confirm(`Are you sure you want to delete customer record for ${cust.name}?`)) {
                                deleteCustomer(cust.id);
                              }
                            }}
                            className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-slate-100 rounded-lg cursor-pointer"
                            title="Delete Customer"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>

        {/* Pagination Controls for 2000+ Customers */}
        {filteredCustomers.length > pageSize && (
          <div className="px-4 py-3 bg-slate-50 border-t border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-2 text-xs text-slate-500">
            <div>
              Showing <span className="font-bold text-slate-900">{(currentPage - 1) * pageSize + 1}</span> to{' '}
              <span className="font-bold text-slate-900">
                {Math.min(currentPage * pageSize, filteredCustomers.length)}
              </span>{' '}
              of <span className="font-bold text-slate-900">{filteredCustomers.length.toLocaleString('en-IN')}</span> customers
            </div>

            <div className="flex items-center gap-1.5">
              <button
                type="button"
                disabled={currentPage === 1}
                onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
                className="px-2.5 py-1.5 bg-white border border-slate-200 rounded-lg text-slate-700 disabled:opacity-40 hover:bg-slate-100 flex items-center gap-1 cursor-pointer font-medium"
              >
                <ChevronLeft className="w-3.5 h-3.5" />
                <span>Prev</span>
              </button>

              <span className="px-3 py-1 font-mono text-slate-700 font-semibold bg-white rounded-lg border border-slate-200">
                Page {currentPage} of {totalPages}
              </span>

              <button
                type="button"
                disabled={currentPage >= totalPages}
                onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
                className="px-2.5 py-1.5 bg-white border border-slate-200 rounded-lg text-slate-700 disabled:opacity-40 hover:bg-slate-100 flex items-center gap-1 cursor-pointer font-medium"
              >
                <span>Next</span>
                <ChevronRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Add New Customer Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white w-full max-w-2xl rounded-2xl shadow-2xl border border-slate-200 overflow-hidden my-8 animate-in fade-in">
            <div className="bg-slate-900 px-6 py-4 text-white flex items-center justify-between">
              <h3 className="font-bold text-sm">Add New Customer</h3>
              <button
                onClick={() => setShowAddModal(false)}
                className="p-1 text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateCustomer} className="p-6 space-y-4 max-h-[80vh] overflow-y-auto">
              <h4 className="text-xs font-bold uppercase tracking-wider text-orange-600">
                1. Customer Details
              </h4>
              <div className="grid grid-cols-2 gap-3 text-xs">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Full Name *</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Rajesh Mehra"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Mobile Number (+91) *</label>
                  <input
                    type="tel"
                    required
                    maxLength={10}
                    placeholder="10-digit mobile"
                    value={mobile}
                    onChange={(e) => setMobile(e.target.value.replace(/\D/g, ''))}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl font-mono"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Email</label>
                  <input
                    type="email"
                    placeholder="email@example.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">City</label>
                  <input
                    type="text"
                    value={city}
                    onChange={(e) => setCity(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl"
                  />
                </div>
                <div className="col-span-2">
                  <label className="block font-semibold text-slate-700 mb-1">Postal Address</label>
                  <input
                    type="text"
                    placeholder="Complete residential address"
                    value={address}
                    onChange={(e) => setAddress(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl"
                  />
                </div>
              </div>

              <h4 className="text-xs font-bold uppercase tracking-wider text-orange-600 pt-2 border-t border-slate-100">
                2. Property & Financial Plan
              </h4>
              <div className="grid grid-cols-2 gap-3 text-xs">
                <div className="col-span-2">
                  <label className="block font-semibold text-slate-700 mb-1">Allot Plot</label>
                  <select
                    value={selectedPropertyId}
                    onChange={(e) => setSelectedPropertyId(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl"
                  >
                    <option value="">Do not allot plot right now (Pending Allotment)</option>
                    {properties.map((p) => (
                      <option key={p.id} value={p.id}>
                        Plot {p.plotNumber} - {p.title} ({p.propertySize} · ₹{p.totalValue.toLocaleString('en-IN')})
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Total Property Value (₹)</label>
                  <input
                    type="number"
                    value={totalValue}
                    onChange={(e) => setTotalValue(parseFloat(e.target.value) || 0)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl font-mono"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Booking Amount Paid (₹)</label>
                  <input
                    type="number"
                    value={bookingAmount}
                    onChange={(e) => setBookingAmount(parseFloat(e.target.value) || 0)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl font-mono"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Monthly Kist Amount (₹)</label>
                  <input
                    type="number"
                    value={monthlyKist}
                    onChange={(e) => setMonthlyKist(parseFloat(e.target.value) || 0)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl font-mono"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Total Number of Kists</label>
                  <input
                    type="number"
                    value={totalKists}
                    onChange={(e) => setTotalKists(parseInt(e.target.value) || 24)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl font-mono"
                  />
                </div>
              </div>

              <div className="pt-4 flex gap-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="flex-1 py-2.5 bg-slate-100 text-slate-700 font-semibold rounded-xl text-xs cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 bg-orange-600 hover:bg-orange-700 text-white font-bold rounded-xl text-xs cursor-pointer shadow-sm"
                >
                  Save Customer Record
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Customer Profile View Modal */}
      {selectedCustomer && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-lg rounded-2xl shadow-xl border border-slate-200 p-6 animate-in fade-in">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-4">
              <div>
                <h4 className="font-bold text-base text-slate-900">{selectedCustomer.name}</h4>
                <p className="font-mono text-xs text-orange-600">{selectedCustomer.id}</p>
              </div>
              <button
                onClick={() => setSelectedCustomer(null)}
                className="p-1 text-slate-400 hover:text-slate-800"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div className="grid grid-cols-2 gap-2 p-3 bg-slate-50 rounded-xl">
                <div>
                  <span className="text-slate-400 block">Mobile:</span>
                  <span className="font-mono font-semibold">+91 {selectedCustomer.mobile}</span>
                </div>
                <div>
                  <span className="text-slate-400 block">Status:</span>
                  <span className="font-semibold text-emerald-600">{selectedCustomer.status}</span>
                </div>
                <div>
                  <span className="text-slate-400 block">City:</span>
                  <span>{selectedCustomer.city}</span>
                </div>
                <div>
                  <span className="text-slate-400 block">Registered:</span>
                  <span>{selectedCustomer.registeredDate}</span>
                </div>
              </div>

              <div className="p-3 bg-orange-50/70 border border-orange-200/60 rounded-xl space-y-1">
                <span className="font-bold text-orange-950 block mb-1">Financial Overview</span>
                <div className="flex justify-between">
                  <span className="text-slate-600">Total Value:</span>
                  <span className="font-mono font-bold">₹{selectedCustomer.totalPropertyValue.toLocaleString('en-IN')}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-600">Monthly Kist:</span>
                  <span className="font-mono font-bold">₹{selectedCustomer.monthlyKistAmount.toLocaleString('en-IN')}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-600">Kists Completed:</span>
                  <span className="font-mono font-bold">{selectedCustomer.paidKists} of {selectedCustomer.totalKists}</span>
                </div>
              </div>

              <button
                onClick={() => {
                  resetCustomerPin(selectedCustomer.id);
                  alert(`PIN reset for ${selectedCustomer.name}. Customer can now login via OTP.`);
                  setSelectedCustomer(null);
                }}
                className="w-full py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-800 rounded-xl font-semibold cursor-pointer"
              >
                Reset Customer PIN
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Bulk Excel/CSV Import Modal for 2000+ Customers */}
      <AdminCustomerImportModal
        isOpen={showImportModal}
        onClose={() => setShowImportModal(false)}
      />
    </div>
  );
};
