import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { KeyRound, CheckCircle2, User, Home, ArrowRight } from 'lucide-react';

interface AdminAssignPropertyProps {
  onSuccess?: () => void;
}

export const AdminAssignProperty: React.FC<AdminAssignPropertyProps> = ({ onSuccess }) => {
  const { customers, properties, assignProperty } = useApp();

  const [selectedCustomerId, setSelectedCustomerId] = useState<string>('');
  const [selectedPropertyId, setSelectedPropertyId] = useState<string>('');
  const [totalValue, setTotalValue] = useState<number>(1250000);
  const [bookingAmount, setBookingAmount] = useState<number>(150000);
  const [monthlyKist, setMonthlyKist] = useState<number>(12500);
  const [totalKists, setTotalKists] = useState<number>(24);
  const [successMsg, setSuccessMsg] = useState<string>('');

  const availableProperties = properties.filter(
    (p) => p.status === 'Available' || !p.assignedCustomerId
  );

  const selectedProp = properties.find((p) => p.id === selectedPropertyId);
  const selectedCust = customers.find((c) => c.id === selectedCustomerId);

  const handlePropertyChange = (propId: string) => {
    setSelectedPropertyId(propId);
    const prop = properties.find((p) => p.id === propId);
    if (prop) {
      setTotalValue(prop.totalValue);
      setBookingAmount(prop.bookingAmount);
      setMonthlyKist(12500);
      setTotalKists(24);
    }
  };

  const handleAssign = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedCustomerId || !selectedPropertyId) {
      alert('Please select both a customer and an available plot.');
      return;
    }

    assignProperty(selectedPropertyId, selectedCustomerId, {
      totalValue,
      bookingAmount,
      monthlyKist,
      totalKists,
    });

    setSuccessMsg(
      `✓ Successfully allotted Plot ${selectedProp?.plotNumber} to ${selectedCust?.name} (${selectedCust?.id})!`
    );

    setTimeout(() => {
      setSuccessMsg('');
      if (onSuccess) onSuccess();
    }, 2000);
  };

  return (
    <div className="max-w-2xl mx-auto space-y-5 animate-in fade-in">
      <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm">
        <div className="flex items-center gap-3 pb-4 border-b border-slate-100 mb-5">
          <div className="w-10 h-10 rounded-xl bg-orange-100 text-orange-600 flex items-center justify-center">
            <KeyRound className="w-5 h-5" />
          </div>
          <div>
            <h3 className="font-bold text-base text-slate-900">Assign Property to Customer</h3>
            <p className="text-xs text-slate-500">
              Allot a vacant plot to an existing or newly registered customer and initialize their installment schedule.
            </p>
          </div>
        </div>

        {successMsg && (
          <div className="mb-5 p-4 bg-emerald-50 border border-emerald-200 rounded-2xl flex items-center gap-3 text-emerald-800 text-xs font-semibold">
            <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
            <span>{successMsg}</span>
          </div>
        )}

        <form onSubmit={handleAssign} className="space-y-4 text-xs">
          {/* Step 1: Select Customer */}
          <div>
            <label className="block font-semibold text-slate-700 mb-1 flex items-center gap-1.5">
              <User className="w-3.5 h-3.5 text-orange-600" />
              <span>Select Customer *</span>
            </label>
            <select
              value={selectedCustomerId}
              onChange={(e) => setSelectedCustomerId(e.target.value)}
              required
              className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-slate-900"
            >
              <option value="">-- Choose Customer --</option>
              {customers.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name} (ID: {c.id}, Mobile: +91 {c.mobile}) · Status: {c.status}
                </option>
              ))}
            </select>
          </div>

          {/* Step 2: Select Available Plot */}
          <div>
            <label className="block font-semibold text-slate-700 mb-1 flex items-center gap-1.5">
              <Home className="w-3.5 h-3.5 text-orange-600" />
              <span>Select Available Plot *</span>
            </label>
            <select
              value={selectedPropertyId}
              onChange={(e) => handlePropertyChange(e.target.value)}
              required
              className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-slate-900"
            >
              <option value="">-- Choose Plot --</option>
              {availableProperties.map((p) => (
                <option key={p.id} value={p.id}>
                  Plot {p.plotNumber} - {p.title} ({p.propertySize} · {p.propertyType} · ₹{p.totalValue.toLocaleString('en-IN')})
                </option>
              ))}
            </select>
          </div>

          {/* Step 3: Installment Schedule Customization */}
          <div className="p-4 bg-orange-50/70 border border-orange-200/80 rounded-2xl space-y-3">
            <h4 className="font-bold text-orange-950 uppercase tracking-wider text-[11px]">
              Payment & Kist Terms Configuration
            </h4>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Agreed Total Property Value (₹)
                </label>
                <input
                  type="number"
                  value={totalValue}
                  onChange={(e) => setTotalValue(parseFloat(e.target.value) || 0)}
                  className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl font-mono"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Booking Advance Amount (₹)
                </label>
                <input
                  type="number"
                  value={bookingAmount}
                  onChange={(e) => setBookingAmount(parseFloat(e.target.value) || 0)}
                  className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl font-mono"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Monthly Installment (Kist) (₹)
                </label>
                <input
                  type="number"
                  value={monthlyKist}
                  onChange={(e) => setMonthlyKist(parseFloat(e.target.value) || 0)}
                  className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl font-mono"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Total Number of Installments
                </label>
                <input
                  type="number"
                  value={totalKists}
                  onChange={(e) => setTotalKists(parseInt(e.target.value) || 24)}
                  className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl font-mono"
                />
              </div>
            </div>
          </div>

          <button
            type="submit"
            className="w-full py-3.5 bg-orange-600 hover:bg-orange-700 text-white font-bold rounded-xl text-xs shadow-md shadow-orange-600/20 transition-all flex items-center justify-center gap-2 cursor-pointer"
          >
            <span>Confirm Plot Allotment & Generate Booking Receipt</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </form>
      </div>
    </div>
  );
};
