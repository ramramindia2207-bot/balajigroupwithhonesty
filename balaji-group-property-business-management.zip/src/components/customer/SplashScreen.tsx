import React, { useState } from 'react';
import { BalajiLogo } from '../common/BalajiLogo';
import { ShieldCheck, Zap, HeartHandshake, CheckCircle2, ArrowRight, Home } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { AdminAccessModal } from '../common/AdminAccessModal';
import { PWAInstallButton } from '../common/PWAInstallButton';

interface SplashScreenProps {
  onStart: () => void;
}

export const SplashScreen: React.FC<SplashScreenProps> = ({ onStart }) => {
  const { t } = useApp();
  const [showAdminModal, setShowAdminModal] = useState(false);

  return (
    <div className="min-h-screen bg-gradient-to-b from-orange-500 via-orange-600 to-amber-700 flex flex-col justify-between text-white p-6 relative overflow-hidden select-none">
      {/* Decorative background radial glows */}
      <div className="absolute top-0 right-0 w-96 h-96 bg-white/10 rounded-full blur-3xl pointer-events-none -mr-20 -mt-20"></div>
      <div className="absolute bottom-1/3 left-0 w-80 h-80 bg-orange-400/20 rounded-full blur-3xl pointer-events-none -ml-20"></div>

      {/* Top right small home icon without admin text */}
      <div className="absolute top-4 right-4 z-20">
        <button
          onClick={() => setShowAdminModal(true)}
          className="p-2.5 text-white/70 hover:text-white hover:bg-white/20 rounded-xl transition-all cursor-pointer backdrop-blur-xs border border-white/10 shadow-xs"
          aria-label="Portal Entry"
        >
          <Home className="w-4 h-4" />
        </button>
      </div>

      {/* Top Branding Bar */}
      <div className="pt-8 sm:pt-12 text-center relative z-10 flex flex-col items-center">
        {/* Large Brand Icon */}
        <div className="w-24 h-24 sm:w-28 sm:h-28 bg-white/15 backdrop-blur-md rounded-3xl p-5 mb-5 flex items-center justify-center border border-white/25 shadow-xl">
          <svg viewBox="0 0 48 48" fill="none" className="w-full h-full drop-shadow-md">
            <path d="M24 4L4 21H10V42H38V21H44L24 4Z" fill="#FFFFFF" opacity="0.3" />
            <path d="M24 6L5 22H11L24 10.5L37 22H43L24 6Z" fill="#FFFFFF" />
            <path d="M13 23V41H35V23L24 13.5L13 23Z" stroke="#FFFFFF" strokeWidth="3.5" strokeLinejoin="round" />
            <rect x="20" y="25" width="8" height="10" rx="1.5" fill="#FFFFFF" />
          </svg>
        </div>

        <h1 className="text-3xl sm:text-4xl font-extrabold tracking-tight uppercase font-heading">
          BALAJI GROUP
        </h1>
        <p className="text-orange-100 text-sm sm:text-base font-medium tracking-wide mt-1.5">
          {t('tagline')}
        </p>
      </div>

      {/* Center Township Landscape Graphic */}
      <div className="my-auto py-6 relative z-10 text-center max-w-md mx-auto">
        <div className="relative rounded-2xl overflow-hidden shadow-2xl border border-white/20 mb-6 group">
          <img
            src="/src/assets/images/balaji_property_banner_1791042203433.jpg"
            alt="Balaji Group Plotted Townships"
            referrerPolicy="no-referrer"
            className="w-full h-48 object-cover brightness-95 transform group-hover:scale-105 transition-transform duration-700"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-transparent to-transparent flex flex-col justify-end p-4 text-left">
            <span className="text-[10px] font-bold uppercase tracking-wider text-orange-400">
              Verified Plotted Townships
            </span>
            <h3 className="text-base font-bold text-white">Green Valley · Chhatarpur</h3>
            <p className="text-xs text-slate-200">Gated security · Immediate Registry · Easy Kists</p>
          </div>
        </div>

        {/* 4 Trust Badges */}
        <div className="grid grid-cols-4 gap-2 mb-2">
          <div className="bg-white/10 backdrop-blur-xs rounded-xl p-2.5 flex flex-col items-center justify-center border border-white/15">
            <ShieldCheck className="w-5 h-5 text-orange-200 mb-1" />
            <span className="text-[11px] font-medium">{t('secure')}</span>
          </div>
          <div className="bg-white/10 backdrop-blur-xs rounded-xl p-2.5 flex flex-col items-center justify-center border border-white/15">
            <CheckCircle2 className="w-5 h-5 text-orange-200 mb-1" />
            <span className="text-[11px] font-medium">{t('simple')}</span>
          </div>
          <div className="bg-white/10 backdrop-blur-xs rounded-xl p-2.5 flex flex-col items-center justify-center border border-white/15">
            <Zap className="w-5 h-5 text-orange-200 mb-1" />
            <span className="text-[11px] font-medium">{t('fast')}</span>
          </div>
          <div className="bg-white/10 backdrop-blur-xs rounded-xl p-2.5 flex flex-col items-center justify-center border border-white/15">
            <HeartHandshake className="w-5 h-5 text-orange-200 mb-1" />
            <span className="text-[11px] font-medium">{t('trusted')}</span>
          </div>
        </div>
      </div>

      {/* Bottom Action Area */}
      <div className="pb-4 relative z-10 max-w-md mx-auto w-full text-center">
        <p className="text-sm font-semibold text-orange-100 mb-4">
          {t('dreamProperty')}
        </p>

        <div className="space-y-2.5">
          <button
            onClick={onStart}
            className="w-full py-4 bg-white hover:bg-orange-50 text-orange-600 font-extrabold rounded-2xl text-base shadow-2xl transition-all active:scale-[0.98] flex items-center justify-center gap-2 cursor-pointer"
          >
            <span>Login / Continue</span>
            <ArrowRight className="w-5 h-5" />
          </button>

          <div className="flex justify-center">
            <PWAInstallButton
              variant="header"
              className="w-full justify-center py-3 bg-white/20 hover:bg-white/30 backdrop-blur-md border border-white/30 shadow-lg text-sm"
            />
          </div>
        </div>

        <div className="mt-4 flex items-center justify-center gap-2 text-xs text-orange-200">
          <span>Balaji Group Real Estate</span>
          <span>·</span>
          <span>Version 1.0.0</span>
        </div>
      </div>

      <AdminAccessModal isOpen={showAdminModal} onClose={() => setShowAdminModal(false)} />
    </div>
  );
};
