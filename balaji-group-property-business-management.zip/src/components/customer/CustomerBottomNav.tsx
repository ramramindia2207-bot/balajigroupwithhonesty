import React from 'react';
import { Home, MapPin, CreditCard, Tag, HelpCircle, User } from 'lucide-react';
import { useApp } from '../../context/AppContext';

interface CustomerBottomNavProps {
  activeTab: string;
  onTabChange: (tab: string) => void;
}

export const CustomerBottomNav: React.FC<CustomerBottomNavProps> = ({
  activeTab,
  onTabChange,
}) => {
  const { t } = useApp();

  const navItems = [
    { id: 'home', label: t('home'), icon: Home },
    { id: 'property', label: t('property'), icon: MapPin },
    { id: 'payments', label: t('payments'), icon: CreditCard },
    { id: 'coupons', label: t('coupons'), icon: Tag },
    { id: 'help', label: t('help'), icon: HelpCircle },
    { id: 'settings', label: t('settings'), icon: User },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-md border-t border-slate-200 px-2 py-1.5 shadow-lg select-none">
      <div className="max-w-md mx-auto flex items-center justify-around">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => onTabChange(item.id)}
              className={`flex flex-col items-center justify-center py-1 px-2 rounded-xl transition-all cursor-pointer ${
                isActive ? 'text-orange-600' : 'text-slate-500 hover:text-slate-800'
              }`}
            >
              <div
                className={`p-1 rounded-lg transition-transform ${
                  isActive ? 'scale-110 bg-orange-50' : ''
                }`}
              >
                <Icon className="w-5 h-5" />
              </div>
              <span className={`text-[10px] mt-0.5 ${isActive ? 'font-bold' : 'font-medium'}`}>
                {item.label}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
};
