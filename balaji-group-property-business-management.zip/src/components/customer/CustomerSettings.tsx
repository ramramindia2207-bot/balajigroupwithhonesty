import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Globe,
  Lock,
  Bell,
  Sun,
  HelpCircle,
  Info,
  LogOut,
  ChevronRight,
  Shield,
  FileCheck,
  Check,
  KeyRound,
  X,
} from 'lucide-react';
import { Language } from '../../types';
import { PWAInstallButton } from '../common/PWAInstallButton';

interface CustomerSettingsProps {
  onNavigateTab: (tab: string) => void;
}

export const CustomerSettings: React.FC<CustomerSettingsProps> = ({ onNavigateTab }) => {
  const {
    currentCustomer,
    language,
    setLanguage,
    setCustomerPin,
    logoutCustomer,
    settings,
    t,
  } = useApp();

  const [notificationsEnabled, setNotificationsEnabled] = useState<boolean>(true);
  const [showLanguageModal, setShowLanguageModal] = useState<boolean>(false);
  const [showPinModal, setShowPinModal] = useState<boolean>(false);
  const [showPrivacyModal, setShowPrivacyModal] = useState<boolean>(false);
  const [showTermsModal, setShowTermsModal] = useState<boolean>(false);

  // Change PIN state
  const [pinInput, setPinInput] = useState<string>('');
  const [confirmPinInput, setConfirmPinInput] = useState<string>('');
  const [pinMessage, setPinMessage] = useState<string>('');

  if (!currentCustomer) return null;

  const handleUpdatePin = (e: React.FormEvent) => {
    e.preventDefault();
    if (pinInput.length < 4) {
      setPinMessage('PIN must be at least 4 digits.');
      return;
    }
    if (pinInput !== confirmPinInput) {
      setPinMessage('PINs do not match.');
      return;
    }
    setCustomerPin(currentCustomer.id, pinInput);
    setPinMessage('✓ Login PIN updated successfully!');
    setTimeout(() => {
      setShowPinModal(false);
      setPinMessage('');
      setPinInput('');
      setConfirmPinInput('');
    }, 1200);
  };

  return (
    <div className="space-y-5 pb-8 animate-in fade-in duration-200">
      {/* Profile Header Card */}
      <div className="bg-white rounded-3xl p-5 border border-slate-200 shadow-xs flex items-center gap-4">
        <div className="w-14 h-14 rounded-2xl bg-orange-600 text-white font-extrabold text-xl flex items-center justify-center shadow-md shadow-orange-600/20">
          {currentCustomer.name.charAt(0)}
        </div>
        <div className="flex-1 min-w-0">
          <h3 className="font-bold text-base text-slate-900 truncate">
            {currentCustomer.name}
          </h3>
          <p className="text-xs text-slate-500 font-mono">Customer ID: {currentCustomer.id}</p>
          <p className="text-xs text-slate-500 font-mono">+91 {currentCustomer.mobile}</p>
        </div>
      </div>

      {/* Settings Navigation List (Matching Wireframe Screen 10) */}
      <div className="bg-white rounded-3xl border border-slate-200 overflow-hidden shadow-xs divide-y divide-slate-100 text-xs">
        {/* Change Language */}
        <button
          onClick={() => setShowLanguageModal(true)}
          className="w-full p-4 flex items-center justify-between hover:bg-slate-50 transition-colors text-left cursor-pointer"
        >
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-orange-50 text-orange-600 flex items-center justify-center">
              <Globe className="w-4 h-4" />
            </div>
            <div>
              <span className="font-bold text-slate-900 text-sm block">
                {t('changeLanguage')}
              </span>
              <span className="text-slate-400">
                {language === 'en' ? 'English' : 'हिन्दी (Hindi)'}
              </span>
            </div>
          </div>
          <ChevronRight className="w-4 h-4 text-slate-400" />
        </button>

        {/* Login Security (PIN / Password) */}
        <button
          onClick={() => setShowPinModal(true)}
          className="w-full p-4 flex items-center justify-between hover:bg-slate-50 transition-colors text-left cursor-pointer"
        >
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-orange-50 text-orange-600 flex items-center justify-center">
              <Lock className="w-4 h-4" />
            </div>
            <div>
              <span className="font-bold text-slate-900 text-sm block">
                {t('loginSecurity')}
              </span>
              <span className="text-slate-400">
                {currentCustomer.hasPin ? 'PIN Enabled (Change PIN)' : 'Set Up Fast Login PIN'}
              </span>
            </div>
          </div>
          <ChevronRight className="w-4 h-4 text-slate-400" />
        </button>

        {/* Notifications Toggle */}
        <div className="p-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-orange-50 text-orange-600 flex items-center justify-center">
              <Bell className="w-4 h-4" />
            </div>
            <div>
              <span className="font-bold text-slate-900 text-sm block">
                {t('notifications')}
              </span>
              <span className="text-slate-400">Payment & Kist reminders</span>
            </div>
          </div>
          <button
            onClick={() => setNotificationsEnabled(!notificationsEnabled)}
            className={`w-12 h-6 flex items-center rounded-full p-1 transition-colors cursor-pointer ${
              notificationsEnabled ? 'bg-orange-600' : 'bg-slate-300'
            }`}
          >
            <div
              className={`bg-white w-4 h-4 rounded-full shadow-md transform transition-transform ${
                notificationsEnabled ? 'translate-x-6' : 'translate-x-0'
              }`}
            ></div>
          </button>
        </div>

        {/* Theme */}
        <div className="p-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-orange-50 text-orange-600 flex items-center justify-center">
              <Sun className="w-4 h-4" />
            </div>
            <div>
              <span className="font-bold text-slate-900 text-sm block">{t('theme')}</span>
              <span className="text-slate-400">Clean & Light UI</span>
            </div>
          </div>
          <span className="px-2.5 py-1 bg-slate-100 text-slate-700 font-semibold rounded-lg text-xs">
            {t('light')}
          </span>
        </div>

        {/* Help & Support Shortcut */}
        <button
          onClick={() => onNavigateTab('help')}
          className="w-full p-4 flex items-center justify-between hover:bg-slate-50 transition-colors text-left cursor-pointer"
        >
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-orange-50 text-orange-600 flex items-center justify-center">
              <HelpCircle className="w-4 h-4" />
            </div>
            <div>
              <span className="font-bold text-slate-900 text-sm block">
                {t('helpSupport')}
              </span>
              <span className="text-slate-400">{settings.email}</span>
            </div>
          </div>
          <ChevronRight className="w-4 h-4 text-slate-400" />
        </button>

        {/* Privacy Policy */}
        <button
          onClick={() => setShowPrivacyModal(true)}
          className="w-full p-4 flex items-center justify-between hover:bg-slate-50 transition-colors text-left cursor-pointer"
        >
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-orange-50 text-orange-600 flex items-center justify-center">
              <Shield className="w-4 h-4" />
            </div>
            <div>
              <span className="font-bold text-slate-900 text-sm block">
                {t('privacyPolicy')}
              </span>
              <span className="text-slate-400">Data encryption & customer privacy</span>
            </div>
          </div>
          <ChevronRight className="w-4 h-4 text-slate-400" />
        </button>

        {/* Terms & Conditions */}
        <button
          onClick={() => setShowTermsModal(true)}
          className="w-full p-4 flex items-center justify-between hover:bg-slate-50 transition-colors text-left cursor-pointer"
        >
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-orange-50 text-orange-600 flex items-center justify-center">
              <FileCheck className="w-4 h-4" />
            </div>
            <div>
              <span className="font-bold text-slate-900 text-sm block">
                {t('termsConditions')}
              </span>
              <span className="text-slate-400">Property allotment guidelines</span>
            </div>
          </div>
          <ChevronRight className="w-4 h-4 text-slate-400" />
        </button>

        {/* About Us */}
        <div className="p-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-orange-50 text-orange-600 flex items-center justify-center">
              <Info className="w-4 h-4" />
            </div>
            <div>
              <span className="font-bold text-slate-900 text-sm block">{t('aboutUs')}</span>
              <span className="text-slate-400">Balaji Group Real Estate v1.0.0</span>
            </div>
          </div>
          <span className="text-slate-400 text-xs font-mono">{t('version')}</span>
        </div>
      </div>

      {/* PWA / APK Mobile App Download Card */}
      <PWAInstallButton variant="card" />

      {/* Red Logout Button (Matching Wireframe Screen 10) */}
      <button
        onClick={logoutCustomer}
        className="w-full py-4 bg-rose-600 hover:bg-rose-700 text-white font-bold rounded-2xl text-sm shadow-md shadow-rose-600/20 transition-all flex items-center justify-center gap-2 cursor-pointer"
      >
        <LogOut className="w-4 h-4" />
        <span>{t('logout')}</span>
      </button>

      {/* Language Selection Modal */}
      {showLanguageModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-sm rounded-2xl shadow-xl border border-slate-200 p-5 animate-in fade-in">
            <div className="flex items-center justify-between mb-4">
              <h4 className="font-bold text-slate-900 text-sm">{t('changeLanguage')}</h4>
              <button
                onClick={() => setShowLanguageModal(false)}
                className="p-1 hover:bg-slate-100 rounded-lg text-slate-400"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-2">
              <button
                onClick={() => {
                  setLanguage('en');
                  setShowLanguageModal(false);
                }}
                className={`w-full p-3 rounded-xl border flex items-center justify-between text-xs font-semibold transition-colors cursor-pointer ${
                  language === 'en'
                    ? 'border-orange-500 bg-orange-50 text-orange-900'
                    : 'border-slate-200 hover:bg-slate-50 text-slate-700'
                }`}
              >
                <span>English (Default)</span>
                {language === 'en' && <Check className="w-4 h-4 text-orange-600" />}
              </button>

              <button
                onClick={() => {
                  setLanguage('hi');
                  setShowLanguageModal(false);
                }}
                className={`w-full p-3 rounded-xl border flex items-center justify-between text-xs font-semibold transition-colors cursor-pointer ${
                  language === 'hi'
                    ? 'border-orange-500 bg-orange-50 text-orange-900'
                    : 'border-slate-200 hover:bg-slate-50 text-slate-700'
                }`}
              >
                <span>हिन्दी (Hindi)</span>
                {language === 'hi' && <Check className="w-4 h-4 text-orange-600" />}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Change PIN Modal */}
      {showPinModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-sm rounded-2xl shadow-xl border border-slate-200 p-6 animate-in fade-in">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <KeyRound className="w-5 h-5 text-orange-600" />
                <h4 className="font-bold text-slate-900 text-sm">Manage Login PIN</h4>
              </div>
              <button
                onClick={() => setShowPinModal(false)}
                className="p-1 hover:bg-slate-100 rounded-lg text-slate-400"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {pinMessage && (
              <p className="text-xs mb-3 font-semibold text-center text-emerald-600">
                {pinMessage}
              </p>
            )}

            <form onSubmit={handleUpdatePin} className="space-y-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  New 4-Digit PIN
                </label>
                <input
                  type="password"
                  maxLength={6}
                  placeholder="Enter new PIN"
                  value={pinInput}
                  onChange={(e) => setPinInput(e.target.value.replace(/\D/g, ''))}
                  required
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-sm font-mono text-center"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Confirm New PIN
                </label>
                <input
                  type="password"
                  maxLength={6}
                  placeholder="Re-enter PIN"
                  value={confirmPinInput}
                  onChange={(e) => setConfirmPinInput(e.target.value.replace(/\D/g, ''))}
                  required
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-sm font-mono text-center"
                />
              </div>

              <button
                type="submit"
                className="w-full mt-2 py-3 bg-orange-600 hover:bg-orange-700 text-white font-bold rounded-xl text-xs transition-colors cursor-pointer"
              >
                Save New PIN
              </button>
            </form>
          </div>
        </div>
      )}

      {/* Privacy Policy Modal */}
      {showPrivacyModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-lg rounded-2xl shadow-xl border border-slate-200 p-6 animate-in fade-in max-h-[85vh] overflow-y-auto text-xs text-slate-600 space-y-3">
            <div className="flex items-center justify-between pb-2 border-b border-slate-100">
              <h4 className="font-bold text-slate-900 text-sm">Privacy Policy · Balaji Group</h4>
              <button
                onClick={() => setShowPrivacyModal(false)}
                className="p-1 hover:bg-slate-100 rounded-lg text-slate-400"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <p>
              Balaji Group places paramount importance on customer confidentiality and data security.
              Personal identifiable information including mobile numbers, plot registry details, and financial ledgers are encrypted in transit and at rest.
            </p>
            <p>
              We never share customer contact details or transaction records with third-party telemarketers. Customer property data is strictly accessible only by authenticated account holders and authorized company administration.
            </p>
          </div>
        </div>
      )}

      {/* Terms & Conditions Modal */}
      {showTermsModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-lg rounded-2xl shadow-xl border border-slate-200 p-6 animate-in fade-in max-h-[85vh] overflow-y-auto text-xs text-slate-600 space-y-3">
            <div className="flex items-center justify-between pb-2 border-b border-slate-100">
              <h4 className="font-bold text-slate-900 text-sm">Terms & Conditions · Plot Allotment</h4>
              <button
                onClick={() => setShowTermsModal(false)}
                className="p-1 hover:bg-slate-100 rounded-lg text-slate-400"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <p>
              1. Monthly installments (Kists) must be honored on or before the 15th of each calendar month.
            </p>
            <p>
              2. Payments via UPI QR are subject to reconciliation against official bank statement UTR records before official computer receipts are marked as Approved.
            </p>
            <p>
              3. Plot boundary demarcation and registry deed execution shall occur in accordance with the signed allotment agreement.
            </p>
          </div>
        </div>
      )}
    </div>
  );
};
