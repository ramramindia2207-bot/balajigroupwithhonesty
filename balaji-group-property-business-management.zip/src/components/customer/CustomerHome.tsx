import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  MapPin,
  CreditCard,
  Tag,
  HelpCircle,
  Settings,
  ChevronRight,
  Calendar,
  AlertTriangle,
  CheckCircle,
  Clock,
  Sparkles,
  QrCode,
  FileText,
  ShieldAlert,
} from 'lucide-react';
import { QRScanModal } from '../common/QRScanModal';

interface CustomerHomeProps {
  onNavigateTab: (tab: string) => void;
}

export const CustomerHome: React.FC<CustomerHomeProps> = ({ onNavigateTab }) => {
  const { currentCustomer, customerProperty, calculateCustomerFinance, t } = useApp();
  const [showQRModal, setShowQRModal] = useState<boolean>(false);

  if (!currentCustomer) {
    return (
      <div className="p-8 text-center">
        <p className="text-slate-500">Please sign in to view your dashboard.</p>
      </div>
    );
  }

  const finance = calculateCustomerFinance(currentCustomer);
  const isOverdue = currentCustomer.kistStatus === 'Due' || currentCustomer.status === 'Due';
  const isAdvance = currentCustomer.kistStatus === 'Advance';
  const displayAmount = finance.dueAmount > 0 ? finance.dueAmount : finance.monthlyKist;

  return (
    <div className="space-y-5 pb-8 animate-in fade-in duration-200">
      {/* Personalized Greeting */}
      <div className="bg-gradient-to-r from-orange-600 via-orange-500 to-amber-600 rounded-3xl p-6 text-white shadow-xl relative overflow-hidden">
        <div className="absolute right-0 top-0 w-64 h-64 bg-white/10 rounded-full blur-2xl pointer-events-none -mr-16 -mt-16"></div>

        <div className="relative z-10">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs uppercase tracking-wider font-semibold text-orange-100">
              {t('welcomeToBalaji')}
            </span>
            <span className="font-mono text-xs bg-white/20 px-2.5 py-0.5 rounded-full font-bold">
              ID: {currentCustomer.id}
            </span>
          </div>

          <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
            {t('hello')}, {currentCustomer.name}
          </h2>

          <p className="text-xs text-orange-100 mt-1 flex items-center gap-1.5">
            <MapPin className="w-3.5 h-3.5 shrink-0" />
            <span>{currentCustomer.city || 'Delhi NCR'}</span>
            <span>·</span>
            <span>Customer since {currentCustomer.registeredDate}</span>
          </p>
        </div>
      </div>

      {/* Account Pending State (For New Customers awaiting admin allotment) */}
      {currentCustomer.status === 'Pending Approval' && (
        <div className="bg-amber-50 border border-amber-200 rounded-2xl p-4 flex items-start gap-3">
          <AlertTriangle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
          <div className="text-xs text-amber-900">
            <h4 className="font-bold text-sm text-amber-950 mb-0.5">
              Registration Under Verification
            </h4>
            <p className="leading-relaxed">
              {t('pendingAdminAssignment')} Our sales team will contact you at +91 {currentCustomer.mobile}.
            </p>
          </div>
        </div>
      )}

      {/* Your Property Card (Screen 5 wireframe) */}
      {customerProperty ? (
        <div
          onClick={() => onNavigateTab('property')}
          className="bg-white rounded-2xl p-4 sm:p-5 border border-slate-200 shadow-sm hover:shadow-md hover:border-orange-300 transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-400">
              {t('yourProperty')}
            </span>
            <span className="text-xs text-orange-600 font-semibold group-hover:underline flex items-center gap-0.5">
              <span>View Details</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </span>
          </div>

          <div className="flex items-center gap-4">
            <div className="w-20 h-20 sm:w-24 sm:h-24 rounded-xl overflow-hidden shrink-0 border border-slate-200 relative bg-slate-100">
              <img
                src={customerProperty.imageUrl || '/src/assets/images/balaji_plot_greenvalley_1791042223890.jpg'}
                alt={customerProperty.title}
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
              />
              <span className="absolute bottom-1 left-1 bg-slate-900/80 text-white text-[9px] font-bold px-1.5 py-0.5 rounded">
                Plot {customerProperty.plotNumber}
              </span>
            </div>

            <div className="flex-1 min-w-0">
              <h3 className="font-bold text-base text-slate-900 truncate">
                Plot No. {customerProperty.plotNumber}
              </h3>
              <p className="text-xs text-slate-600 flex items-center gap-1 mt-0.5 truncate">
                <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                <span className="truncate">{customerProperty.location}</span>
              </p>
              <div className="flex items-center gap-2 mt-2 text-xs text-slate-500">
                <span className="bg-slate-100 px-2 py-0.5 rounded text-[11px] font-medium text-slate-700">
                  {customerProperty.propertyType}
                </span>
                <span>·</span>
                <span className="font-mono">{customerProperty.propertySize}</span>
              </div>
            </div>
          </div>
        </div>
      ) : (
        <div className="bg-white rounded-2xl p-6 border border-slate-200 text-center">
          <p className="text-sm font-semibold text-slate-700">No property assigned yet</p>
          <p className="text-xs text-slate-400 mt-1">
            Once allotted by Balaji Group admin, your plot and registry information will appear here.
          </p>
        </div>
      )}

      {/* Quick Action Icons Grid (Matching Wireframe 5) */}
      <div>
        <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-3">
          {t('quickActions')}
        </h4>
        <div className="grid grid-cols-4 sm:grid-cols-5 gap-2.5">
          <button
            onClick={() => onNavigateTab('property')}
            className="flex flex-col items-center justify-center p-3 bg-white hover:bg-orange-50/50 rounded-2xl border border-slate-200 hover:border-orange-300 transition-all cursor-pointer group shadow-2xs"
          >
            <div className="w-11 h-11 rounded-xl bg-orange-100 text-orange-600 flex items-center justify-center mb-1.5 group-hover:scale-105 transition-transform">
              <MapPin className="w-5 h-5" />
            </div>
            <span className="text-xs font-semibold text-slate-700 text-center leading-tight">
              {t('myProperty')}
            </span>
          </button>

          <button
            onClick={() => onNavigateTab('payments')}
            className="flex flex-col items-center justify-center p-3 bg-white hover:bg-orange-50/50 rounded-2xl border border-slate-200 hover:border-orange-300 transition-all cursor-pointer group shadow-2xs"
          >
            <div className="w-11 h-11 rounded-xl bg-emerald-100 text-emerald-600 flex items-center justify-center mb-1.5 group-hover:scale-105 transition-transform">
              <CreditCard className="w-5 h-5" />
            </div>
            <span className="text-xs font-semibold text-slate-700 text-center leading-tight">
              {t('payments')}
            </span>
          </button>

          <button
            onClick={() => onNavigateTab('coupons')}
            className="flex flex-col items-center justify-center p-3 bg-white hover:bg-orange-50/50 rounded-2xl border border-slate-200 hover:border-orange-300 transition-all cursor-pointer group shadow-2xs"
          >
            <div className="w-11 h-11 rounded-xl bg-purple-100 text-purple-600 flex items-center justify-center mb-1.5 group-hover:scale-105 transition-transform">
              <Tag className="w-5 h-5" />
            </div>
            <span className="text-xs font-semibold text-slate-700 text-center leading-tight">
              {t('coupons')}
            </span>
          </button>

          <button
            onClick={() => onNavigateTab('help')}
            className="flex flex-col items-center justify-center p-3 bg-white hover:bg-orange-50/50 rounded-2xl border border-slate-200 hover:border-orange-300 transition-all cursor-pointer group shadow-2xs"
          >
            <div className="w-11 h-11 rounded-xl bg-sky-100 text-sky-600 flex items-center justify-center mb-1.5 group-hover:scale-105 transition-transform">
              <HelpCircle className="w-5 h-5" />
            </div>
            <span className="text-xs font-semibold text-slate-700 text-center leading-tight">
              {t('helpSupport')}
            </span>
          </button>

          <button
            onClick={() => onNavigateTab('settings')}
            className="hidden sm:flex flex-col items-center justify-center p-3 bg-white hover:bg-orange-50/50 rounded-2xl border border-slate-200 hover:border-orange-300 transition-all cursor-pointer group shadow-2xs"
          >
            <div className="w-11 h-11 rounded-xl bg-slate-100 text-slate-600 flex items-center justify-center mb-1.5 group-hover:scale-105 transition-transform">
              <Settings className="w-5 h-5" />
            </div>
            <span className="text-xs font-semibold text-slate-700 text-center leading-tight">
              {t('settings')}
            </span>
          </button>
        </div>
      </div>

      {/* Upcoming Due Card (Matching Wireframe 5 bottom) */}
      <div className="bg-white rounded-3xl p-5 border border-slate-200 shadow-sm">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <span
              className={`w-2.5 h-2.5 rounded-full ${
                isOverdue ? 'bg-rose-500 animate-pulse' : 'bg-orange-500'
              }`}
            ></span>
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-700">
              {t('upcomingDue')}
            </h4>
          </div>

          <span
            className={`text-xs font-bold px-2.5 py-0.5 rounded-full ${
              isOverdue
                ? 'bg-rose-100 text-rose-700'
                : isAdvance
                ? 'bg-blue-100 text-blue-700'
                : 'bg-orange-100 text-orange-800'
            }`}
          >
            {isOverdue ? t('statusOverdue') : isAdvance ? 'Advance' : currentCustomer.kistStatus === 'Next' ? 'Next Kist' : t('statusDue')}
          </span>
        </div>

        <div className="flex items-center justify-between mb-4">
          <div>
            <div className="flex items-baseline gap-1">
              <span className="text-lg font-bold text-orange-600">₹</span>
              <span className="text-3xl font-extrabold text-slate-900 font-mono tabular-nums">
                {displayAmount.toLocaleString('en-IN')}
              </span>
            </div>
            <p className="text-xs text-slate-500 mt-1 flex items-center gap-1 font-medium">
              <Calendar className="w-3.5 h-3.5 text-slate-400" />
              <span>
                {t('nextDueDate')}: <strong className="text-slate-700">{finance.nextDueDate}</strong>
              </span>
            </p>
          </div>

          <button
            onClick={() => setShowQRModal(true)}
            className="px-5 py-2.5 bg-orange-600 hover:bg-orange-700 text-white font-bold rounded-xl text-xs shadow-md shadow-orange-600/20 transition-all active:scale-[0.98] flex items-center gap-1.5 cursor-pointer"
          >
            <QrCode className="w-4 h-4" />
            <span>{t('payNow')}</span>
          </button>
        </div>

        {/* Progress bar of kists */}
        <div className="pt-4 border-t border-slate-100">
          <div className="flex items-center justify-between text-xs text-slate-600 mb-1.5">
            <span>
              Installments: <strong className="text-slate-900 font-mono">{finance.paidKists}</strong> of{' '}
              <strong className="text-slate-900 font-mono">{finance.totalKists}</strong> Kists Paid
            </span>
            <span className="font-bold text-orange-600">
              {Math.round((finance.paidKists / (finance.totalKists || 1)) * 100)}%
            </span>
          </div>

          <div className="w-full bg-slate-100 rounded-full h-2 overflow-hidden">
            <div
              className="bg-orange-600 h-full rounded-full transition-all duration-500"
              style={{
                width: `${Math.min(100, (finance.paidKists / (finance.totalKists || 1)) * 100)}%`,
              }}
            ></div>
          </div>
        </div>
      </div>

      {/* Promotional Banner */}
      <div
        onClick={() => onNavigateTab('coupons')}
        className="bg-gradient-to-r from-amber-50 to-orange-50 border border-orange-200/80 rounded-2xl p-4 flex items-center justify-between cursor-pointer hover:shadow-xs transition-shadow"
      >
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-orange-600 text-white flex items-center justify-center shrink-0 shadow-xs">
            <Sparkles className="w-5 h-5" />
          </div>
          <div>
            <h5 className="font-bold text-xs text-slate-900">
              Exclusive Festive Offers Active!
            </h5>
            <p className="text-[11px] text-slate-600">
              Save up to ₹50,000 on installments and registry fees.
            </p>
          </div>
        </div>
        <ChevronRight className="w-4 h-4 text-orange-600 shrink-0" />
      </div>

      {showQRModal && (
        <QRScanModal
          initialAmount={finance.monthlyKist}
          onClose={() => setShowQRModal(false)}
        />
      )}
    </div>
  );
};
