import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  CreditCard,
  QrCode,
  Calendar,
  CheckCircle2,
  Clock,
  XCircle,
  FileText,
  ArrowRight,
  TrendingDown,
  Layers,
  ChevronRight,
  ShieldCheck,
} from 'lucide-react';
import { PaymentRecord } from '../../types';
import { QRScanModal } from '../common/QRScanModal';
import { ReceiptModal } from '../common/ReceiptModal';

export const CustomerPayments: React.FC = () => {
  const {
    currentCustomer,
    customerProperty,
    customerPayments,
    calculateCustomerFinance,
    t,
  } = useApp();

  const [showQRModal, setShowQRModal] = useState<boolean>(false);
  const [qrPayAmount, setQrPayAmount] = useState<number>(12500);
  const [selectedReceipt, setSelectedReceipt] = useState<PaymentRecord | null>(null);
  const [customAmountInput, setCustomAmountInput] = useState<string>('');
  const [isCustomMode, setIsCustomMode] = useState<boolean>(false);

  if (!currentCustomer) return null;

  const finance = calculateCustomerFinance(currentCustomer);
  const isOverdue = currentCustomer.kistStatus === 'Due' || currentCustomer.status === 'Due';
  const isAdvance = currentCustomer.kistStatus === 'Advance';

  const handlePayDueKist = () => {
    setQrPayAmount(finance.dueAmount > 0 ? finance.dueAmount : finance.monthlyKist);
    setShowQRModal(true);
  };

  const handlePayNextKist = () => {
    setQrPayAmount(finance.monthlyKist);
    setShowQRModal(true);
  };

  const handlePayCustom = () => {
    const val = parseFloat(customAmountInput);
    if (!val || val <= 0) {
      alert('Please enter a valid payment amount.');
      return;
    }
    setQrPayAmount(val);
    setShowQRModal(true);
    setIsCustomMode(false);
  };

  return (
    <div className="space-y-5 pb-8 animate-in fade-in duration-200">
      {/* Top Title */}
      <div>
        <h2 className="text-xl sm:text-2xl font-bold text-slate-900">
          {t('paymentKistDetails')}
        </h2>
        <p className="text-xs text-slate-500 mt-0.5">
          Plot No. {customerProperty?.plotNumber || '12A'} · {currentCustomer.name} (ID: {currentCustomer.id})
        </p>
      </div>

      {/* Main Financial Summary Card (Matching Wireframe Screen 7) */}
      <div className="bg-gradient-to-br from-amber-50/90 via-orange-50/50 to-white rounded-3xl p-6 border border-orange-200 shadow-sm">
        {/* Total Property Value Banner */}
        <div className="text-center pb-5 border-b border-orange-100">
          <span className="text-xs font-semibold uppercase tracking-wider text-slate-500 block mb-1">
            {t('totalPropertyValue')}
          </span>
          <div className="flex items-baseline justify-center gap-1">
            <span className="text-xl font-bold text-orange-600">₹</span>
            <span className="text-3xl sm:text-4xl font-black text-slate-900 font-mono tabular-nums">
              {finance.totalValue.toLocaleString('en-IN')}
            </span>
          </div>
        </div>

        {/* 2-Column Key Metrics */}
        <div className="grid grid-cols-2 gap-4 py-5 border-b border-orange-100 text-xs">
          <div>
            <span className="text-slate-400 block mb-0.5">{t('bookingAmount')}</span>
            <span className="font-bold text-slate-900 text-sm font-mono">
              ₹{currentCustomer.bookingAmountPaid.toLocaleString('en-IN')}
            </span>
          </div>

          <div>
            <span className="text-slate-400 block mb-0.5">{t('monthlyKist')}</span>
            <span className="font-bold text-slate-900 text-sm font-mono">
              ₹{finance.monthlyKist.toLocaleString('en-IN')}
            </span>
          </div>

          <div>
            <span className="text-slate-400 block mb-0.5">{t('totalPaid')}</span>
            <span className="font-bold text-emerald-600 text-sm font-mono">
              ₹{finance.totalPaid.toLocaleString('en-IN')}
            </span>
          </div>

          <div>
            <span className="text-slate-400 block mb-0.5">Remaining Balance</span>
            <span className="font-bold text-slate-900 text-sm font-mono">
              ₹{finance.remainingAmount.toLocaleString('en-IN')}
            </span>
          </div>
        </div>

        {/* Kist Progress Counts */}
        <div className="grid grid-cols-3 gap-2 py-4 text-center border-b border-orange-100 text-xs">
          <div className="p-2 bg-white/80 rounded-xl border border-orange-100">
            <span className="text-slate-400 block text-[10px] uppercase font-semibold">
              {t('totalKists')}
            </span>
            <span className="font-mono font-black text-slate-900 text-base">
              {finance.totalKists}
            </span>
          </div>

          <div className="p-2 bg-emerald-50 rounded-xl border border-emerald-100">
            <span className="text-emerald-700 block text-[10px] uppercase font-semibold">
              {t('paidKists')}
            </span>
            <span className="font-mono font-black text-emerald-800 text-base">
              {finance.paidKists}
            </span>
          </div>

          <div className="p-2 bg-orange-50 rounded-xl border border-orange-100">
            <span className="text-orange-700 block text-[10px] uppercase font-semibold">
              {t('remainingKists')}
            </span>
            <span className="font-mono font-black text-orange-800 text-base">
              {finance.remainingKists}
            </span>
          </div>
        </div>

        {/* Due Amount Highlight */}
        <div className="pt-5 flex items-center justify-between">
          <div>
            <span className="text-xs font-bold uppercase tracking-wider text-slate-500 block mb-0.5">
              {t('dueAmount')}
            </span>
            <span
              className={`font-mono text-xl sm:text-2xl font-black ${
                isOverdue ? 'text-rose-600' : 'text-orange-600'
              }`}
            >
              ₹{finance.dueAmount > 0 ? finance.dueAmount.toLocaleString('en-IN') : '0'}
            </span>
            <p className="text-[11px] text-slate-500 mt-0.5 flex items-center gap-1 font-medium">
              <Calendar className="w-3.5 h-3.5 text-slate-400" />
              <span>Due Date: {finance.nextDueDate}</span>
            </p>
          </div>

          <span
            className={`text-xs font-bold px-3 py-1 rounded-full uppercase tracking-wider ${
              finance.dueAmount === 0
                ? 'bg-emerald-100 text-emerald-800'
                : isOverdue
                ? 'bg-rose-100 text-rose-700'
                : isAdvance
                ? 'bg-blue-100 text-blue-700'
                : 'bg-orange-100 text-orange-800'
            }`}
          >
            {finance.dueAmount === 0
              ? t('statusPaid')
              : isOverdue
              ? t('statusOverdue')
              : isAdvance
              ? 'Advance'
              : currentCustomer.kistStatus === 'Next'
              ? 'Next Kist'
              : t('statusDue')}
          </span>
        </div>
      </div>

      {/* Action Payment Buttons - Option to pay Kist: Due or Next */}
      <div className="space-y-3">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {/* Option A: Pay Due Kist */}
          <button
            onClick={handlePayDueKist}
            className="p-4 bg-orange-600 hover:bg-orange-700 text-white rounded-2xl shadow-md shadow-orange-600/20 text-left transition-all active:scale-[0.98] cursor-pointer flex flex-col justify-between"
          >
            <div className="flex items-center justify-between mb-2">
              <span className="text-[10px] font-bold uppercase tracking-wider text-orange-200">
                Option 1: Pay Due Kist
              </span>
              <span className="p-1 rounded-lg bg-white/20 text-white">
                <QrCode className="w-4 h-4" />
              </span>
            </div>
            <div>
              <span className="font-bold text-xs block text-orange-100">Current Due Amount</span>
              <span className="text-xl font-black font-mono">
                ₹{finance.dueAmount > 0 ? finance.dueAmount.toLocaleString('en-IN') : finance.monthlyKist.toLocaleString('en-IN')}
              </span>
            </div>
          </button>

          {/* Option B: Pay Next Kist */}
          <button
            onClick={handlePayNextKist}
            className="p-4 bg-slate-900 hover:bg-slate-800 text-white rounded-2xl shadow-md text-left transition-all active:scale-[0.98] cursor-pointer flex flex-col justify-between border border-slate-800"
          >
            <div className="flex items-center justify-between mb-2">
              <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
                Option 2: Pay Next Kist
              </span>
              <span className="p-1 rounded-lg bg-white/10 text-white">
                <Calendar className="w-4 h-4" />
              </span>
            </div>
            <div>
              <span className="font-bold text-xs block text-slate-300">
                Next Scheduled Kist (#{Math.min(finance.totalKists, finance.paidKists + 1)})
              </span>
              <span className="text-xl font-black font-mono text-orange-400">
                ₹{finance.monthlyKist.toLocaleString('en-IN')}
              </span>
            </div>
          </button>
        </div>

        {/* Custom Amount / Remaining Balance */}
        {!isCustomMode ? (
          <div className="flex gap-2">
            <button
              onClick={() => setIsCustomMode(true)}
              className="flex-1 py-3 bg-white hover:bg-slate-50 text-slate-700 font-semibold rounded-2xl text-xs border border-slate-300 transition-colors cursor-pointer"
            >
              {t('payCustomAmount')}
            </button>
            {finance.remainingAmount > 0 && (
              <button
                onClick={() => {
                  setQrPayAmount(finance.remainingAmount);
                  setShowQRModal(true);
                }}
                className="py-3 px-4 bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold rounded-2xl text-xs border border-slate-200 transition-colors cursor-pointer"
              >
                Pay Full Balance
              </button>
            )}
          </div>
        ) : (
          <div className="bg-white p-4 rounded-2xl border border-slate-300 space-y-3">
            <label className="block text-xs font-semibold text-slate-700">
              Enter Custom Payment Amount (₹)
            </label>
            <div className="flex gap-2">
              <input
                type="number"
                placeholder="e.g. 25000"
                value={customAmountInput}
                onChange={(e) => setCustomAmountInput(e.target.value)}
                className="flex-1 px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-sm font-mono"
              />
              <button
                onClick={handlePayCustom}
                className="px-4 py-2.5 bg-orange-600 text-white font-bold rounded-xl text-xs cursor-pointer"
              >
                Proceed
              </button>
              <button
                onClick={() => setIsCustomMode(false)}
                className="px-3 py-2.5 bg-slate-100 text-slate-600 font-medium rounded-xl text-xs cursor-pointer"
              >
                Cancel
              </button>
            </div>
            {/* Quick Chips */}
            <div className="flex flex-wrap gap-1.5 pt-1">
              {[5000, 10000, 12500, 25000, 50000].map((amt) => (
                <button
                  key={amt}
                  type="button"
                  onClick={() => setCustomAmountInput(amt.toString())}
                  className="px-2.5 py-1 bg-slate-100 hover:bg-orange-50 hover:text-orange-600 text-slate-600 rounded-lg text-[11px] font-mono font-semibold cursor-pointer"
                >
                  ₹{amt.toLocaleString('en-IN')}
                </button>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Payment History List (Matching Wireframe Screen 7 & Requirements) */}
      <div className="bg-white rounded-3xl p-5 border border-slate-200 shadow-xs">
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-bold text-sm text-slate-900 flex items-center gap-2">
            <CreditCard className="w-4 h-4 text-orange-600" />
            <span>{t('paymentHistory')}</span>
          </h3>
          <span className="text-xs text-slate-400 font-mono">
            {customerPayments.length} Records
          </span>
        </div>

        {customerPayments.length === 0 ? (
          <p className="text-xs text-slate-400 text-center py-6 italic">
            {t('noPaymentsFound')}
          </p>
        ) : (
          <div className="space-y-3">
            {customerPayments.map((p) => {
              const isApproved = p.status === 'Approved';
              const isPending = p.status === 'Pending Verification';
              const isRejected = p.status === 'Rejected';

              return (
                <div
                  key={p.id}
                  className="p-4 rounded-2xl border border-slate-200 hover:border-orange-200 transition-colors bg-white shadow-2xs"
                >
                  <div className="flex items-start justify-between gap-3 mb-2">
                    <div>
                      <div className="flex items-center gap-2 mb-1">
                        <span className="font-bold text-sm text-slate-900">
                          {p.kistNumber === 0 ? 'Plot Booking Advance' : `Kist #${p.kistNumber}`}
                        </span>
                        <span
                          className={`text-[10px] font-bold px-2 py-0.5 rounded-md uppercase tracking-wider ${
                            isApproved
                              ? 'bg-emerald-100 text-emerald-800'
                              : isPending
                              ? 'bg-amber-100 text-amber-800'
                              : 'bg-rose-100 text-rose-800'
                          }`}
                        >
                          {p.status}
                        </span>
                      </div>
                      <p className="text-xs text-slate-500 font-mono">
                        Date: {p.paymentDate} · Method: {p.paymentMethod}
                      </p>
                      <p className="text-xs text-slate-400 font-mono">
                        Txn / UTR: {p.transactionId}
                      </p>
                    </div>

                    <div className="text-right">
                      <span className="font-mono font-black text-slate-900 text-base block">
                        ₹{p.amount.toLocaleString('en-IN')}
                      </span>
                      {isApproved && (
                        <button
                          onClick={() => setSelectedReceipt(p)}
                          className="mt-1 text-xs text-orange-600 font-semibold hover:underline inline-flex items-center gap-1 cursor-pointer"
                        >
                          <FileText className="w-3.5 h-3.5" />
                          <span>{t('receipt')}</span>
                        </button>
                      )}
                    </div>
                  </div>

                  {p.notes && (
                    <div className="mt-2 pt-2 border-t border-slate-100 text-[11px] text-slate-500">
                      <span>Note: {p.notes}</span>
                    </div>
                  )}

                  {isRejected && p.rejectionReason && (
                    <div className="mt-2 pt-2 border-t border-rose-100 text-xs text-rose-700 bg-rose-50 p-2 rounded-lg">
                      <span>Reason: {p.rejectionReason}</span>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* QR Payment Modal */}
      {showQRModal && (
        <QRScanModal
          initialAmount={qrPayAmount}
          onClose={() => setShowQRModal(false)}
        />
      )}

      {/* Printable Receipt Modal */}
      {selectedReceipt && (
        <ReceiptModal
          payment={selectedReceipt}
          customer={currentCustomer}
          property={customerProperty}
          onClose={() => setSelectedReceipt(null)}
        />
      )}
    </div>
  );
};
