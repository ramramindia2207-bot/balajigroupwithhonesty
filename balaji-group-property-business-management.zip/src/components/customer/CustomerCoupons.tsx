import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { Tag, Sparkles, Check, Copy, ArrowRight, Gift, AlertCircle, Info, X } from 'lucide-react';
import { Coupon } from '../../types';

interface CustomerCouponsProps {
  onNavigateTab?: (tab: string) => void;
}

export const CustomerCoupons: React.FC<CustomerCouponsProps> = ({ onNavigateTab }) => {
  const { coupons, appliedCoupon, applyCouponCode, removeAppliedCoupon, t } = useApp();
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [inputCode, setInputCode] = useState<string>('');
  const [message, setMessage] = useState<{ text: string; type: 'success' | 'error' } | null>(null);
  const [viewingCouponTerms, setViewingCouponTerms] = useState<Coupon | null>(null);

  const categories = ['All', 'Special', 'Festive', 'Referral'];

  const filteredCoupons = coupons.filter((c) => {
    if (selectedCategory === 'All') return true;
    return c.category.toLowerCase() === selectedCategory.toLowerCase();
  });

  const handleApply = (codeToApply?: string) => {
    const code = (codeToApply || inputCode).trim();
    if (!code) {
      setMessage({ text: 'Please enter a coupon code.', type: 'error' });
      return;
    }

    const res = applyCouponCode(code);
    if (res.success) {
      setMessage({ text: res.message, type: 'success' });
      setInputCode(res.coupon?.code || '');
    } else {
      setMessage({ text: res.message, type: 'error' });
    }
  };

  return (
    <div className="space-y-5 pb-8 animate-in fade-in duration-200">
      {/* Exclusive Offers Banner (Matching Wireframe Screen 9) */}
      <div className="bg-gradient-to-r from-orange-600 via-orange-500 to-amber-500 rounded-3xl p-6 text-white shadow-xl relative overflow-hidden">
        <div className="relative z-10 flex items-center justify-between">
          <div className="max-w-xs">
            <span className="text-[11px] font-bold uppercase tracking-wider text-orange-200 block mb-1">
              Save on Installments & Plots
            </span>
            <h2 className="text-2xl font-black tracking-tight">{t('exclusiveOffers')}</h2>
            <p className="text-xs text-orange-100 mt-1 leading-relaxed">
              {t('saveMoreProperty')}
            </p>
          </div>

          <div className="w-14 h-14 rounded-2xl bg-white/20 backdrop-blur-md flex items-center justify-center shrink-0 border border-white/30 shadow-inner">
            <Gift className="w-8 h-8 text-white" />
          </div>
        </div>
      </div>

      {/* Applied Coupon Banner */}
      {appliedCoupon && (
        <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-2xl flex items-center justify-between animate-in fade-in">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-emerald-600 text-white flex items-center justify-center shrink-0">
              <Check className="w-4 h-4" />
            </div>
            <div>
              <p className="text-xs font-bold text-emerald-900">
                Coupon <span className="font-mono">{appliedCoupon.code}</span> Active
              </p>
              <p className="text-[11px] text-emerald-700">
                {appliedCoupon.discountAmount
                  ? `Flat ₹${appliedCoupon.discountAmount.toLocaleString('en-IN')} will be deducted from your next payment!`
                  : `${appliedCoupon.discountPercentage}% discount applied on next payment!`}
              </p>
            </div>
          </div>
          <button
            onClick={removeAppliedCoupon}
            className="text-xs text-rose-600 hover:underline font-semibold cursor-pointer"
          >
            Remove
          </button>
        </div>
      )}

      {/* Apply Coupon Input Box */}
      <div className="bg-white rounded-2xl p-4 border border-slate-200 shadow-xs">
        <label className="block text-xs font-semibold text-slate-700 mb-2">
          {t('enterCouponCode')}
        </label>
        <div className="flex gap-2">
          <input
            type="text"
            placeholder="e.g. BALAJI50K"
            value={inputCode}
            onChange={(e) => {
              setInputCode(e.target.value.toUpperCase());
              setMessage(null);
            }}
            className="flex-1 px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-mono uppercase font-bold text-slate-900 focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-orange-500"
          />
          <button
            type="button"
            onClick={() => handleApply()}
            className="px-5 py-2.5 bg-orange-600 hover:bg-orange-700 text-white font-bold rounded-xl text-xs transition-colors cursor-pointer shadow-sm"
          >
            {t('applyCoupon')}
          </button>
        </div>

        {message && (
          <p
            className={`text-xs mt-2 font-medium ${
              message.type === 'success' ? 'text-emerald-600' : 'text-rose-600'
            }`}
          >
            {message.text}
          </p>
        )}
      </div>

      {/* Category Filter Tabs (Matching Wireframe Screen 9) */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1">
        {categories.map((cat) => (
          <button
            key={cat}
            onClick={() => setSelectedCategory(cat)}
            className={`px-4 py-1.5 rounded-full text-xs font-semibold whitespace-nowrap transition-colors cursor-pointer ${
              selectedCategory === cat
                ? 'bg-orange-600 text-white shadow-xs'
                : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200'
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      {/* Coupons List Cards */}
      <div className="space-y-3">
        {filteredCoupons.map((coupon) => {
          const isCurrentApplied = appliedCoupon?.id === coupon.id;

          return (
            <div
              key={coupon.id}
              className={`bg-white rounded-2xl p-4 border transition-all shadow-xs ${
                isCurrentApplied
                  ? 'border-emerald-500 ring-2 ring-emerald-500/20'
                  : 'border-slate-200 hover:border-orange-300'
              }`}
            >
              <div className="flex items-start justify-between gap-3">
                <div className="flex items-start gap-3">
                  <div className="w-10 h-10 rounded-xl bg-orange-100 text-orange-600 flex items-center justify-center shrink-0 mt-0.5">
                    <Tag className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="font-extrabold text-sm text-slate-900">{coupon.name}</h3>
                    <div className="flex items-center gap-2 mt-1">
                      <span className="font-mono text-xs font-bold text-orange-600 bg-orange-50 border border-orange-200/60 px-2 py-0.5 rounded">
                        {coupon.code}
                      </span>
                      <span className="text-[11px] text-slate-400">
                        {t('validTill')} {coupon.validUntil}
                      </span>
                    </div>
                  </div>
                </div>

                <div className="flex flex-col items-end gap-2">
                  {isCurrentApplied ? (
                    <span className="text-xs font-bold text-emerald-600 flex items-center gap-1">
                      <Check className="w-3.5 h-3.5" />
                      <span>Applied</span>
                    </span>
                  ) : (
                    <button
                      onClick={() => handleApply(coupon.code)}
                      className="px-3 py-1 bg-orange-50 hover:bg-orange-100 text-orange-700 rounded-lg text-xs font-bold border border-orange-200 transition-colors cursor-pointer"
                    >
                      Apply
                    </button>
                  )}
                  <button
                    onClick={() => setViewingCouponTerms(coupon)}
                    className="text-[11px] text-slate-400 hover:text-slate-700 underline cursor-pointer"
                  >
                    View
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Terms & Conditions Modal */}
      {viewingCouponTerms && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-md rounded-2xl shadow-xl border border-slate-200 p-6 animate-in fade-in">
            <div className="flex items-center justify-between mb-4 pb-2 border-b border-slate-100">
              <h4 className="font-bold text-slate-900 text-base">Coupon Details</h4>
              <button
                onClick={() => setViewingCouponTerms(null)}
                className="p-1 hover:bg-slate-100 rounded-lg text-slate-400 hover:text-slate-700"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3 text-xs text-slate-600">
              <div className="p-3 bg-orange-50 rounded-xl border border-orange-200/60">
                <span className="text-xs uppercase font-bold text-orange-700 block mb-1">
                  Coupon Code
                </span>
                <span className="font-mono text-lg font-black text-slate-900">
                  {viewingCouponTerms.code}
                </span>
                <p className="text-xs text-slate-700 font-semibold mt-1">
                  {viewingCouponTerms.name}
                </p>
              </div>

              <div>
                <strong className="text-slate-800">Validity:</strong>{' '}
                {viewingCouponTerms.validFrom} to {viewingCouponTerms.validUntil}
              </div>

              <div>
                <strong className="text-slate-800">Conditions:</strong>
                <p className="mt-1 leading-relaxed">{viewingCouponTerms.conditions}</p>
              </div>

              <div>
                <strong className="text-slate-800">Usage Limit:</strong> Limited to{' '}
                {viewingCouponTerms.maxUsageLimit} redemptions. (
                {viewingCouponTerms.currentUsageCount} redeemed so far)
              </div>
            </div>

            <div className="mt-6 flex gap-2">
              <button
                onClick={() => setViewingCouponTerms(null)}
                className="flex-1 py-2.5 bg-slate-100 text-slate-700 font-semibold rounded-xl text-xs cursor-pointer"
              >
                Close
              </button>
              <button
                onClick={() => {
                  handleApply(viewingCouponTerms.code);
                  setViewingCouponTerms(null);
                }}
                className="flex-1 py-2.5 bg-orange-600 text-white font-semibold rounded-xl text-xs cursor-pointer"
              >
                Apply Coupon
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
