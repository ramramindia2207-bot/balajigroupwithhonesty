import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Headphones,
  Mail,
  Phone,
  MessageSquare,
  MapPin,
  Clock,
  HelpCircle,
  Send,
  CheckCircle2,
  ChevronDown,
  ChevronUp,
  Ticket,
  AlertCircle,
} from 'lucide-react';
import { SupportTicket } from '../../types';

export const CustomerHelp: React.FC = () => {
  const { currentCustomer, customerProperty, supportTickets, createSupportTicket, settings, t } = useApp();

  const [activeFaq, setActiveFaq] = useState<number | null>(0);
  const [subject, setSubject] = useState<string>('');
  const [category, setCategory] = useState<any>('Kist Inquiry');
  const [message, setMessage] = useState<string>('');
  const [submittedTicket, setSubmittedTicket] = useState<string | null>(null);
  const [error, setError] = useState<string>('');

  if (!currentCustomer) return null;

  // Filter tickets for this customer
  const myTickets = supportTickets.filter((t) => t.customerId === currentCustomer.id);

  const faqs = [
    {
      q: 'How are my monthly installments (Kists) tracked?',
      a: 'Every approved payment automatically updates your paid kist count, reduces the remaining balance, and computes your next scheduled due date. You can view all records in the Payments tab.',
    },
    {
      q: 'When do I receive my official property registry documents?',
      a: 'Registry execution is initiated immediately upon completing the required registry installment milestone. Stamped copies are uploaded directly into your Property Documents section.',
    },
    {
      q: 'How does UPI QR verification work?',
      a: 'When you make a payment via Google Pay, PhonePe, Paytm, or BHIM, copy the 12-digit UTR/Transaction ID and submit it through the app. Our accounts desk verifies the credit with our ICICI Bank portal and confirms within 2 to 4 business hours.',
    },
    {
      q: 'Can I visit my plot or request boundary demarcation?',
      a: 'Yes, our on-site team is available Monday to Saturday at Green Valley, Chhatarpur. You can submit a site visit request right here under "Plot Visit" or call our helpline directly.',
    },
  ];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!subject.trim() || !message.trim()) {
      setError('Please provide both a subject and message.');
      return;
    }

    const newTicket = createSupportTicket({
      customerId: currentCustomer.id,
      subject: subject.trim(),
      category,
      message: message.trim(),
    });

    setSubmittedTicket(newTicket.ticketNumber);
    setSubject('');
    setMessage('');
    setError('');
  };

  return (
    <div className="space-y-6 pb-8 animate-in fade-in duration-200">
      {/* Top Graphic Header (Matching Wireframe Screen 11) */}
      <div className="text-center py-4">
        <div className="w-16 h-16 bg-orange-100 text-orange-600 rounded-3xl flex items-center justify-center mx-auto mb-3 shadow-inner">
          <Headphones className="w-8 h-8" />
        </div>
        <h2 className="text-2xl font-black text-slate-900">{t('needHelp')}</h2>
        <p className="text-xs text-slate-500 max-w-xs mx-auto mt-1">
          {t('hereToAssist')}
        </p>
      </div>

      {/* Contact Channels Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        <a
          href={`mailto:${settings.email}`}
          className="flex items-center gap-3.5 p-4 bg-white rounded-2xl border border-slate-200 hover:border-orange-300 hover:shadow-xs transition-all group"
        >
          <div className="w-10 h-10 rounded-xl bg-orange-50 text-orange-600 flex items-center justify-center shrink-0 group-hover:scale-105 transition-transform">
            <Mail className="w-5 h-5" />
          </div>
          <div className="min-w-0">
            <h4 className="text-xs font-bold text-slate-900">{t('emailSupport')}</h4>
            <p className="text-xs text-slate-500 truncate font-mono">{settings.email}</p>
          </div>
        </a>

        <a
          href={`tel:${settings.phone}`}
          className="flex items-center gap-3.5 p-4 bg-white rounded-2xl border border-slate-200 hover:border-orange-300 hover:shadow-xs transition-all group"
        >
          <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center shrink-0 group-hover:scale-105 transition-transform">
            <Phone className="w-5 h-5" />
          </div>
          <div className="min-w-0">
            <h4 className="text-xs font-bold text-slate-900">{t('callUs')}</h4>
            <p className="text-xs text-slate-500 truncate font-mono">{settings.phone}</p>
          </div>
        </a>

        <a
          href={`https://wa.me/${settings.whatsapp.replace(/\D/g, '')}`}
          target="_blank"
          rel="noopener noreferrer"
          className="flex items-center gap-3.5 p-4 bg-white rounded-2xl border border-slate-200 hover:border-orange-300 hover:shadow-xs transition-all group"
        >
          <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center shrink-0 group-hover:scale-105 transition-transform">
            <MessageSquare className="w-5 h-5" />
          </div>
          <div className="min-w-0">
            <h4 className="text-xs font-bold text-slate-900">{t('whatsappSupport')}</h4>
            <p className="text-xs text-slate-500 truncate">Instant Chat with Helpdesk</p>
          </div>
        </a>

        <div className="flex items-center gap-3.5 p-4 bg-white rounded-2xl border border-slate-200">
          <div className="w-10 h-10 rounded-xl bg-sky-50 text-sky-600 flex items-center justify-center shrink-0">
            <Clock className="w-5 h-5" />
          </div>
          <div className="min-w-0">
            <h4 className="text-xs font-bold text-slate-900">{t('businessHours')}</h4>
            <p className="text-xs text-slate-500 truncate">{settings.officeHours}</p>
          </div>
        </div>
      </div>

      {/* Office Address Card */}
      <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 text-xs text-slate-600 flex items-start gap-3">
        <MapPin className="w-4 h-4 text-orange-600 shrink-0 mt-0.5" />
        <div>
          <strong className="text-slate-900 block mb-0.5">{t('officeAddress')}</strong>
          <span>{settings.address}</span>
        </div>
      </div>

      {/* Submit Support Request Form */}
      <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm">
        <h3 className="text-sm font-bold text-slate-900 mb-1 flex items-center gap-2">
          <Send className="w-4 h-4 text-orange-600" />
          <span>{t('submitSupportTicket')}</span>
        </h3>
        <p className="text-xs text-slate-500 mb-4">
          Direct communication with Balaji documentation & accounts desks.
        </p>

        {submittedTicket && (
          <div className="mb-4 p-4 bg-emerald-50 border border-emerald-200 rounded-2xl flex items-center gap-3">
            <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
            <div className="text-xs text-emerald-900">
              <p className="font-bold">Ticket Submitted Successfully!</p>
              <p className="text-emerald-700">
                Your ticket number is <strong className="font-mono">{submittedTicket}</strong>. Our team will respond shortly.
              </p>
            </div>
          </div>
        )}

        {error && (
          <div className="mb-4 p-3 bg-rose-50 border border-rose-200 rounded-xl text-xs text-rose-700 flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{error}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-3">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                {t('category')}
              </label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value as any)}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:ring-2 focus:ring-orange-500 text-slate-900"
              >
                <option value="Kist Inquiry">Kist / Installment Inquiry</option>
                <option value="Payment Issue">Payment Verification Issue</option>
                <option value="Registry & Documents">Registry & Legal Documents</option>
                <option value="Plot Visit">Site Visit & Demarcation</option>
                <option value="General">General Inquiry</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Plot Reference
              </label>
              <input
                type="text"
                disabled
                value={`Plot ${customerProperty?.plotNumber || '12A'}`}
                className="w-full px-3 py-2 bg-slate-100 border border-slate-200 rounded-xl text-xs font-medium text-slate-600"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              {t('subject')} <span className="text-red-500">*</span>
            </label>
            <input
              type="text"
              placeholder="e.g. Need clarification on receipt #RCP-2026-0842"
              value={subject}
              onChange={(e) => setSubject(e.target.value)}
              required
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:bg-white focus:ring-2 focus:ring-orange-500 text-slate-900"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              {t('message')} <span className="text-red-500">*</span>
            </label>
            <textarea
              rows={3}
              placeholder="Type your question or request in detail..."
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              required
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:bg-white focus:ring-2 focus:ring-orange-500 text-slate-900 resize-none"
            ></textarea>
          </div>

          <button
            type="submit"
            className="w-full py-3 bg-orange-600 hover:bg-orange-700 text-white font-bold rounded-xl text-xs shadow-md shadow-orange-600/20 transition-all cursor-pointer flex items-center justify-center gap-2"
          >
            <Send className="w-3.5 h-3.5" />
            <span>{t('sendTicket')}</span>
          </button>
        </form>
      </div>

      {/* Your Submitted Tickets Tracker */}
      {myTickets.length > 0 && (
        <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm">
          <h3 className="text-sm font-bold text-slate-900 mb-3 flex items-center gap-2">
            <Ticket className="w-4 h-4 text-orange-600" />
            <span>Your Support Requests ({myTickets.length})</span>
          </h3>

          <div className="space-y-3">
            {myTickets.map((tkt) => (
              <div
                key={tkt.id}
                className="p-4 rounded-2xl border border-slate-200 bg-slate-50/50 space-y-2 text-xs"
              >
                <div className="flex items-center justify-between">
                  <span className="font-mono font-bold text-orange-600">{tkt.ticketNumber}</span>
                  <span
                    className={`px-2 py-0.5 rounded-full text-[10px] font-bold uppercase ${
                      tkt.status === 'Resolved'
                        ? 'bg-emerald-100 text-emerald-800'
                        : tkt.status === 'Pending'
                        ? 'bg-amber-100 text-amber-800'
                        : 'bg-blue-100 text-blue-800'
                    }`}
                  >
                    {tkt.status}
                  </span>
                </div>

                <p className="font-semibold text-slate-900">{tkt.subject}</p>
                <p className="text-slate-600 leading-relaxed">{tkt.message}</p>
                <p className="text-[10px] text-slate-400">Created: {tkt.createdAt}</p>

                {tkt.adminReply && (
                  <div className="mt-2 p-3 bg-white rounded-xl border border-orange-200 text-xs">
                    <p className="font-bold text-orange-700 mb-0.5 flex items-center gap-1">
                      <span>Balaji Response ({tkt.repliedBy || 'Support Team'}):</span>
                    </p>
                    <p className="text-slate-700 leading-relaxed">{tkt.adminReply}</p>
                    <p className="text-[10px] text-slate-400 mt-1">{tkt.repliedAt}</p>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Frequently Asked Questions (Accordion) */}
      <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm">
        <h3 className="text-sm font-bold text-slate-900 mb-3 flex items-center gap-2">
          <HelpCircle className="w-4 h-4 text-orange-600" />
          <span>{t('faqs')}</span>
        </h3>

        <div className="divide-y divide-slate-100">
          {faqs.map((faq, idx) => {
            const isOpen = activeFaq === idx;
            return (
              <div key={idx} className="py-3">
                <button
                  onClick={() => setActiveFaq(isOpen ? null : idx)}
                  className="w-full text-left flex items-center justify-between gap-3 text-xs font-bold text-slate-900 hover:text-orange-600 transition-colors cursor-pointer"
                >
                  <span>{faq.q}</span>
                  {isOpen ? (
                    <ChevronUp className="w-4 h-4 text-orange-600 shrink-0" />
                  ) : (
                    <ChevronDown className="w-4 h-4 text-slate-400 shrink-0" />
                  )}
                </button>
                {isOpen && (
                  <p className="text-xs text-slate-600 leading-relaxed mt-2 pl-1 animate-in fade-in">
                    {faq.a}
                  </p>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
