import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  MapPin,
  FileText,
  Download,
  Eye,
  CheckCircle,
  Calendar,
  Layers,
  Maximize2,
  ShieldCheck,
  User,
  Phone,
  Home,
  X,
} from 'lucide-react';
import { PropertyDocument } from '../../types';

export const CustomerProperty: React.FC = () => {
  const { currentCustomer, customerProperty, t } = useApp();
  const [selectedDoc, setSelectedDoc] = useState<PropertyDocument | null>(null);

  if (!currentCustomer) return null;

  if (!customerProperty) {
    return (
      <div className="bg-white rounded-3xl p-8 border border-slate-200 text-center max-w-md mx-auto my-8">
        <Home className="w-12 h-12 text-slate-300 mx-auto mb-3" />
        <h3 className="text-base font-bold text-slate-800">No Property Assigned</h3>
        <p className="text-xs text-slate-500 mt-1 max-w-xs mx-auto">
          {t('pendingAdminAssignment')}
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-5 pb-8 animate-in fade-in duration-200">
      {/* Property Hero Image with Overlay */}
      <div className="relative rounded-3xl overflow-hidden shadow-md border border-slate-200 bg-slate-900">
        <img
          src={customerProperty.imageUrl || '/src/assets/images/balaji_plot_greenvalley_1791042223890.jpg'}
          alt={customerProperty.title}
          referrerPolicy="no-referrer"
          className="w-full h-56 sm:h-64 object-cover brightness-90"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-slate-950/85 via-slate-950/30 to-transparent flex flex-col justify-end p-5 text-white">
          <div className="flex items-center gap-2 mb-1.5">
            <span className="px-2.5 py-0.5 bg-orange-600 text-white text-[11px] font-bold rounded-md uppercase tracking-wider">
              {customerProperty.propertyType}
            </span>
            <span className="px-2.5 py-0.5 bg-emerald-600/90 text-white text-[11px] font-bold rounded-md">
              {customerProperty.status}
            </span>
          </div>

          <h2 className="text-2xl font-black tracking-tight text-white">
            Plot No. {customerProperty.plotNumber}
          </h2>

          <p className="text-xs text-slate-200 flex items-center gap-1 mt-1">
            <MapPin className="w-3.5 h-3.5 text-orange-400 shrink-0" />
            <span>{customerProperty.location}</span>
          </p>
        </div>
      </div>

      {/* Customer Details Card (Matching Wireframe Screen 6) */}
      <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-xs">
        <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-3 flex items-center gap-1.5">
          <User className="w-4 h-4 text-orange-600" />
          <span>{t('customerDetails')}</span>
        </h3>

        <div className="grid grid-cols-2 gap-4 text-xs">
          <div>
            <span className="text-slate-400 block mb-0.5">{t('name')}</span>
            <span className="font-bold text-slate-900 text-sm">{currentCustomer.name}</span>
          </div>
          <div>
            <span className="text-slate-400 block mb-0.5">{t('customerId')}</span>
            <span className="font-mono font-bold text-orange-600 text-sm">
              {currentCustomer.id}
            </span>
          </div>
          <div>
            <span className="text-slate-400 block mb-0.5">{t('mobileNumber')}</span>
            <span className="font-medium text-slate-800 font-mono">+91 {currentCustomer.mobile}</span>
          </div>
          <div>
            <span className="text-slate-400 block mb-0.5">Email</span>
            <span className="font-medium text-slate-800 truncate block">{currentCustomer.email}</span>
          </div>
          <div className="col-span-2">
            <span className="text-slate-400 block mb-0.5">{t('address')}</span>
            <span className="font-medium text-slate-700">{currentCustomer.address}</span>
          </div>
        </div>
      </div>

      {/* Property Information Card (Matching Wireframe Screen 6) */}
      <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-xs">
        <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-3 flex items-center gap-1.5">
          <Home className="w-4 h-4 text-orange-600" />
          <span>{t('propertyInfo')}</span>
        </h3>

        <div className="grid grid-cols-2 gap-4 text-xs">
          <div className="p-3 bg-slate-50 rounded-xl border border-slate-100">
            <span className="text-slate-400 block text-[11px] mb-0.5">{t('plotNumber')}</span>
            <span className="font-extrabold text-slate-900 text-base">
              {customerProperty.plotNumber}
            </span>
          </div>

          <div className="p-3 bg-slate-50 rounded-xl border border-slate-100">
            <span className="text-slate-400 block text-[11px] mb-0.5">{t('propertySize')}</span>
            <span className="font-extrabold text-slate-900 text-base font-mono">
              {customerProperty.propertySize}
            </span>
          </div>

          <div>
            <span className="text-slate-400 block mb-0.5">{t('propertyType')}</span>
            <span className="font-semibold text-slate-800">{customerProperty.propertyType}</span>
          </div>

          <div>
            <span className="text-slate-400 block mb-0.5">Dimensions</span>
            <span className="font-semibold text-slate-800 font-mono">
              {customerProperty.dimensions || '30 x 40 Ft.'}
            </span>
          </div>

          <div>
            <span className="text-slate-400 block mb-0.5">Booking Date</span>
            <span className="font-medium text-slate-700">{customerProperty.bookingDate}</span>
          </div>

          <div>
            <span className="text-slate-400 block mb-0.5">{t('registrationDate')}</span>
            <span className="font-medium text-slate-700">{customerProperty.registrationDate}</span>
          </div>

          <div className="col-span-2 pt-2 border-t border-slate-100">
            <span className="text-slate-400 block mb-0.5">{t('registryNumber')}</span>
            <span className="font-mono font-bold text-slate-900 text-xs bg-slate-100 px-2 py-1 rounded">
              {customerProperty.registryNumber}
            </span>
          </div>
        </div>

        {/* Township Features */}
        {customerProperty.features && customerProperty.features.length > 0 && (
          <div className="mt-4 pt-4 border-t border-slate-100">
            <span className="text-[11px] font-bold uppercase text-slate-400 block mb-2">
              Township Highlights
            </span>
            <div className="flex flex-wrap gap-1.5">
              {customerProperty.features.map((feat, idx) => (
                <span
                  key={idx}
                  className="px-2.5 py-1 bg-orange-50 text-orange-800 rounded-lg text-xs font-medium border border-orange-200/50 flex items-center gap-1"
                >
                  <CheckCircle className="w-3 h-3 text-orange-600" />
                  <span>{feat}</span>
                </span>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Property Documents Section */}
      <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-xs">
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
            <FileText className="w-4 h-4 text-orange-600" />
            <span>{t('documents')}</span>
          </h3>
          <span className="text-xs font-semibold text-slate-400">
            {customerProperty.documents.length} Files
          </span>
        </div>

        {customerProperty.documents.length === 0 ? (
          <p className="text-xs text-slate-400 italic py-3 text-center">
            {t('noDocsYet')}
          </p>
        ) : (
          <div className="space-y-2">
            {customerProperty.documents.map((doc) => (
              <div
                key={doc.id}
                className="flex items-center justify-between p-3 rounded-xl bg-slate-50 hover:bg-orange-50/40 border border-slate-200 transition-colors"
              >
                <div className="flex items-center gap-3 min-w-0">
                  <div className="w-9 h-9 rounded-lg bg-red-100 text-red-600 flex items-center justify-center shrink-0">
                    <FileText className="w-5 h-5" />
                  </div>
                  <div className="min-w-0">
                    <h4 className="text-xs font-bold text-slate-900 truncate">{doc.name}</h4>
                    <p className="text-[11px] text-slate-400 flex items-center gap-2">
                      <span>{doc.type}</span>
                      <span>·</span>
                      <span>{doc.fileSize}</span>
                      <span>·</span>
                      <span>{doc.dateUploaded}</span>
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-1.5 shrink-0 ml-2">
                  <button
                    onClick={() => setSelectedDoc(doc)}
                    className="p-2 text-slate-600 hover:text-orange-600 hover:bg-white rounded-lg transition-colors cursor-pointer"
                    title="View Document"
                  >
                    <Eye className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => setSelectedDoc(doc)}
                    className="px-2.5 py-1.5 bg-white hover:bg-slate-100 border border-slate-200 text-slate-700 text-xs font-semibold rounded-lg transition-colors cursor-pointer flex items-center gap-1"
                  >
                    <Download className="w-3 h-3 text-slate-500" />
                    <span className="hidden sm:inline">Download</span>
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Document Preview Modal */}
      {selectedDoc && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-lg rounded-2xl shadow-2xl overflow-hidden border border-slate-200 animate-in fade-in duration-200">
            <div className="bg-slate-900 px-5 py-4 text-white flex items-center justify-between">
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-5 h-5 text-emerald-400" />
                <h4 className="font-bold text-sm truncate">{selectedDoc.name}</h4>
              </div>
              <button
                onClick={() => setSelectedDoc(null)}
                className="p-1 hover:bg-slate-800 rounded-lg text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-6 text-center">
              <div className="w-16 h-16 bg-red-50 text-red-600 rounded-2xl flex items-center justify-center mx-auto mb-4 border border-red-200">
                <FileText className="w-8 h-8" />
              </div>

              <h4 className="font-bold text-slate-900 text-base">{selectedDoc.name}</h4>
              <p className="text-xs text-slate-500 mt-1">
                Document Type: {selectedDoc.type} · Size: {selectedDoc.fileSize}
              </p>
              <p className="text-xs text-slate-500">
                Uploaded: {selectedDoc.dateUploaded} · Verified by Balaji Documentation Desk
              </p>

              <div className="my-6 p-4 bg-slate-50 rounded-xl border border-slate-200 text-xs text-slate-600 text-left space-y-1">
                <p>
                  <strong>Owner:</strong> {currentCustomer.name} (ID: {currentCustomer.id})
                </p>
                <p>
                  <strong>Plot Assigned:</strong> Plot {customerProperty.plotNumber} ({customerProperty.propertySize})
                </p>
                <p>
                  <strong>Registry Deed No:</strong> {customerProperty.registryNumber}
                </p>
              </div>

              <div className="flex gap-3">
                <button
                  onClick={() => setSelectedDoc(null)}
                  className="flex-1 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold rounded-xl text-xs transition-colors cursor-pointer"
                >
                  Close
                </button>
                <button
                  onClick={() => {
                    alert(`Downloading verified copy of ${selectedDoc.name}`);
                    setSelectedDoc(null);
                  }}
                  className="flex-1 py-2.5 bg-orange-600 hover:bg-orange-700 text-white font-semibold rounded-xl text-xs transition-colors flex items-center justify-center gap-1.5 cursor-pointer shadow-md shadow-orange-600/20"
                >
                  <Download className="w-4 h-4" />
                  <span>Download Document</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
