import React, { useState, useEffect, useRef } from 'react';
import { BalajiLogo } from '../common/BalajiLogo';
import { useApp } from '../../context/AppContext';
import {
  Phone,
  Lock,
  ArrowRight,
  Eye,
  EyeOff,
  ArrowLeft,
  CheckCircle2,
  AlertCircle,
  Sparkles,
  User,
  MapPin,
  Mail,
  Home,
  ShieldCheck,
  Copy,
  Check,
  Smartphone,
  MessageSquare,
  KeyRound,
  MessageCircle,
  ExternalLink,
  Volume2,
  Settings,
  ChevronDown,
  ChevronUp,
  Radio,
  Send,
  Zap,
  LockKeyhole,
} from 'lucide-react';
import { AdminAccessModal } from '../common/AdminAccessModal';
import {
  sendRealTimeOtp,
  verifySessionOtp,
  getWhatsAppOtpUrl,
  getNativeWhatsAppDeepLink,
  getNativeSmsUrl,
  triggerPhoneVibration,
  playNotificationSound,
  sendNativePushNotification,
} from '../../services/smsService';

interface CustomerAuthProps {
  onSuccess: () => void;
  onBackToSplash?: () => void;
}

type AuthStep = 'login' | 'otp' | 'pin' | 'prompt_pin' | 'create_pin' | 'register' | 'success';

export const CustomerAuth: React.FC<CustomerAuthProps> = ({ onSuccess, onBackToSplash }) => {
  const {
    loginWithPhone,
    verifyOtp,
    loginWithPin,
    directSafeLogin,
    setCustomerPin,
    registerNewCustomer,
    customers,
    settings,
    updateSettings,
    t,
  } = useApp();

  const isOtpEnabled = settings.enableOtpLogin ?? true;
  const isPinEnabled = settings.enablePasswordLogin ?? true;

  // State
  const [step, setStep] = useState<AuthStep>('login');
  const [authMode, setAuthMode] = useState<'otp' | 'whatsapp' | 'pin' | 'direct'>('otp');
  const [mobile, setMobile] = useState<string>('');
  const [pin, setPin] = useState<string>('');
  const [showPin, setShowPin] = useState<boolean>(false);
  const [otpDigits, setOtpDigits] = useState<string[]>(['', '', '', '', '', '']);
  const [otpTimer, setOtpTimer] = useState<number>(30);
  const [canResend, setCanResend] = useState<boolean>(false);
  const [error, setError] = useState<string>('');
  const [showAdminModal, setShowAdminModal] = useState<boolean>(false);
  const [verifiedCustomer, setVerifiedCustomer] = useState<any>(null);
  const [smsNotification, setSmsNotification] = useState<{ message: string; isRealSms: boolean; otp?: string; provider?: string } | null>(null);
  const [isSendingOtp, setIsSendingOtp] = useState<boolean>(false);
  const [copiedOtp, setCopiedOtp] = useState<boolean>(false);

  const handleAutoFillOtp = (code?: string) => {
    const target = code || smsNotification?.otp;
    if (!target) return;
    const digits = target.slice(0, 6).split('');
    while (digits.length < 6) digits.push('');
    setOtpDigits(digits);
    setError('');
    setTimeout(() => {
      otpRefs.current[5]?.focus();
    }, 50);
  };

  const handleCopyOtp = (code?: string) => {
    const target = code || smsNotification?.otp;
    if (!target) return;
    navigator.clipboard.writeText(target);
    setCopiedOtp(true);
    setTimeout(() => setCopiedOtp(false), 2000);
  };

  // Direct Phone Delivery & Gateway configuration states
  const [showSmsKeyDrawer, setShowSmsKeyDrawer] = useState<boolean>(false);
  const [quickApiKey, setQuickApiKey] = useState<string>(settings.smsGateway?.apiKey || '');
  const [quickKeySaved, setQuickKeySaved] = useState<boolean>(false);
  const [whatsappSent, setWhatsappSent] = useState<boolean>(false);
  const [nativeSmsOpened, setNativeSmsOpened] = useState<boolean>(false);

  const handleRingAndVibrate = () => {
    triggerPhoneVibration();
    playNotificationSound();
    if (smsNotification?.otp) {
      sendNativePushNotification(smsNotification.otp, mobile);
    }
  };

  const handleSaveQuickApiKeyAndResend = async () => {
    if (!quickApiKey.trim()) return;
    updateSettings({
      smsGateway: {
        ...settings.smsGateway,
        enabled: true,
        provider: 'fast2sms',
        apiKey: quickApiKey.trim(),
      },
    });
    setQuickKeySaved(true);
    setTimeout(() => {
      setQuickKeySaved(false);
      setShowSmsKeyDrawer(false);
    }, 1500);

    // Immediately trigger SMS dispatch with the new key!
    try {
      setIsSendingOtp(true);
      const res = await sendRealTimeOtp(mobile, {
        ...settings.smsGateway,
        enabled: true,
        provider: 'fast2sms',
        apiKey: quickApiKey.trim(),
      });
      setSmsNotification({
        message: res.message,
        isRealSms: res.isRealSms,
        otp: res.otp,
        provider: res.provider,
      });
      setOtpTimer(30);
      setCanResend(false);
    } catch {
      // ignore
    } finally {
      setIsSendingOtp(false);
    }
  };

  // New PIN state
  const [newPin, setNewPin] = useState<string>('');
  const [confirmPin, setConfirmPin] = useState<string>('');
  const [showNewPin, setShowNewPin] = useState<boolean>(false);

  // New customer registration state
  const [regName, setRegName] = useState<string>('');
  const [regEmail, setRegEmail] = useState<string>('');
  const [regCity, setRegCity] = useState<string>('Delhi NCR');
  const [regAddress, setRegAddress] = useState<string>('');
  const [regPlotType, setRegPlotType] = useState<string>('Residential Plot');
  const [regBudget, setRegBudget] = useState<string>('₹ 15 Lakh - ₹ 25 Lakh');

  // Input refs for 6 OTP boxes
  const otpRefs = useRef<(HTMLInputElement | null)[]>([]);

  // Timer countdown for Resend OTP
  useEffect(() => {
    let interval: any = null;
    if (step === 'otp' && otpTimer > 0) {
      interval = setInterval(() => {
        setOtpTimer((prev) => prev - 1);
      }, 1000);
    } else if (otpTimer === 0) {
      setCanResend(true);
    }
    return () => clearInterval(interval);
  }, [step, otpTimer]);

  const handleSendOtp = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!isOtpEnabled) {
      setError('OTP Login is temporarily disabled by administrator. Please login using PIN/password.');
      setAuthMode('pin');
      return;
    }
    const cleanMobile = mobile.replace(/\D/g, '').slice(-10);
    if (cleanMobile.length < 10) {
      setError('Please enter a valid 10-digit mobile number.');
      return;
    }
    setError('');
    setIsSendingOtp(true);

    try {
      const res = await sendRealTimeOtp(cleanMobile, settings.smsGateway);
      setSmsNotification({
        message: res.message,
        isRealSms: res.isRealSms,
        otp: res.otp,
        provider: res.provider,
      });

      // Clear OTP boxes for real user entry
      setOtpDigits(['', '', '', '', '', '']);
      setOtpTimer(30);
      setCanResend(false);
      setStep('otp');

      // Trigger phone vibration and notification chime
      triggerPhoneVibration();
      playNotificationSound();

      // On mobile handsets, trigger native SMS intent to open phone's Messages app
      const isMobile = typeof navigator !== 'undefined' && /Android|iPhone|iPad|iPod/i.test(navigator.userAgent);
      if (isMobile) {
        window.location.href = getNativeSmsUrl(cleanMobile, res.otp);
      }
    } catch (err: any) {
      setError('Failed to dispatch SMS OTP. Please try again.');
    } finally {
      setIsSendingOtp(false);
    }
  };

  const handleSendWhatsAppOtp = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const cleanMobile = mobile.replace(/\D/g, '').slice(-10);
    if (cleanMobile.length < 10) {
      setError('Please enter a valid 10-digit mobile number.');
      return;
    }
    setError('');
    setIsSendingOtp(true);

    try {
      const res = await sendRealTimeOtp(cleanMobile, settings.smsGateway);
      const waUrl = getWhatsAppOtpUrl(cleanMobile, res.otp);

      setSmsNotification({
        message: `WhatsApp OTP generated for +91 ${cleanMobile}. Click "Open WhatsApp" below to deliver the message.`,
        isRealSms: true,
        otp: res.otp,
        provider: 'WhatsApp OTP',
      });

      setOtpDigits(['', '', '', '', '', '']);
      setOtpTimer(30);
      setCanResend(false);
      setStep('otp');
      setWhatsappSent(true);

      // Trigger sensory cues
      triggerPhoneVibration();
      playNotificationSound();

      // Open WhatsApp chat directly (Native mobile app intent on phones, web on desktop)
      const isMobile = typeof navigator !== 'undefined' && /Android|iPhone|iPad|iPod/i.test(navigator.userAgent);
      const nativeLink = getNativeWhatsAppDeepLink(cleanMobile, res.otp);
      const webLink = getWhatsAppOtpUrl(cleanMobile, res.otp);

      if (isMobile) {
        window.location.href = nativeLink;
      } else {
        try {
          window.open(webLink, '_blank');
        } catch {
          // browser popup blocker fallback
        }
      }
    } catch {
      setError('Failed to dispatch WhatsApp OTP. Please try again.');
    } finally {
      setIsSendingOtp(false);
    }
  };

  const handleVerifyOtp = () => {
    const fullOtp = otpDigits.join('');
    if (fullOtp.length < 4) {
      setError('Please enter the 6-digit OTP code.');
      return;
    }

    // Verify session OTP
    const isCodeValid = verifySessionOtp(mobile, fullOtp);
    if (!isCodeValid) {
      setError('Invalid or expired OTP code. Please check your SMS and try again.');
      return;
    }

    const res = verifyOtp(mobile, fullOtp);
    if (res.success) {
      if (res.isNew) {
        // Unregistered phone number -> route to quick registration
        setStep('register');
      } else {
        const cust = res.customer;
        setVerifiedCustomer(cust);
        // Prompt for PIN creation if they don't have one
        if (!cust?.hasPin) {
          setStep('prompt_pin');
        } else {
          setStep('success');
        }
      }
    } else {
      setError(res.message || 'Invalid or expired OTP. Please try again.');
    }
  };

  const handlePinLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (mobile.length !== 10) {
      setError('Please enter your 10-digit mobile number.');
      return;
    }
    if (!pin.trim()) {
      setError('Please enter your 4-digit PIN (Default demo PIN is 1234).');
      return;
    }
    setError('');
    const res = loginWithPin(mobile, pin);
    if (res.success) {
      setVerifiedCustomer(res.customer);
      setStep('success');
    } else {
      setError(res.message || 'Incorrect PIN. Try 1234 or use 1-Click Safe Login.');
    }
  };

  const handleDirectSafeLogin = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (mobile.length !== 10) {
      setError('Please enter your 10-digit mobile number.');
      return;
    }
    setError('');
    const res = directSafeLogin(mobile);
    if (res.success) {
      if (res.isNew) {
        setStep('register');
      } else {
        setVerifiedCustomer(res.customer);
        setStep('success');
      }
    } else {
      setError(res.message || 'Instant login failed. Please try again.');
    }
  };

  const handleSavePin = (e: React.FormEvent) => {
    e.preventDefault();
    if (newPin.length < 4) {
      setError('PIN must be at least 4 digits.');
      return;
    }
    if (newPin !== confirmPin) {
      setError('PINs do not match. Please verify.');
      return;
    }

    if (verifiedCustomer) {
      setCustomerPin(verifiedCustomer.id, newPin);
    }
    setStep('success');
  };

  const handleRegisterSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!regName.trim()) {
      setError('Please enter your full name.');
      return;
    }

    const newCust = registerNewCustomer({
      name: regName.trim(),
      mobile,
      email: regEmail.trim(),
      city: regCity.trim(),
      address: regAddress.trim(),
      interestedPlot: regPlotType,
      budget: regBudget,
    });

    setVerifiedCustomer(newCust);
    setStep('success');
  };

  const handleOtpBoxChange = (idx: number, val: string) => {
    const char = val.slice(-1);
    const updated = [...otpDigits];
    updated[idx] = char;
    setOtpDigits(updated);
    if (char && idx < 5) {
      otpRefs.current[idx + 1]?.focus();
    }
  };

  const handleOtpKeyDown = (idx: number, e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Backspace' && !otpDigits[idx] && idx > 0) {
      otpRefs.current[idx - 1]?.focus();
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col justify-center items-center p-4 sm:p-6">
      {/* Container matching mobile wireframe proportions */}
      <div className="w-full max-w-md bg-white rounded-3xl shadow-xl border border-slate-200 overflow-hidden transition-all duration-300">
        {/* Navigation Bar */}
        <div className="px-6 pt-6 pb-2 flex items-center justify-between">
          {step !== 'login' && step !== 'success' ? (
            <button
              onClick={() => {
                setError('');
                if (step === 'otp') setStep('login');
                else if (step === 'pin') setStep('login');
                else if (step === 'create_pin') setStep('prompt_pin');
                else if (step === 'prompt_pin') setStep('success');
                else if (step === 'register') setStep('login');
              }}
              className="p-2 -ml-2 rounded-xl text-slate-500 hover:text-slate-900 hover:bg-slate-100 transition-colors cursor-pointer"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
          ) : onBackToSplash ? (
            <button
              onClick={onBackToSplash}
              className="p-2 -ml-2 rounded-xl text-slate-500 hover:text-slate-900 hover:bg-slate-100 transition-colors cursor-pointer text-xs font-semibold flex items-center gap-1"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>Back</span>
            </button>
          ) : (
            <div className="w-6"></div>
          )}

          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-orange-600"></span>
            <span className="text-[11px] font-bold text-orange-600 uppercase tracking-wider">
              Customer Portal
            </span>
            <button
              type="button"
              onClick={() => setShowAdminModal(true)}
              className="p-1.5 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-xl transition-colors cursor-pointer ml-1"
              aria-label="Portal Entry"
            >
              <Home className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* ================= STEP 1: LOGIN SCREEN (Wireframe 2) ================= */}
        {step === 'login' && (
          <div className="p-6 pt-2">
            <div className="text-center mb-6">
              <div className="flex justify-center mb-3">
                <BalajiLogo size="lg" showTagline />
              </div>
              <h2 className="text-2xl font-bold text-slate-900">{t('welcomeBack')}</h2>
              <p className="text-xs text-slate-500 mt-1">{t('loginToAccount')}</p>
            </div>

            {error && (
              <div className="mb-4 p-3 bg-rose-50 border border-rose-200 rounded-xl flex items-center gap-2 text-xs text-rose-700">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{error}</span>
              </div>
            )}

            {/* 100% Privacy & Safety Guarantee Banner */}
            <div className="mb-5 p-3 rounded-2xl bg-gradient-to-r from-emerald-50 to-teal-50 border border-emerald-200/80 text-emerald-900 shadow-2xs">
              <div className="flex items-start gap-2.5">
                <div className="w-6 h-6 rounded-lg bg-emerald-600 text-white flex items-center justify-center shrink-0 mt-0.5 shadow-xs">
                  <ShieldCheck className="w-4 h-4" />
                </div>
                <div>
                  <div className="text-xs font-bold text-emerald-950 flex items-center gap-1.5">
                    <span>100% Private & Safe Login</span>
                    <span className="text-[10px] font-semibold px-1.5 py-0.2 bg-emerald-200/70 text-emerald-800 rounded-md">No 3rd Party Sites</span>
                  </div>
                  <p className="text-[11px] text-emerald-700/90 mt-0.5 leading-relaxed">
                    You <strong>never</strong> need to visit or register on external SMS websites. Choose from 3 safe login methods below.
                  </p>
                </div>
              </div>
            </div>

            {/* Login Mode Tabs */}
            <div className="grid grid-cols-4 gap-1 p-1 bg-slate-100 rounded-2xl mb-5 text-xs font-bold">
              <button
                type="button"
                onClick={() => {
                  setAuthMode('otp');
                  setError('');
                }}
                className={`py-2 px-1 rounded-xl transition-all cursor-pointer flex flex-col sm:flex-row items-center justify-center gap-1 text-[11px] ${
                  authMode === 'otp'
                    ? 'bg-blue-600 text-white shadow-xs'
                    : 'text-slate-600 hover:text-blue-700'
                }`}
              >
                <Smartphone className="w-3.5 h-3.5" />
                <span>Phone SMS</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  setAuthMode('whatsapp');
                  setError('');
                }}
                className={`py-2 px-1 rounded-xl transition-all cursor-pointer flex flex-col sm:flex-row items-center justify-center gap-1 text-[11px] ${
                  authMode === 'whatsapp'
                    ? 'bg-emerald-600 text-white shadow-xs'
                    : 'text-slate-600 hover:text-emerald-700'
                }`}
              >
                <MessageCircle className="w-3.5 h-3.5" />
                <span>WhatsApp</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  setAuthMode('pin');
                  setError('');
                }}
                className={`py-2 px-1 rounded-xl transition-all cursor-pointer flex flex-col sm:flex-row items-center justify-center gap-1 text-[11px] ${
                  authMode === 'pin'
                    ? 'bg-white text-orange-600 shadow-xs'
                    : 'text-slate-500 hover:text-slate-800'
                }`}
              >
                <Lock className="w-3.5 h-3.5" />
                <span>4-Digit PIN</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  setAuthMode('direct');
                  setError('');
                }}
                className={`py-2 px-1 rounded-xl transition-all cursor-pointer flex flex-col sm:flex-row items-center justify-center gap-1 text-[11px] ${
                  authMode === 'direct'
                    ? 'bg-white text-emerald-600 shadow-xs'
                    : 'text-slate-500 hover:text-slate-800'
                }`}
              >
                <Zap className="w-3.5 h-3.5" />
                <span>1-Click</span>
              </button>
            </div>

            {/* MODE 0: WHATSAPP REAL OTP (100% Free & Unlimited) */}
            {authMode === 'whatsapp' && (
              <form onSubmit={handleSendWhatsAppOtp} className="space-y-4 animate-in fade-in">
                <div className="p-3 bg-emerald-50/90 border border-emerald-200 rounded-2xl">
                  <div className="flex items-center gap-2 mb-1">
                    <div className="w-6 h-6 rounded-lg bg-emerald-600 text-white flex items-center justify-center shadow-xs">
                      <MessageCircle className="w-3.5 h-3.5" />
                    </div>
                    <span className="text-xs font-bold text-emerald-950">Real WhatsApp OTP (100% Free & Unlimited)</span>
                  </div>
                  <p className="text-[11px] text-emerald-800 leading-relaxed">
                    A real 6-digit verification code will be sent directly to your phone's WhatsApp chat in 1 second. Zero telecom SMS costs, unlimited times per day!
                  </p>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                    Your WhatsApp Mobile Number
                  </label>
                  <div className="relative flex items-center">
                    <div className="absolute left-3.5 flex items-center gap-1.5 text-slate-400">
                      <Phone className="w-4 h-4 text-emerald-600" />
                      <span className="text-xs font-semibold text-slate-700 border-r border-slate-300 pr-2">
                        +91
                      </span>
                    </div>
                    <input
                      type="tel"
                      maxLength={10}
                      value={mobile}
                      onChange={(e) => setMobile(e.target.value.replace(/\D/g, ''))}
                      placeholder={t('enterMobile')}
                      required
                      className="w-full pl-22 pr-4 py-3 bg-slate-50 border border-emerald-300/80 rounded-xl text-sm font-medium text-slate-900 focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-emerald-500 transition-all"
                    />
                  </div>
                  <p className="text-[10px] text-slate-400 mt-1">
                    Enter the 10-digit number active on your WhatsApp app.
                  </p>
                </div>

                <button
                  type="submit"
                  disabled={isSendingOtp}
                  className="w-full py-3.5 bg-emerald-600 hover:bg-emerald-700 active:scale-[0.98] text-white font-bold rounded-xl text-sm shadow-md shadow-emerald-600/25 flex items-center justify-center gap-2 cursor-pointer transition-all disabled:opacity-50"
                >
                  <MessageCircle className="w-4 h-4" />
                  <span>{isSendingOtp ? 'Opening WhatsApp...' : 'Send OTP to WhatsApp'}</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </form>
            )}

            {/* MODE 1: 4-DIGIT PIN LOGIN (100% Safe, No external websites) */}
            {authMode === 'pin' && (
              <form onSubmit={handlePinLogin} className="space-y-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                    {t('mobileNumber')}
                  </label>
                  <div className="relative flex items-center">
                    <div className="absolute left-3.5 flex items-center gap-1.5 text-slate-400">
                      <Phone className="w-4 h-4" />
                      <span className="text-xs font-semibold text-slate-700 border-r border-slate-300 pr-2">
                        +91
                      </span>
                    </div>
                    <input
                      type="tel"
                      maxLength={10}
                      value={mobile}
                      onChange={(e) => setMobile(e.target.value.replace(/\D/g, ''))}
                      placeholder={t('enterMobile')}
                      required
                      className="w-full pl-22 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-sm font-medium text-slate-900 focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-orange-500"
                    />
                  </div>
                </div>

                <div>
                  <div className="flex items-center justify-between mb-1.5">
                    <label className="text-xs font-semibold text-slate-700">
                      Secret 4-Digit Security PIN
                    </label>
                    <span className="text-[10px] text-slate-400 font-mono">
                      Demo PIN: <strong>1234</strong>
                    </span>
                  </div>
                  <div className="relative flex items-center">
                    <Lock className="w-4 h-4 text-slate-400 absolute left-3.5" />
                    <input
                      type={showPin ? 'text' : 'password'}
                      maxLength={8}
                      value={pin}
                      onChange={(e) => setPin(e.target.value)}
                      placeholder="Enter 4-digit PIN (e.g. 1234)"
                      required
                      className="w-full pl-10 pr-10 py-3 bg-slate-50 border border-slate-200 rounded-xl text-sm font-mono text-slate-900 focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-orange-500"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPin(!showPin)}
                      className="absolute right-3.5 text-slate-400 hover:text-slate-600 cursor-pointer"
                    >
                      {showPin ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                <button
                  type="submit"
                  className="w-full py-3.5 bg-orange-600 hover:bg-orange-700 text-white font-bold rounded-xl text-sm shadow-md shadow-orange-600/20 transition-all active:scale-[0.98] cursor-pointer flex items-center justify-center gap-2"
                >
                  <Lock className="w-4 h-4" />
                  <span>Login Securely with PIN</span>
                </button>
              </form>
            )}

            {/* MODE 2: 1-CLICK INSTANT SAFE LOGIN (Zero SMS, Zero Third-Party) */}
            {authMode === 'direct' && (
              <form onSubmit={handleDirectSafeLogin} className="space-y-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                    {t('mobileNumber')}
                  </label>
                  <div className="relative flex items-center">
                    <div className="absolute left-3.5 flex items-center gap-1.5 text-slate-400">
                      <Phone className="w-4 h-4" />
                      <span className="text-xs font-semibold text-slate-700 border-r border-slate-300 pr-2">
                        +91
                      </span>
                    </div>
                    <input
                      type="tel"
                      maxLength={10}
                      value={mobile}
                      onChange={(e) => setMobile(e.target.value.replace(/\D/g, ''))}
                      placeholder={t('enterMobile')}
                      required
                      className="w-full pl-22 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-sm font-medium text-slate-900 focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-emerald-500"
                    />
                  </div>
                </div>

                <div className="p-3 bg-slate-50 border border-slate-200/80 rounded-xl text-[11px] text-slate-600 space-y-1">
                  <div className="flex items-center gap-1.5 text-emerald-700 font-bold">
                    <Check className="w-3.5 h-3.5" />
                    <span>Instant Direct Authentication</span>
                  </div>
                  <p className="leading-relaxed">
                    Directly authenticates registered customers without relying on telecom carrier gateways or any 3rd party websites.
                  </p>
                </div>

                <button
                  type="submit"
                  className="w-full py-3.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl text-sm shadow-md shadow-emerald-600/20 transition-all active:scale-[0.98] cursor-pointer flex items-center justify-center gap-2"
                >
                  <Zap className="w-4 h-4" />
                  <span>Instant Safe Login (No External Sites)</span>
                </button>
              </form>
            )}

            {/* MODE 3: CELLULAR PHONE SMS OTP */}
            {authMode === 'otp' && (
              <form onSubmit={handleSendOtp} className="space-y-4 animate-in fade-in">
                <div className="p-3 bg-blue-50/90 border border-blue-200 rounded-2xl">
                  <div className="flex items-center gap-2 mb-1">
                    <div className="w-6 h-6 rounded-lg bg-blue-600 text-white flex items-center justify-center shadow-xs">
                      <Smartphone className="w-3.5 h-3.5" />
                    </div>
                    <span className="text-xs font-bold text-blue-950">Real Phone SMS Verification</span>
                  </div>
                  <p className="text-[11px] text-blue-800 leading-relaxed">
                    A 6-digit verification code will be sent to your mobile phone number. On phones, your Messages app will launch with the code ready.
                  </p>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                    {t('mobileNumber')}
                  </label>
                  <div className="relative flex items-center">
                    <div className="absolute left-3.5 flex items-center gap-1.5 text-slate-400">
                      <Phone className="w-4 h-4 text-blue-600" />
                      <span className="text-xs font-semibold text-slate-700 border-r border-slate-300 pr-2">
                        +91
                      </span>
                    </div>
                    <input
                      type="tel"
                      maxLength={10}
                      value={mobile}
                      onChange={(e) => setMobile(e.target.value.replace(/\D/g, ''))}
                      placeholder={t('enterMobile')}
                      required
                      className="w-full pl-22 pr-4 py-3 bg-slate-50 border border-blue-200 rounded-xl text-sm font-medium text-slate-900 focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all"
                    />
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={isSendingOtp}
                  className="w-full py-3.5 bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white font-bold rounded-xl text-sm shadow-md shadow-blue-600/25 transition-all active:scale-[0.98] flex items-center justify-center gap-2 cursor-pointer"
                >
                  <Smartphone className="w-4 h-4" />
                  <span>{isSendingOtp ? 'Dispatching SMS...' : 'Send OTP in SMS to Phone'}</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </form>
            )}

            {/* Demo Customer Quick Select */}
            <div className="mt-4 pt-3 border-t border-slate-100">
              <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block mb-1.5">
                Quick 1-Tap Customer Accounts (Pre-loaded):
              </span>
              <div className="grid grid-cols-2 gap-1.5">
                <button
                  type="button"
                  onClick={() => {
                    setMobile('9876543210');
                    setPin('1234');
                    setError('');
                  }}
                  className="p-2 rounded-xl bg-slate-50 hover:bg-orange-50 hover:border-orange-200 border border-slate-200 text-left cursor-pointer transition-all"
                >
                  <div className="text-[11px] font-bold text-slate-800">Rahul Sharma</div>
                  <div className="text-[9px] text-slate-500 font-mono">9876543210 · PIN 1234</div>
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setMobile('8765432109');
                    setPin('1234');
                    setError('');
                  }}
                  className="p-2 rounded-xl bg-slate-50 hover:bg-orange-50 hover:border-orange-200 border border-slate-200 text-left cursor-pointer transition-all"
                >
                  <div className="text-[11px] font-bold text-slate-800">Priya Singh</div>
                  <div className="text-[9px] text-slate-500 font-mono">8765432109 · PIN 1234</div>
                </button>
              </div>
            </div>

            {/* New Customer Registration Link */}
            <div className="mt-5 text-center text-xs text-slate-600">
              <span>{t('newCustomerQuestion')} </span>
              <button
                type="button"
                onClick={() => {
                  setError('');
                  setStep('register');
                }}
                className="font-bold text-orange-600 hover:underline cursor-pointer"
              >
                {t('registerHere')}
              </button>
            </div>

            {/* Security Assurance Badge */}
            <div className="mt-6 pt-4 border-t border-slate-100 flex items-center justify-center gap-1.5 text-[11px] text-slate-400">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
              <span>Official Balaji Group Portal · Secure Encrypted Access</span>
            </div>
          </div>
        )}

        {/* ================= STEP 2: OTP VERIFICATION (Wireframe 3) ================= */}
        {step === 'otp' && (
          <div className="p-6 pt-2">
            <div className="text-center mb-6">
              <h2 className="text-2xl font-bold text-slate-900">{t('otpVerification')}</h2>
              <p className="text-xs text-slate-500 mt-1 max-w-xs mx-auto">
                {t('enterOtpCode')} <strong className="text-slate-800">+91 {mobile}</strong>
              </p>
            </div>

            {error && (
              <div className="mb-4 p-3 bg-rose-50 border border-rose-200 rounded-xl flex items-center gap-2 text-xs text-rose-700">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{error}</span>
              </div>
            )}

            {/* ================= AUTHENTIC PHONE VERIFICATION STATUS (NO ON-SCREEN SPOILER) ================= */}
            {authMode === 'whatsapp' || smsNotification?.provider === 'WhatsApp OTP' ? (
              <div className="mb-5 p-4 rounded-2xl bg-gradient-to-br from-emerald-50 via-teal-50 to-white border border-emerald-200 text-slate-800 shadow-2xs text-center space-y-3 animate-in fade-in">
                <div className="w-12 h-12 rounded-2xl bg-emerald-600 text-white flex items-center justify-center mx-auto shadow-md shadow-emerald-600/20">
                  <MessageCircle className="w-6 h-6 fill-white" />
                </div>

                <div>
                  <h3 className="font-extrabold text-slate-900 text-base">
                    Verification Code Sent to WhatsApp
                  </h3>
                  <p className="text-xs text-emerald-800 font-mono font-semibold mt-0.5">
                    +91 {mobile}
                  </p>
                </div>

                <p className="text-xs text-slate-600 leading-relaxed max-w-xs mx-auto">
                  A real 6-digit OTP has been dispatched to your phone's WhatsApp. Tap below to read the message, then enter your code:
                </p>

                <div className="pt-1 space-y-2">
                  <a
                    href={getNativeWhatsAppDeepLink(mobile, smsNotification?.otp || '')}
                    onClick={() => setWhatsappSent(true)}
                    className="w-full py-3.5 px-4 bg-emerald-600 hover:bg-emerald-700 active:scale-95 text-white font-extrabold rounded-xl text-xs flex items-center justify-center gap-2 shadow-md shadow-emerald-600/25 transition-all cursor-pointer"
                  >
                    <MessageCircle className="w-4 h-4 fill-white" />
                    <span>Open WhatsApp on Phone to View Code</span>
                  </a>

                  <a
                    href={getWhatsAppOtpUrl(mobile, smsNotification?.otp || '')}
                    target="_blank"
                    rel="noopener noreferrer"
                    onClick={() => setWhatsappSent(true)}
                    className="block text-center text-[11px] text-emerald-700 hover:underline cursor-pointer"
                  >
                    Open via WhatsApp Web / Browser link
                  </a>
                </div>
              </div>
            ) : (
              <div className="mb-5 p-4 rounded-2xl bg-gradient-to-br from-blue-50 via-indigo-50 to-white border border-blue-200 text-slate-800 shadow-2xs text-center space-y-3 animate-in fade-in">
                <div className="w-12 h-12 rounded-2xl bg-blue-600 text-white flex items-center justify-center mx-auto shadow-md shadow-blue-600/20">
                  <Smartphone className="w-6 h-6" />
                </div>

                <div>
                  <h3 className="font-extrabold text-slate-900 text-base">
                    SMS Sent to Your Phone
                  </h3>
                  <p className="text-xs text-blue-800 font-mono font-semibold mt-0.5">
                    +91 {mobile}
                  </p>
                </div>

                <p className="text-xs text-slate-600 leading-relaxed max-w-xs mx-auto">
                  We dispatched a 6-digit verification code to your physical phone. Open your phone's Messages app to see the code, then enter it below:
                </p>

                <div className="pt-1 flex flex-col sm:flex-row items-center justify-center gap-2">
                  <a
                    href={getNativeSmsUrl(mobile, smsNotification?.otp || '')}
                    onClick={() => setNativeSmsOpened(true)}
                    className="w-full sm:w-auto px-4 py-3 bg-blue-600 hover:bg-blue-700 active:scale-95 text-white font-extrabold rounded-xl text-xs flex items-center justify-center gap-2 shadow-md shadow-blue-600/25 transition-all cursor-pointer"
                  >
                    <Smartphone className="w-4 h-4" />
                    <span>Open Phone Messages App (SMS)</span>
                  </a>

                  <a
                    href={getWhatsAppOtpUrl(mobile, smsNotification?.otp || '')}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-full sm:w-auto px-4 py-3 bg-emerald-600 hover:bg-emerald-700 active:scale-95 text-white font-extrabold rounded-xl text-xs flex items-center justify-center gap-2 shadow-md shadow-emerald-600/25 transition-all cursor-pointer"
                  >
                    <MessageCircle className="w-4 h-4 fill-white" />
                    <span>Receive on WhatsApp Instead</span>
                  </a>
                </div>
              </div>
            )}

                {/* Cellular Carrier SMS Status & Quick Setup Drawer (Optional) */}
                <div className="mt-3 p-2.5 bg-white/90 rounded-xl border border-orange-200/80 text-xs shadow-2xs">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-1.5 font-bold text-slate-800 text-[11px]">
                      <Radio className={`w-3.5 h-3.5 ${smsNotification?.isRealSms ? 'text-emerald-600' : 'text-slate-400'}`} />
                      <span>
                        {smsNotification?.isRealSms
                          ? `Telecom Carrier SMS Active (${smsNotification?.provider || 'Gateway'})`
                          : 'Telecom Gateway (Optional)'}
                      </span>
                    </div>
                    <button
                      type="button"
                      onClick={() => setShowSmsKeyDrawer(!showSmsKeyDrawer)}
                      className="text-orange-600 font-bold hover:underline flex items-center gap-1 cursor-pointer text-[10px]"
                    >
                      <Settings className="w-3 h-3" />
                      <span>{showSmsKeyDrawer ? 'Close' : 'Enterprise Gateway'}</span>
                      {showSmsKeyDrawer ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
                    </button>
                  </div>

                  {showSmsKeyDrawer && (
                    <div className="mt-2.5 pt-2.5 border-t border-slate-200 space-y-2">
                      <p className="text-[10px] text-slate-600 leading-relaxed">
                        Optional for telecom administrators: Route via cellular towers. <em>You do not need this; you can use the 100% safe direct login or PIN without visiting any external websites.</em>
                      </p>
                      <div className="flex gap-1.5">
                        <input
                          type="text"
                          value={quickApiKey}
                          onChange={(e) => setQuickApiKey(e.target.value)}
                          placeholder="Telecom Gateway Key (Optional)"
                          className="flex-1 px-2.5 py-1.5 bg-slate-50 border border-slate-300 rounded-lg text-xs font-mono text-slate-800"
                        />
                        <button
                          type="button"
                          disabled={!quickApiKey.trim() || isSendingOtp}
                          onClick={handleSaveQuickApiKeyAndResend}
                          className="px-3 py-1.5 bg-orange-600 hover:bg-orange-700 disabled:opacity-50 text-white font-bold rounded-lg text-xs flex items-center gap-1 cursor-pointer shrink-0 shadow-xs active:scale-95 transition-all"
                        >
                          {quickKeySaved ? <Check className="w-3 h-3" /> : <Send className="w-3 h-3" />}
                          <span>{quickKeySaved ? 'Saved!' : 'Save & Send SMS'}</span>
                        </button>
                      </div>
                    </div>
                  )}
                </div>

            {/* 6 Digit Input Boxes */}
            <div className="flex justify-between gap-2 mb-6">
              {otpDigits.map((digit, idx) => (
                <input
                  key={idx}
                  ref={(el) => {
                    otpRefs.current[idx] = el;
                  }}
                  type="text"
                  maxLength={1}
                  value={digit}
                  onChange={(e) => handleOtpBoxChange(idx, e.target.value)}
                  onKeyDown={(e) => handleOtpKeyDown(idx, e)}
                  className="w-12 h-14 text-center text-xl font-bold text-slate-900 bg-slate-50 border border-slate-300 rounded-xl focus:bg-white focus:border-orange-500 focus:ring-2 focus:ring-orange-500 focus:outline-hidden transition-all shadow-2xs font-mono"
                />
              ))}
            </div>

            {/* Resend OTP Timer & WhatsApp Resend */}
            <div className="text-center mb-6 text-xs text-slate-500">
              {canResend ? (
                <div className="flex items-center justify-center gap-3">
                  <button
                    type="button"
                    onClick={() => handleSendWhatsAppOtp()}
                    className="font-bold text-emerald-600 hover:text-emerald-700 hover:underline flex items-center gap-1 cursor-pointer"
                  >
                    <MessageCircle className="w-3.5 h-3.5" />
                    <span>Resend via WhatsApp</span>
                  </button>
                  <span className="text-slate-300">|</span>
                  <button
                    type="button"
                    onClick={() => handleSendOtp()}
                    className="font-bold text-orange-600 hover:text-orange-700 hover:underline cursor-pointer"
                  >
                    <span>Resend via SMS</span>
                  </button>
                </div>
              ) : (
                <span>
                  {t('resendOtp')} (00:{otpTimer < 10 ? `0${otpTimer}` : otpTimer})
                </span>
              )}
            </div>

            <button
              type="button"
              onClick={handleVerifyOtp}
              className={`w-full py-3.5 text-white font-bold rounded-xl text-sm shadow-md transition-all active:scale-[0.98] cursor-pointer flex items-center justify-center gap-2 ${
                authMode === 'whatsapp' || smsNotification?.provider === 'WhatsApp OTP'
                  ? 'bg-emerald-600 hover:bg-emerald-700 shadow-emerald-600/25'
                  : 'bg-orange-600 hover:bg-orange-700 shadow-orange-600/20'
              }`}
            >
              <CheckCircle2 className="w-4 h-4" />
              <span>{t('verify')}</span>
            </button>

            {/* Safe Direct Login Without External SMS */}
            <div className="mt-4 p-3 bg-emerald-50/80 rounded-2xl border border-emerald-200/80 text-center">
              <p className="text-[11px] font-bold text-emerald-900 mb-2 flex items-center justify-center gap-1.5">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                <span>Prefer not to use SMS? 100% Safe Alternative:</span>
              </p>
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => {
                    const res = directSafeLogin(mobile);
                    if (res.success) {
                      if (res.isNew) {
                        setStep('register');
                      } else {
                        setVerifiedCustomer(res.customer);
                        setStep('success');
                      }
                    }
                  }}
                  className="py-2.5 px-2 bg-emerald-600 hover:bg-emerald-700 active:scale-95 text-white font-bold rounded-xl text-xs shadow-xs transition-all flex items-center justify-center gap-1 cursor-pointer"
                >
                  <Zap className="w-3.5 h-3.5" />
                  <span>Instant Safe Login</span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    setAuthMode('pin');
                    setStep('login');
                  }}
                  className="py-2.5 px-2 bg-white hover:bg-slate-50 border border-slate-300 active:scale-95 text-slate-800 font-bold rounded-xl text-xs shadow-xs transition-all flex items-center justify-center gap-1 cursor-pointer"
                >
                  <Lock className="w-3.5 h-3.5 text-orange-600" />
                  <span>Use 4-Digit PIN</span>
                </button>
              </div>
            </div>
          </div>
        )}

        {/* ================= STEP 3: PROMPT PIN CREATION ================= */}
        {step === 'prompt_pin' && (
          <div className="p-6 pt-2 text-center">
            <div className="w-14 h-14 bg-orange-100 text-orange-600 rounded-2xl flex items-center justify-center mx-auto mb-4">
              <ShieldCheck className="w-8 h-8" />
            </div>
            <h3 className="text-xl font-bold text-slate-900 mb-2">Faster Login Setup</h3>
            <p className="text-xs text-slate-600 mb-6 leading-relaxed">
              {t('fasterLoginPrompt')}
            </p>

            <div className="space-y-3">
              <button
                onClick={() => setStep('create_pin')}
                className="w-full py-3.5 bg-orange-600 hover:bg-orange-700 text-white font-bold rounded-xl text-sm shadow-md transition-all cursor-pointer"
              >
                Create PIN
              </button>
              <button
                onClick={() => setStep('success')}
                className="w-full py-3 bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold rounded-xl text-xs transition-colors cursor-pointer"
              >
                {t('skipForNow')}
              </button>
            </div>
          </div>
        )}

        {/* ================= STEP 4: CREATE PIN (Wireframe 4) ================= */}
        {step === 'create_pin' && (
          <div className="p-6 pt-2">
            <div className="text-center mb-6">
              <h2 className="text-2xl font-bold text-slate-900">{t('createPasswordTitle')}</h2>
              <p className="text-xs text-slate-500 mt-1">{t('setPasswordDesc')}</p>
            </div>

            {error && (
              <div className="mb-4 p-3 bg-rose-50 border border-rose-200 rounded-xl flex items-center gap-2 text-xs text-rose-700">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{error}</span>
              </div>
            )}

            <form onSubmit={handleSavePin} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  {t('newPassword')}
                </label>
                <div className="relative flex items-center">
                  <Lock className="w-4 h-4 text-slate-400 absolute left-3.5" />
                  <input
                    type={showNewPin ? 'text' : 'password'}
                    maxLength={8}
                    value={newPin}
                    onChange={(e) => setNewPin(e.target.value)}
                    placeholder="Enter 4-8 digit PIN"
                    required
                    className="w-full pl-10 pr-10 py-3 bg-slate-50 border border-slate-200 rounded-xl text-sm font-mono text-slate-900 focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-orange-500"
                  />
                  <button
                    type="button"
                    onClick={() => setShowNewPin(!showNewPin)}
                    className="absolute right-3.5 text-slate-400 hover:text-slate-600 cursor-pointer"
                  >
                    {showNewPin ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  {t('confirmPassword')}
                </label>
                <div className="relative flex items-center">
                  <Lock className="w-4 h-4 text-slate-400 absolute left-3.5" />
                  <input
                    type={showNewPin ? 'text' : 'password'}
                    maxLength={8}
                    value={confirmPin}
                    onChange={(e) => setConfirmPin(e.target.value)}
                    placeholder="Confirm PIN"
                    required
                    className="w-full pl-10 pr-10 py-3 bg-slate-50 border border-slate-200 rounded-xl text-sm font-mono text-slate-900 focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-orange-500"
                  />
                </div>
              </div>

              {/* Password criteria checklist */}
              <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 text-xs space-y-1.5 text-slate-600">
                <div className="flex items-center gap-1.5">
                  <CheckCircle2
                    className={`w-3.5 h-3.5 ${
                      newPin.length >= 4 ? 'text-emerald-600' : 'text-slate-300'
                    }`}
                  />
                  <span>{t('pwdReq1')}</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <CheckCircle2
                    className={`w-3.5 h-3.5 ${
                      newPin.length > 0 && newPin === confirmPin
                        ? 'text-emerald-600'
                        : 'text-slate-300'
                    }`}
                  />
                  <span>PIN matches confirmed value</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                  <span>{t('pwdReq2')}</span>
                </div>
              </div>

              <button
                type="submit"
                className="w-full py-3.5 bg-orange-600 hover:bg-orange-700 text-white font-bold rounded-xl text-sm shadow-md shadow-orange-600/20 transition-all cursor-pointer"
              >
                {t('savePassword')}
              </button>
            </form>
          </div>
        )}

        {/* ================= STEP 5: NEW CUSTOMER REGISTRATION ================= */}
        {step === 'register' && (
          <div className="p-6 pt-2">
            <div className="text-center mb-5">
              <h2 className="text-xl font-bold text-slate-900">{t('newRegistrationTitle')}</h2>
              <p className="text-xs text-slate-500 mt-1">{t('newRegSubtitle')}</p>
            </div>

            {error && (
              <div className="mb-4 p-3 bg-rose-50 border border-rose-200 rounded-xl flex items-center gap-2 text-xs text-rose-700">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{error}</span>
              </div>
            )}

            <form onSubmit={handleRegisterSubmit} className="space-y-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  {t('fullName')} <span className="text-red-500">*</span>
                </label>
                <div className="relative flex items-center">
                  <User className="w-4 h-4 text-slate-400 absolute left-3" />
                  <input
                    type="text"
                    placeholder="e.g. Ramesh Chandra"
                    value={regName}
                    onChange={(e) => setRegName(e.target.value)}
                    required
                    className="w-full pl-9 pr-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 focus:bg-white focus:ring-2 focus:ring-orange-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  {t('mobileNumber')}
                </label>
                <div className="relative flex items-center">
                  <Phone className="w-4 h-4 text-slate-400 absolute left-3" />
                  <input
                    type="tel"
                    value={mobile}
                    onChange={(e) => setMobile(e.target.value)}
                    required
                    className="w-full pl-9 pr-3 py-2.5 bg-slate-100 border border-slate-200 rounded-xl text-xs font-mono text-slate-900"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  {t('email')}
                </label>
                <div className="relative flex items-center">
                  <Mail className="w-4 h-4 text-slate-400 absolute left-3" />
                  <input
                    type="email"
                    placeholder="e.g. ramesh@example.com"
                    value={regEmail}
                    onChange={(e) => setRegEmail(e.target.value)}
                    className="w-full pl-9 pr-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 focus:bg-white focus:ring-2 focus:ring-orange-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    {t('city')}
                  </label>
                  <input
                    type="text"
                    value={regCity}
                    onChange={(e) => setRegCity(e.target.value)}
                    className="w-full px-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    {t('interestedPlot')}
                  </label>
                  <select
                    value={regPlotType}
                    onChange={(e) => setRegPlotType(e.target.value)}
                    className="w-full px-2 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900"
                  >
                    <option value="Residential Plot">Residential Plot</option>
                    <option value="Commercial Plot">Commercial Plot</option>
                    <option value="Villa Plot">Villa Plot</option>
                    <option value="Farmhouse">Farmhouse</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Address
                </label>
                <input
                  type="text"
                  placeholder="e.g. Sector 12, South Delhi"
                  value={regAddress}
                  onChange={(e) => setRegAddress(e.target.value)}
                  className="w-full px-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900"
                />
              </div>

              <button
                type="submit"
                className="w-full mt-3 py-3.5 bg-orange-600 hover:bg-orange-700 text-white font-bold rounded-xl text-sm shadow-md transition-all cursor-pointer"
              >
                {t('submitRequest')}
              </button>
            </form>
          </div>
        )}

        {/* ================= STEP 6: LOGIN SUCCESSFUL (Wireframe Screen) ================= */}
        {step === 'success' && (
          <div className="p-8 text-center animate-in zoom-in-95 duration-200">
            <div className="w-16 h-16 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto mb-4">
              <CheckCircle2 className="w-10 h-10" />
            </div>
            <h3 className="text-2xl font-bold text-slate-900 mb-1">{t('loginSuccess')}</h3>
            <p className="text-sm text-slate-600 mb-6">
              {t('welcomeBackUser')}, <strong className="text-slate-900">{verifiedCustomer?.name || 'Valued Customer'}</strong>!
            </p>

            <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 mb-6 text-left text-xs space-y-1.5">
              <div className="flex justify-between">
                <span className="text-slate-500">Customer ID:</span>
                <span className="font-mono font-bold text-slate-800">{verifiedCustomer?.id}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Mobile:</span>
                <span className="font-mono text-slate-800">+91 {verifiedCustomer?.mobile}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Account Status:</span>
                <span className="font-semibold text-emerald-600">{verifiedCustomer?.status || 'Active'}</span>
              </div>
            </div>

            <button
              onClick={onSuccess}
              className="w-full py-4 bg-orange-600 hover:bg-orange-700 text-white font-bold rounded-xl text-sm shadow-lg shadow-orange-600/25 transition-all active:scale-[0.98] cursor-pointer"
            >
              {t('continueBtn')}
            </button>
          </div>
        )}
      </div>

      <AdminAccessModal isOpen={showAdminModal} onClose={() => setShowAdminModal(false)} />
    </div>
  );
};
