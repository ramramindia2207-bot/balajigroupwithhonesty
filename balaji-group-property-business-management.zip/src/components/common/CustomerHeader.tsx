import React, { useState } from 'react';
import { BalajiLogo } from './BalajiLogo';
import { Bell, Globe, Shield, LogOut, ChevronDown, User, Home } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { NotificationDrawer } from './NotificationDrawer';
import { AdminAccessModal } from './AdminAccessModal';
import { PWAInstallButton } from './PWAInstallButton';

interface CustomerHeaderProps {
  onNavigateTab?: (tab: string) => void;
}

export const CustomerHeader: React.FC<CustomerHeaderProps> = ({ onNavigateTab }) => {
  const {
    currentCustomer,
    language,
    setLanguage,
    notifications,
    setAppMode,
    logoutCustomer,
    t,
  } = useApp();

  const [showNotifs, setShowNotifs] = useState(false);
  const [showProfileMenu, setShowProfileMenu] = useState(false);
  const [showAdminModal, setShowAdminModal] = useState(false);

  const unreadCount = notifications.filter(
    (n) => (!n.customerId || n.customerId === currentCustomer?.id) && !n.read
  ).length;

  return (
    <>
      <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200 px-4 py-3 shadow-2xs">
        <div className="max-w-5xl mx-auto flex items-center justify-between">
          {/* Brand Logo */}
          <div
            onClick={() => onNavigateTab && onNavigateTab('home')}
            className="cursor-pointer transition-transform active:scale-95"
          >
            <BalajiLogo size="sm" showTagline />
          </div>

          {/* Right Action Icons */}
          <div className="flex items-center gap-1.5 sm:gap-2.5">
            {/* APK / PWA Install Button */}
            <PWAInstallButton variant="header" />

            {/* Language Switcher */}
            <div className="flex items-center bg-slate-100 rounded-lg p-0.5 border border-slate-200">
              <button
                onClick={() => setLanguage('en')}
                className={`px-2 py-1 text-xs font-semibold rounded-md transition-all cursor-pointer ${
                  language === 'en'
                    ? 'bg-white text-orange-600 shadow-2xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                EN
              </button>
              <button
                onClick={() => setLanguage('hi')}
                className={`px-2 py-1 text-xs font-semibold rounded-md transition-all cursor-pointer ${
                  language === 'hi'
                    ? 'bg-white text-orange-600 shadow-2xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                हिन्दी
              </button>
            </div>

            {/* Notification Bell */}
            <button
              onClick={() => setShowNotifs(true)}
              className="relative p-2 rounded-xl text-slate-600 hover:text-orange-600 hover:bg-orange-50 transition-colors cursor-pointer"
              aria-label="Notifications"
            >
              <Bell className="w-5 h-5" />
              {unreadCount > 0 && (
                <span className="absolute top-1.5 right-1.5 w-4 h-4 bg-orange-600 text-white text-[10px] font-bold rounded-full flex items-center justify-center animate-pulse">
                  {unreadCount}
                </span>
              )}
            </button>

            {/* Small Home Icon in top right (No text, Password Protected with Akkudon@2207) */}
            <button
              onClick={() => setShowAdminModal(true)}
              className="p-2 text-slate-400 hover:text-slate-800 hover:bg-slate-100 rounded-xl transition-colors cursor-pointer"
              aria-label="Portal Entry"
            >
              <Home className="w-4 h-4" />
            </button>

            {/* Customer Profile Pill / Menu */}
            {currentCustomer ? (
              <div className="relative">
                <button
                  onClick={() => setShowProfileMenu(!showProfileMenu)}
                  className="flex items-center gap-2 p-1 pl-2 bg-slate-50 hover:bg-slate-100 rounded-xl border border-slate-200 transition-colors cursor-pointer"
                >
                  <span className="text-xs font-bold text-slate-800 hidden md:inline max-w-[120px] truncate">
                    {currentCustomer.name.split(' ')[0]}
                  </span>
                  <div className="w-7 h-7 rounded-lg bg-orange-600 text-white text-xs font-bold flex items-center justify-center shadow-xs">
                    {currentCustomer.name.charAt(0)}
                  </div>
                  <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
                </button>

                {showProfileMenu && (
                  <div className="absolute right-0 mt-2 w-56 bg-white rounded-2xl shadow-xl border border-slate-200 py-2 z-50 animate-in fade-in slide-in-from-top-2">
                    <div className="px-4 py-2 border-b border-slate-100">
                      <p className="text-xs font-bold text-slate-900">{currentCustomer.name}</p>
                      <p className="text-[11px] text-slate-500 font-mono">ID: {currentCustomer.id}</p>
                      <p className="text-[11px] text-slate-500">+91 {currentCustomer.mobile}</p>
                    </div>

                    <button
                      onClick={() => {
                        setShowProfileMenu(false);
                        onNavigateTab && onNavigateTab('settings');
                      }}
                      className="w-full text-left px-4 py-2 text-xs text-slate-700 hover:bg-slate-50 flex items-center gap-2 cursor-pointer"
                    >
                      <User className="w-3.5 h-3.5 text-slate-500" />
                      <span>{t('settings')} & Profile</span>
                    </button>

                    <div className="border-t border-slate-100 my-1"></div>

                    <button
                      onClick={() => {
                        setShowProfileMenu(false);
                        logoutCustomer();
                      }}
                      className="w-full text-left px-4 py-2 text-xs text-rose-600 hover:bg-rose-50 flex items-center gap-2 font-medium cursor-pointer"
                    >
                      <LogOut className="w-3.5 h-3.5" />
                      <span>{t('logout')}</span>
                    </button>
                  </div>
                )}
              </div>
            ) : null}
          </div>
        </div>
      </header>

      <NotificationDrawer isOpen={showNotifs} onClose={() => setShowNotifs(false)} />
      <AdminAccessModal isOpen={showAdminModal} onClose={() => setShowAdminModal(false)} />
    </>
  );
};
