import React, { useRef } from 'react';
import { PaymentRecord, Customer, Property } from '../../types';
import { BalajiLogo } from './BalajiLogo';
import { X, Printer, Download, CheckCircle2 } from 'lucide-react';
import { useApp } from '../../context/AppContext';

interface ReceiptModalProps {
  payment: PaymentRecord;
  customer?: Customer | null;
  property?: Property | null;
  onClose: () => void;
}

export const ReceiptModal: React.FC<ReceiptModalProps> = ({
  payment,
  customer,
  property,
  onClose,
}) => {
  const { settings } = useApp();
  const receiptRef = useRef<HTMLDivElement>(null);

  const handlePrint = () => {
    window.print();
  };

  // Convert amount to Indian currency words
  const numberToWords = (num: number): string => {
    const a = [
      '', 'One ', 'Two ', 'Three ', 'Four ', 'Five ', 'Six ', 'Seven ', 'Eight ', 'Nine ',
      'Ten ', 'Eleven ', 'Twelve ', 'Thirteen ', 'Fourteen ', 'Fifteen ', 'Sixteen ', 'Seventeen ', 'Eighteen ', 'Nineteen '
    ];
    const b = ['', '', 'Twenty', 'Thirty', 'Forty', 'Fifty', 'Sixty', 'Seventy', 'Eighty', 'Ninety'];

    const inWords = (n: number): string => {
      let str = '';
      if (n > 9999999) {
        str += inWords(Math.floor(n / 10000000)) + 'Crore ';
        n %= 10000000;
      }
      if (n > 99999) {
        str += inWords(Math.floor(n / 100000)) + 'Lakh ';
        n %= 100000;
      }
      if (n > 999) {
        str += inWords(Math.floor(n / 1000)) + 'Thousand ';
        n %= 1000;
      }
      if (n > 99) {
        str += inWords(Math.floor(n / 100)) + 'Hundred ';
        n %= 100;
      }
      if (n > 0) {
        if (str !== '') str += 'and ';
        if (n < 20) str += a[n];
        else str += b[Math.floor(n / 10)] + ' ' + a[n % 10];
      }
      return str;
    };

    return (inWords(num).trim() + ' Rupees Only');
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-white w-full max-w-2xl rounded-2xl shadow-2xl overflow-hidden border border-slate-200 animate-in fade-in duration-200 my-8">
        {/* Header Action Bar */}
        <div className="bg-slate-900 px-6 py-4 flex items-center justify-between text-white">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-5 h-5 text-emerald-400" />
            <span className="font-semibold text-sm">Official Payment Receipt</span>
          </div>
          <div className="flex items-center gap-3">
            <button
              onClick={handlePrint}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg text-xs font-medium transition-colors cursor-pointer"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Print / PDF</span>
            </button>
            <button
              onClick={onClose}
              className="p-1 hover:bg-slate-800 rounded-lg text-slate-400 hover:text-white transition-colors cursor-pointer"
              aria-label="Close"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Printable Receipt Paper */}
        <div ref={receiptRef} className="p-8 bg-white text-slate-800 print:p-0">
          {/* Company Letterhead */}
          <div className="flex items-start justify-between border-b-2 border-orange-500 pb-5">
            <div>
              <BalajiLogo size="lg" showTagline />
              <p className="text-xs text-slate-500 mt-2 max-w-sm leading-relaxed">
                {settings.address}
                <br />
                Phone: {settings.phone} · Email: {settings.email}
              </p>
            </div>
            <div className="text-right">
              <span className="inline-block px-3 py-1 bg-orange-100 text-orange-800 text-xs font-bold rounded-md uppercase tracking-wider mb-2">
                Acknowledgment Receipt
              </span>
              <p className="text-xs text-slate-500 font-mono">
                Receipt No: <strong className="text-slate-900">{payment.receiptNumber}</strong>
              </p>
              <p className="text-xs text-slate-500 font-mono mt-0.5">
                Date: <strong className="text-slate-900">{payment.paymentDate}</strong>
              </p>
            </div>
          </div>

          {/* Customer & Property Grid */}
          <div className="grid grid-cols-2 gap-6 my-6 p-4 bg-slate-50 rounded-xl border border-slate-200/80">
            <div>
              <h4 className="text-xs font-semibold uppercase tracking-wider text-slate-400 mb-2">
                Received From
              </h4>
              <p className="text-sm font-bold text-slate-900">{payment.customerName}</p>
              <p className="text-xs text-slate-600 mt-0.5">Customer ID: {payment.customerId}</p>
              {customer?.mobile && (
                <p className="text-xs text-slate-600">Mobile: +91 {customer.mobile}</p>
              )}
              {customer?.address && (
                <p className="text-xs text-slate-500 mt-1 line-clamp-1">{customer.address}</p>
              )}
            </div>

            <div>
              <h4 className="text-xs font-semibold uppercase tracking-wider text-slate-400 mb-2">
                Property Details
              </h4>
              <p className="text-sm font-bold text-slate-900">Plot No. {payment.plotNumber}</p>
              <p className="text-xs text-slate-600 mt-0.5">
                {property?.location || 'Green Valley Enclave, Chhatarpur'}
              </p>
              <p className="text-xs text-slate-600">
                Type: {property?.propertyType || 'Residential Plot'} · Size: {property?.propertySize || '1000 Sq. Ft.'}
              </p>
              {property?.registryNumber && (
                <p className="text-xs text-slate-500 mt-0.5">Reg. File: {property.registryNumber}</p>
              )}
            </div>
          </div>

          {/* Payment Particulars Table */}
          <div className="border border-slate-200 rounded-xl overflow-hidden mb-6">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-100 text-slate-700 font-semibold border-b border-slate-200">
                <tr>
                  <th className="py-2.5 px-4">Description</th>
                  <th className="py-2.5 px-4">Payment Method</th>
                  <th className="py-2.5 px-4">Transaction / UTR</th>
                  <th className="py-2.5 px-4 text-right">Amount (INR)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                <tr>
                  <td className="py-3 px-4 font-medium text-slate-900">
                    {payment.kistNumber === 0 ? 'Plot Booking Advance' : `Monthly Installment (Kist #${payment.kistNumber})`}
                    {payment.notes && <span className="block text-[11px] text-slate-500 font-normal">{payment.notes}</span>}
                  </td>
                  <td className="py-3 px-4 text-slate-600">{payment.paymentMethod}</td>
                  <td className="py-3 px-4 font-mono text-slate-600">{payment.transactionId}</td>
                  <td className="py-3 px-4 text-right font-mono font-bold text-slate-900 text-sm">
                    ₹{payment.amount.toLocaleString('en-IN')}
                  </td>
                </tr>
              </tbody>
              <tfoot className="bg-orange-50/60 font-semibold border-t border-slate-200">
                <tr>
                  <td colSpan={3} className="py-3 px-4 text-slate-700">
                    Total Amount Received
                  </td>
                  <td className="py-3 px-4 text-right font-mono font-extrabold text-orange-600 text-base">
                    ₹{payment.amount.toLocaleString('en-IN')}
                  </td>
                </tr>
              </tfoot>
            </table>
          </div>

          {/* Amount In Words */}
          <div className="mb-6 p-3 bg-slate-50 rounded-lg text-xs text-slate-700 border border-slate-200/60">
            <span className="font-semibold text-slate-900">Amount in Words: </span>
            <span className="italic">{numberToWords(payment.amount)}</span>
          </div>

          {/* Verification Stamp & Signatory */}
          <div className="flex items-end justify-between pt-4 border-t border-slate-200">
            <div className="flex items-center gap-3">
              <div className="w-16 h-16 rounded-full border-2 border-dashed border-emerald-600/50 flex flex-col items-center justify-center p-1 text-center rotate-[-12deg] bg-emerald-50/30">
                <span className="text-[9px] font-black uppercase text-emerald-700 tracking-tight">BALAJI GROUP</span>
                <span className="text-[8px] font-bold text-emerald-600">VERIFIED</span>
                <span className="text-[7px] text-emerald-500">{payment.verifiedAt || 'Verified'}</span>
              </div>
              <div className="text-[11px] text-slate-500">
                <p className="font-medium text-slate-700">Payment Status: <span className="text-emerald-600 font-semibold">{payment.status}</span></p>
                <p>Verified By: {payment.verifiedBy || 'Balaji Accounts Desk'}</p>
                <p className="text-[10px] text-slate-400">System generated computer receipt. No physical signature required.</p>
              </div>
            </div>

            <div className="text-right">
              <div className="h-10 w-32 border-b border-slate-400 mb-1 flex items-end justify-center">
                <span className="font-serif italic text-sm text-slate-700 font-semibold">Ramesh Sharma</span>
              </div>
              <p className="text-[11px] font-bold text-slate-800">Authorized Signatory</p>
              <p className="text-[10px] text-slate-500">Balaji Group Real Estate</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
