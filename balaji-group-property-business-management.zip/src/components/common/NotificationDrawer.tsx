import React from 'react';
import { X, Bell, CheckCheck, CreditCard, Ticket, Tag, Home, Info } from 'lucide-react';
import { useApp } from '../../context/AppContext';

interface NotificationDrawerProps {
  isOpen: boolean;
  onClose: () => void;
}

export const NotificationDrawer: React.FC<NotificationDrawerProps> = ({ isOpen, onClose }) => {
  const { notifications, currentCustomer, markNotificationRead, t } = useApp();

  if (!isOpen) return null;

  // Filter notifications relevant to this customer or broadcast
  const userNotifs = notifications.filter(
    (n) => !n.customerId || n.customerId === currentCustomer?.id
  );

  const getIcon = (type: string) => {
    switch (type) {
      case 'payment':
        return <CreditCard className="w-4 h-4 text-emerald-600" />;
      case 'due':
        return <CreditCard className="w-4 h-4 text-orange-600" />;
      case 'coupon':
        return <Tag className="w-4 h-4 text-purple-600" />;
      case 'property':
        return <Home className="w-4 h-4 text-blue-600" />;
      case 'support':
        return <Ticket className="w-4 h-4 text-amber-600" />;
      default:
        return <Info className="w-4 h-4 text-slate-600" />;
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/40 backdrop-blur-xs flex justify-end">
      <div className="bg-white w-full max-w-sm h-full shadow-2xl flex flex-col border-l border-slate-200 animate-in slide-in-from-right duration-200">
        {/* Drawer Header */}
        <div className="p-4 border-b border-slate-200 flex items-center justify-between bg-slate-50">
          <div className="flex items-center gap-2">
            <Bell className="w-5 h-5 text-orange-600" />
            <h3 className="font-bold text-slate-900 text-sm">{t('notifications')}</h3>
            <span className="text-xs bg-orange-100 text-orange-800 font-semibold px-2 py-0.5 rounded-full">
              {userNotifs.filter((n) => !n.read).length}
            </span>
          </div>
          <button
            onClick={onClose}
            className="p-1 hover:bg-slate-200 rounded-lg text-slate-500 hover:text-slate-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Notifications List */}
        <div className="flex-1 overflow-y-auto p-3 space-y-2.5">
          {userNotifs.length === 0 ? (
            <div className="py-12 text-center text-slate-400">
              <Bell className="w-8 h-8 mx-auto mb-2 opacity-30" />
              <p className="text-sm">{t('noNotifications')}</p>
            </div>
          ) : (
            userNotifs.map((n) => (
              <div
                key={n.id}
                onClick={() => markNotificationRead(n.id)}
                className={`p-3.5 rounded-xl border transition-all cursor-pointer ${
                  n.read
                    ? 'bg-white border-slate-200 text-slate-600'
                    : 'bg-orange-50/60 border-orange-200 text-slate-900 shadow-2xs'
                }`}
              >
                <div className="flex items-start gap-2.5">
                  <div className="p-2 bg-white rounded-lg shadow-2xs shrink-0 border border-slate-100">
                    {getIcon(n.type)}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between gap-1 mb-0.5">
                      <h4 className="font-semibold text-xs text-slate-900 truncate">{n.title}</h4>
                      <span className="text-[10px] text-slate-400 whitespace-nowrap">{n.date}</span>
                    </div>
                    <p className="text-xs text-slate-600 leading-relaxed">{n.message}</p>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Footer */}
        <div className="p-3 border-t border-slate-200 bg-slate-50 flex justify-between items-center text-xs text-slate-500">
          <span className="flex items-center gap-1">
            <CheckCheck className="w-3.5 h-3.5 text-slate-400" />
            <span>Tap any notification to mark read</span>
          </span>
          <button
            onClick={() => userNotifs.forEach((n) => markNotificationRead(n.id))}
            className="text-orange-600 hover:text-orange-700 font-semibold cursor-pointer"
          >
            Mark all read
          </button>
        </div>
      </div>
    </div>
  );
};
