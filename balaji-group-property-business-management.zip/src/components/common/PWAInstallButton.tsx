import React, { useState } from 'react';
import {
  Download,
  Smartphone,
  CheckCircle2,
  Share2,
  ExternalLink,
  QrCode,
  X,
  Layers,
  ShieldCheck,
  Package,
} from 'lucide-react';
import { usePWAInstall } from '../../hooks/usePWAInstall';

interface PWAInstallButtonProps {
  variant?: 'header' | 'floating' | 'banner' | 'card';
  className?: string;
}

export const PWAInstallButton: React.FC<PWAInstallButtonProps> = ({
  variant = 'header',
  className = '',
}) => {
  const { isInstallable, isInstalled, isIOS, isAndroid, install } = usePWAInstall();
  const [showModal, setShowModal] = useState(false);
  const [isCopied, setIsCopied] = useState(false);

  // App live production URL for scanning or PWABuilder
  const appUrl =
    typeof window !== 'undefined'
      ? window.location.origin
      : 'https://ais-pre-wau3gpsaq4dakmbjiqbkjq-873736810111.asia-east1.run.app';

  // Microsoft PWABuilder direct link to generate signed Android APK / AAB
  const pwaBuilderUrl = `https://www.pwabuilder.com/reportcard?site=${encodeURIComponent(appUrl)}`;

  const handleCopyUrl = () => {
    if (typeof navigator !== 'undefined') {
      navigator.clipboard.writeText(appUrl);
      setIsCopied(true);
      setTimeout(() => setIsCopied(false), 2500);
    }
  };

  const handleInstallClick = async () => {
    if (isInstallable) {
      const accepted = await install();
      if (!accepted) {
        setShowModal(true);
      }
    } else {
      setShowModal(true);
    }
  };

  if (isInstalled && variant === 'header') {
    return (
      <div className="hidden sm:flex items-center gap-1.5 px-3 py-1 bg-emerald-50 border border-emerald-200 rounded-xl text-emerald-800 text-xs font-semibold">
        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
        <span>APK Installed</span>
      </div>
    );
  }

  return (
    <>
      {/* 1. HEADER VARIANT */}
      {variant === 'header' && (
        <button
          type="button"
          onClick={handleInstallClick}
          className={`group flex items-center gap-2 px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-orange-600 to-amber-600 hover:from-orange-700 hover:to-amber-700 text-white font-bold text-xs shadow-sm hover:shadow active:scale-95 transition-all cursor-pointer ${className}`}
          title="Install Balaji Group APK on Android/iOS"
        >
          <Smartphone className="w-4 h-4 transition-transform group-hover:scale-110" />
          <span className="hidden sm:inline">Install App / APK</span>
          <span className="sm:hidden">Install App</span>
          <span className="px-1.5 py-0.2 bg-white/20 rounded text-[10px] font-mono">APK</span>
        </button>
      )}

      {/* 2. CARD VARIANT (for Settings or Dashboard) */}
      {variant === 'card' && (
        <div
          className={`p-4 rounded-2xl bg-gradient-to-br from-orange-50 via-amber-50 to-white border border-orange-200 shadow-sm ${className}`}
        >
          <div className="flex items-start justify-between gap-3">
            <div className="flex items-center gap-3">
              <div className="w-11 h-11 rounded-2xl bg-gradient-to-br from-orange-600 to-amber-600 text-white flex items-center justify-center shadow-md shadow-orange-600/20 shrink-0">
                <Package className="w-6 h-6" />
              </div>
              <div>
                <h4 className="font-extrabold text-slate-900 text-sm flex items-center gap-1.5">
                  Balaji Group Android App (APK / PWA)
                  <span className="px-1.5 py-0.5 text-[9px] font-bold bg-orange-600 text-white rounded">
                    Direct
                  </span>
                </h4>
                <p className="text-xs text-slate-600 mt-0.5">
                  Install directly on your Android phone without Google Play. Fast, offline-ready & instant updates.
                </p>
              </div>
            </div>
            <button
              type="button"
              onClick={handleInstallClick}
              className="px-4 py-2 bg-orange-600 hover:bg-orange-700 text-white font-bold text-xs rounded-xl shadow-sm flex items-center gap-1.5 shrink-0 cursor-pointer transition-all active:scale-95"
            >
              <Download className="w-4 h-4" />
              <span>{isInstallable ? 'Install Now' : 'Get APK'}</span>
            </button>
          </div>
        </div>
      )}

      {/* 3. FLOATING VARIANT */}
      {variant === 'floating' && !isInstalled && (
        <button
          type="button"
          onClick={handleInstallClick}
          className={`fixed bottom-20 right-4 z-40 flex items-center gap-2 px-4 py-2.5 rounded-full bg-slate-900 text-white shadow-xl hover:bg-black font-bold text-xs border border-slate-700 active:scale-95 transition-all cursor-pointer ${className}`}
        >
          <Smartphone className="w-4 h-4 text-orange-400" />
          <span>Get APK App</span>
        </button>
      )}

      {/* COMPREHENSIVE APK & INSTALL MODAL */}
      {showModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 animate-in fade-in duration-200">
          <div className="w-full max-w-lg bg-white rounded-3xl shadow-2xl border border-slate-200 overflow-hidden max-h-[92vh] flex flex-col">
            {/* Header */}
            <div className="relative bg-gradient-to-r from-orange-600 via-amber-600 to-orange-700 p-5 text-white">
              <button
                type="button"
                onClick={() => setShowModal(false)}
                className="absolute top-4 right-4 p-1.5 rounded-full bg-white/10 hover:bg-white/20 text-white transition cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>

              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-2xl bg-white text-orange-600 flex items-center justify-center font-black text-xl shadow-md">
                  BG
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="text-lg font-black tracking-tight">Balaji Group Mobile App</h3>
                    <span className="px-2 py-0.5 rounded-full bg-white/20 text-white text-[10px] font-bold">
                      APK / PWA
                    </span>
                  </div>
                  <p className="text-xs text-orange-100 mt-0.5">
                    Official Mobile Application for Property Management
                  </p>
                </div>
              </div>
            </div>

            {/* Modal Body */}
            <div className="p-5 overflow-y-auto space-y-4 text-xs text-slate-700">
              {/* Option 1: Instant 1-Tap WebAPK Installation on Android */}
              <div className="p-4 rounded-2xl bg-gradient-to-br from-emerald-50 to-teal-50 border border-emerald-200 space-y-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2 font-black text-emerald-950 text-sm">
                    <Smartphone className="w-4 h-4 text-emerald-600" />
                    <span>Method 1: Instant Install on Android (WebAPK)</span>
                  </div>
                  <span className="px-2 py-0.5 bg-emerald-600 text-white rounded-full text-[10px] font-bold">
                    Recommended
                  </span>
                </div>
                <p className="text-emerald-900 leading-relaxed text-[11px]">
                  Android Chrome generates an official native <strong>WebAPK</strong> directly on your phone with the Balaji Group app icon, full-screen mode, and offline storage.
                </p>

                {isInstallable ? (
                  <button
                    type="button"
                    onClick={async () => {
                      await install();
                      setShowModal(false);
                    }}
                    className="w-full py-2.5 px-4 bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold rounded-xl shadow-md shadow-emerald-600/20 flex items-center justify-center gap-2 cursor-pointer transition-all active:scale-95"
                  >
                    <Download className="w-4 h-4" />
                    <span>1-Tap Install APK Now</span>
                  </button>
                ) : (
                  <div className="p-3 bg-white/80 rounded-xl border border-emerald-200/70 text-[11px] text-emerald-950 space-y-1">
                    <span className="font-bold block">How to install in Chrome/Samsung Internet:</span>
                    <ol className="list-decimal list-inside space-y-0.5">
                      <li>Tap the <strong>three dots menu (⋮)</strong> at top-right of your browser.</li>
                      <li>Select <strong>"Install app"</strong> or <strong>"Add to Home screen"</strong>.</li>
                      <li>Android will package the APK and place the Balaji Group icon on your phone's home screen!</li>
                    </ol>
                  </div>
                )}
              </div>

              {/* Option 2: Generate Signed Standalone .APK / .AAB with PWABuilder */}
              <div className="p-4 rounded-2xl bg-gradient-to-br from-blue-50 to-indigo-50 border border-blue-200 space-y-2.5">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2 font-black text-blue-950 text-sm">
                    <Package className="w-4 h-4 text-blue-600" />
                    <span>Method 2: Download Signed .APK / .AAB Package</span>
                  </div>
                  <span className="px-2 py-0.5 bg-blue-600 text-white rounded-full text-[10px] font-bold">
                    Play Store / Sideload
                  </span>
                </div>
                <p className="text-blue-900 leading-relaxed text-[11px]">
                  Want a physical signed <strong>.apk</strong> file to distribute via WhatsApp, pen drive, or publish on the <strong>Google Play Store</strong>? Microsoft's free <strong>PWABuilder</strong> packages this web app into a ready Android APK/AAB in 1 click!
                </p>

                <div className="flex flex-col sm:flex-row gap-2 pt-1">
                  <a
                    href={pwaBuilderUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex-1 py-2.5 px-3 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl text-center flex items-center justify-center gap-1.5 cursor-pointer shadow-sm active:scale-95 transition-all text-xs"
                  >
                    <ExternalLink className="w-3.5 h-3.5" />
                    <span>Open PWABuilder (1-Click APK)</span>
                  </a>
                  <button
                    type="button"
                    onClick={handleCopyUrl}
                    className="py-2.5 px-3 bg-white border border-blue-300 text-blue-900 font-bold rounded-xl hover:bg-blue-50 transition cursor-pointer text-xs flex items-center justify-center gap-1 shrink-0"
                  >
                    <span>{isCopied ? 'URL Copied!' : 'Copy App URL'}</span>
                  </button>
                </div>
              </div>

              {/* Option 3: iOS iPhone / iPad Installation */}
              {isIOS && (
                <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-2">
                  <div className="flex items-center gap-2 font-bold text-slate-900 text-sm">
                    <Share2 className="w-4 h-4 text-orange-600" />
                    <span>Install on iPhone / iPad (iOS Safari)</span>
                  </div>
                  <ol className="list-decimal list-inside space-y-1 text-slate-600 text-[11px]">
                    <li>Tap the <strong>Share</strong> button in Safari's bottom toolbar.</li>
                    <li>Scroll down and tap <strong>"Add to Home Screen"</strong>.</li>
                    <li>Tap <strong>Add</strong> at top right. The Balaji Group icon will appear on your home screen.</li>
                  </ol>
                </div>
              )}

              {/* Direct QR Code to open on phone */}
              <div className="p-3.5 bg-slate-50 rounded-2xl border border-slate-200 flex items-center gap-3">
                <div className="p-2 bg-white rounded-xl border border-slate-200 shrink-0">
                  <QrCode className="w-8 h-8 text-slate-800" />
                </div>
                <div className="min-w-0 flex-1">
                  <span className="font-bold text-slate-900 block text-xs">
                    Scan on Android Phone to Install
                  </span>
                  <span className="text-[10px] text-slate-500 block truncate font-mono mt-0.5">
                    {appUrl}
                  </span>
                </div>
                <button
                  type="button"
                  onClick={handleCopyUrl}
                  className="px-2.5 py-1.5 bg-white border border-slate-200 text-slate-700 font-bold rounded-lg text-[10px] hover:bg-slate-100 shrink-0 cursor-pointer"
                >
                  {isCopied ? 'Copied!' : 'Copy Link'}
                </button>
              </div>

              {/* Security & Offline Highlights */}
              <div className="grid grid-cols-2 gap-2 pt-1 text-[10px] text-slate-500">
                <div className="flex items-center gap-1.5">
                  <ShieldCheck className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                  <span>Google Cloud SSL Secure</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <Layers className="w-3.5 h-3.5 text-blue-600 shrink-0" />
                  <span>Offline Pre-Caching Included</span>
                </div>
              </div>
            </div>

            {/* Modal Footer */}
            <div className="p-3 bg-slate-50 border-t border-slate-100 flex items-center justify-end">
              <button
                type="button"
                onClick={() => setShowModal(false)}
                className="px-4 py-2 bg-slate-200 hover:bg-slate-300 text-slate-800 font-bold rounded-xl text-xs transition cursor-pointer"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
