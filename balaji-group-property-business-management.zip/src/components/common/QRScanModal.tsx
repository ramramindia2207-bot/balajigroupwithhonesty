import React, { useState } from 'react';
import { X, Copy, Check, QrCode, ShieldCheck, ArrowRight, Upload, AlertCircle } from 'lucide-react';
import { useApp } from '../../context/AppContext';

interface QRScanModalProps {
  initialAmount?: number;
  onClose: () => void;
  onSuccess?: () => void;
}

export const QRScanModal: React.FC<QRScanModalProps> = ({
  initialAmount = 12500,
  onClose,
  onSuccess,
}) => {
  const { currentCustomer, customerProperty, settings, submitQrPayment, appliedCoupon } = useApp();
  const [amount, setAmount] = useState<number>(initialAmount);
  const [transactionId, setTransactionId] = useState<string>('');
  const [notes, setNotes] = useState<string>('');
  const [copied, setCopied] = useState<boolean>(false);
  const [screenshotUploaded, setScreenshotUploaded] = useState<boolean>(false);
  const [submitting, setSubmitting] = useState<boolean>(false);
  const [submitted, setSubmitted] = useState<boolean>(false);
  const [error, setError] = useState<string>('');

  const upiId = settings.upiId || 'balajigroup@icici';
  const payeeName = settings.businessName || 'Balaji Group';

  // Apply discount if coupon is present
  const discount = appliedCoupon?.discountAmount || (appliedCoupon?.discountPercentage ? (amount * appliedCoupon.discountPercentage) / 100 : 0);
  const payableAmount = Math.max(1, amount - discount);

  // Formatted UPI Intent URI for QR code
  const upiUri = `upi://pay?pa=${encodeURIComponent(upiId)}&pn=${encodeURIComponent(payeeName)}&am=${payableAmount}&cu=INR&tn=${encodeURIComponent(`Plot ${customerProperty?.plotNumber || ''} Kist`)}`;

  const handleCopyUpi = () => {
    navigator.clipboard.writeText(upiId);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!transactionId.trim() || transactionId.trim().length < 6) {
      setError('Please enter a valid 12-digit UTR or Transaction Reference number.');
      return;
    }

    if (!currentCustomer) {
      setError('Customer session expired. Please re-login.');
      return;
    }

    setSubmitting(true);
    setError('');

    setTimeout(() => {
      submitQrPayment({
        customerId: currentCustomer.id,
        amount: payableAmount,
        transactionId: transactionId.trim().toUpperCase(),
        notes: notes.trim() || (appliedCoupon ? `Applied coupon ${appliedCoupon.code}` : undefined),
        receiptFileUrl: screenshotUploaded ? 'screenshot_uploaded.png' : undefined,
      });

      setSubmitting(false);
      setSubmitted(true);
      if (onSuccess) {
        setTimeout(onSuccess, 1500);
      }
    }, 600);
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-white w-full max-w-lg rounded-2xl shadow-2xl overflow-hidden border border-slate-200 animate-in fade-in duration-200 my-6">
        {/* Top Header */}
        <div className="bg-gradient-to-r from-orange-600 to-orange-500 px-6 py-4 text-white flex items-center justify-between">
          <div className="flex items-center gap-2">
            <QrCode className="w-5 h-5 text-orange-100" />
            <h3 className="font-bold text-base">Scan & Pay via UPI</h3>
          </div>
          <button
            onClick={onClose}
            className="p-1 hover:bg-orange-700/50 rounded-lg text-white/80 hover:text-white transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {submitted ? (
          <div className="p-8 text-center">
            <div className="w-16 h-16 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto mb-4">
              <ShieldCheck className="w-10 h-10" />
            </div>
            <h4 className="text-xl font-bold text-slate-900 mb-2">Payment Submitted!</h4>
            <p className="text-sm text-slate-600 mb-6 max-w-sm mx-auto leading-relaxed">
              Your transaction <span className="font-mono font-semibold text-slate-900">{transactionId}</span> for{' '}
              <span className="font-bold text-slate-900">₹{payableAmount.toLocaleString('en-IN')}</span> has been queued for verification.
              Our accounts team will verify and generate your digital receipt shortly.
            </p>
            <button
              onClick={onClose}
              className="w-full py-3 bg-orange-600 hover:bg-orange-700 text-white font-semibold rounded-xl text-sm transition-colors cursor-pointer shadow-md shadow-orange-600/20"
            >
              Back to Dashboard
            </button>
          </div>
        ) : (
          <div className="p-6 max-h-[85vh] overflow-y-auto">
            {/* Amount Configuration */}
            <div className="bg-orange-50/80 rounded-xl p-4 border border-orange-200/60 mb-5 text-center">
              <span className="text-xs font-medium text-orange-800 uppercase tracking-wider block mb-1">
                Amount to Pay
              </span>
              <div className="flex items-baseline justify-center gap-1">
                <span className="text-2xl font-bold text-orange-600">₹</span>
                <span className="text-3xl font-extrabold text-slate-900 font-mono tabular-nums">
                  {payableAmount.toLocaleString('en-IN')}
                </span>
              </div>
              {discount > 0 && (
                <p className="text-xs text-emerald-700 font-medium mt-1">
                  🎉 Coupon {appliedCoupon?.code} applied! Saved ₹{discount.toLocaleString('en-IN')}
                </p>
              )}
              {customerProperty && (
                <p className="text-xs text-slate-500 mt-1">
                  Plot No. {customerProperty.plotNumber} · {currentCustomer?.name}
                </p>
              )}
            </div>

            {/* Live QR Code Box */}
            <div className="flex flex-col items-center justify-center p-6 bg-slate-50 rounded-2xl border border-slate-200 mb-5">
              <div className="relative p-4 bg-white rounded-xl shadow-sm border border-slate-200">
                {settings.qrCodeUrl ? (
                  <img
                    src={settings.qrCodeUrl}
                    alt="Balaji Group UPI Payment QR"
                    referrerPolicy="no-referrer"
                    className="w-48 h-48 object-contain rounded-lg"
                    onError={(e) => {
                      // Fallback if URL is invalid
                      (e.target as HTMLElement).style.display = 'none';
                    }}
                  />
                ) : (
                  /* Visual SVG QR Code generator */
                  <svg
                    viewBox="0 0 200 200"
                    className="w-48 h-48 rounded-lg"
                    aria-label="UPI Payment QR Code"
                  >
                    {/* Outer corner finders */}
                    <rect width="200" height="200" fill="#FFFFFF" />
                    
                    {/* Top-Left Finder */}
                    <rect x="15" y="15" width="50" height="50" fill="#0F172A" rx="4" />
                    <rect x="23" y="23" width="34" height="34" fill="#FFFFFF" rx="2" />
                    <rect x="31" y="31" width="18" height="18" fill="#EA580C" rx="1" />

                    {/* Top-Right Finder */}
                    <rect x="135" y="15" width="50" height="50" fill="#0F172A" rx="4" />
                    <rect x="143" y="23" width="34" height="34" fill="#FFFFFF" rx="2" />
                    <rect x="151" y="31" width="18" height="18" fill="#EA580C" rx="1" />

                    {/* Bottom-Left Finder */}
                    <rect x="15" y="135" width="50" height="50" fill="#0F172A" rx="4" />
                    <rect x="23" y="143" width="34" height="34" fill="#FFFFFF" rx="2" />
                    <rect x="31" y="151" width="18" height="18" fill="#EA580C" rx="1" />

                    {/* Simulated QR Matrix Dots */}
                    <g fill="#1E293B">
                      <rect x="75" y="20" width="8" height="8" />
                      <rect x="90" y="20" width="8" height="8" />
                      <rect x="110" y="20" width="8" height="8" />
                      <rect x="75" y="35" width="8" height="8" />
                      <rect x="100" y="35" width="8" height="8" />
                      <rect x="85" y="50" width="8" height="8" />
                      <rect x="115" y="50" width="8" height="8" />

                      <rect x="20" y="75" width="8" height="8" />
                      <rect x="35" y="75" width="8" height="8" />
                      <rect x="50" y="85" width="8" height="8" />
                      <rect x="20" y="100" width="8" height="8" />
                      <rect x="40" y="115" width="8" height="8" />

                      <rect x="75" y="75" width="8" height="8" />
                      <rect x="90" y="85" width="8" height="8" />
                      <rect x="115" y="75" width="8" height="8" />
                      <rect x="75" y="105" width="8" height="8" />
                      <rect x="105" y="105" width="8" height="8" />
                      <rect x="90" y="120" width="8" height="8" />

                      <rect x="140" y="75" width="8" height="8" />
                      <rect x="165" y="75" width="8" height="8" />
                      <rect x="150" y="90" width="8" height="8" />
                      <rect x="175" y="100" width="8" height="8" />
                      <rect x="140" y="115" width="8" height="8" />

                      <rect x="75" y="140" width="8" height="8" />
                      <rect x="95" y="140" width="8" height="8" />
                      <rect x="115" y="155" width="8" height="8" />
                      <rect x="85" y="170" width="8" height="8" />
                      <rect x="140" y="140" width="8" height="8" />
                      <rect x="160" y="155" width="8" height="8" />
                      <rect x="175" y="170" width="8" height="8" />
                      <rect x="145" y="175" width="8" height="8" />
                    </g>

                    {/* Center House Brand Emblem */}
                    <rect x="82" y="82" width="36" height="36" rx="8" fill="#EA580C" />
                    <path d="M100 89L89 98H93V111H107V98H111L100 89Z" fill="#FFFFFF" />
                  </svg>
                )}
              </div>

              {/* Supported UPI Apps */}
              <div className="flex items-center gap-3 mt-4 text-xs font-semibold text-slate-500">
                <span className="text-slate-700">Supported:</span>
                <span className="text-emerald-700 font-bold bg-emerald-50 px-2 py-0.5 rounded">GPay</span>
                <span className="text-indigo-700 font-bold bg-indigo-50 px-2 py-0.5 rounded">PhonePe</span>
                <span className="text-sky-700 font-bold bg-sky-50 px-2 py-0.5 rounded">Paytm</span>
                <span className="text-orange-700 font-bold bg-orange-50 px-2 py-0.5 rounded">BHIM</span>
              </div>
            </div>

            {/* UPI ID Row with Copy */}
            <div className="flex items-center justify-between p-3 bg-slate-100 rounded-xl border border-slate-200 mb-5">
              <div>
                <span className="text-[10px] uppercase font-bold text-slate-400 block">UPI ID</span>
                <span className="font-mono text-sm font-bold text-slate-900">{upiId}</span>
              </div>
              <button
                type="button"
                onClick={handleCopyUpi}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-white hover:bg-slate-50 border border-slate-200 text-slate-700 rounded-lg text-xs font-medium transition-colors shadow-2xs cursor-pointer"
              >
                {copied ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-emerald-600" />
                    <span className="text-emerald-600 font-semibold">Copied!</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5 text-slate-500" />
                    <span>Copy</span>
                  </>
                )}
              </button>
            </div>

            {/* Transaction Verification Submission Form */}
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="border-t border-slate-200 pt-4">
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-600 mb-3 flex items-center gap-1.5">
                  <ShieldCheck className="w-4 h-4 text-orange-600" />
                  <span>Submit Payment Reference After Transfer</span>
                </h4>

                {error && (
                  <div className="flex items-center gap-2 p-2.5 bg-rose-50 border border-rose-200 rounded-lg text-xs text-rose-700 mb-3">
                    <AlertCircle className="w-4 h-4 shrink-0" />
                    <span>{error}</span>
                  </div>
                )}

                <div className="space-y-3">
                  <div>
                    <label className="block text-xs font-medium text-slate-700 mb-1">
                      12-Digit UPI Transaction ID / UTR Number <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="text"
                      placeholder="e.g. 428910248102 or TXN123456"
                      value={transactionId}
                      onChange={(e) => setTransactionId(e.target.value)}
                      required
                      className="w-full px-3.5 py-2.5 bg-white border border-slate-300 rounded-xl text-sm font-mono focus:outline-hidden focus:ring-2 focus:ring-orange-500 focus:border-orange-500"
                    />
                    <p className="text-[11px] text-slate-400 mt-1">
                      Found in your Google Pay / PhonePe / Bank app payment details receipt.
                    </p>
                  </div>

                  <div>
                    <label className="block text-xs font-medium text-slate-700 mb-1">
                      Payment Screenshot Proof (Optional)
                    </label>
                    <div
                      onClick={() => setScreenshotUploaded(true)}
                      className={`border border-dashed rounded-xl p-3 text-center cursor-pointer transition-colors ${
                        screenshotUploaded
                          ? 'border-emerald-500 bg-emerald-50/50'
                          : 'border-slate-300 hover:border-orange-400 bg-slate-50'
                      }`}
                    >
                      <div className="flex items-center justify-center gap-2 text-xs">
                        <Upload className="w-4 h-4 text-slate-500" />
                        <span className={screenshotUploaded ? 'text-emerald-700 font-semibold' : 'text-slate-600'}>
                          {screenshotUploaded ? '✓ Screenshot Attached (payment_receipt.png)' : 'Click to attach payment screenshot'}
                        </span>
                      </div>
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-medium text-slate-700 mb-1">
                      Notes for Accounts Department (Optional)
                    </label>
                    <input
                      type="text"
                      placeholder="e.g. Payment made from HDFC Bank account of father"
                      value={notes}
                      onChange={(e) => setNotes(e.target.value)}
                      className="w-full px-3.5 py-2 bg-white border border-slate-300 rounded-xl text-xs focus:outline-hidden focus:ring-2 focus:ring-orange-500"
                    />
                  </div>
                </div>
              </div>

              <button
                type="submit"
                disabled={submitting}
                className="w-full mt-4 py-3 bg-orange-600 hover:bg-orange-700 disabled:bg-orange-400 text-white font-semibold rounded-xl text-sm transition-colors cursor-pointer flex items-center justify-center gap-2 shadow-md shadow-orange-600/20"
              >
                {submitting ? (
                  <span>Submitting to Accounts...</span>
                ) : (
                  <>
                    <span>Submit for Admin Verification</span>
                    <ArrowRight className="w-4 h-4" />
                  </>
                )}
              </button>
            </form>
          </div>
        )}
      </div>
    </div>
  );
};
