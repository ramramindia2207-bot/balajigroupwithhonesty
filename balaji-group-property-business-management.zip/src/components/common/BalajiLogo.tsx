import React from 'react';

interface BalajiLogoProps {
  size?: 'sm' | 'md' | 'lg' | 'xl';
  variant?: 'light' | 'dark' | 'orange';
  showTagline?: boolean;
}

export const BalajiLogo: React.FC<BalajiLogoProps> = ({
  size = 'md',
  variant = 'orange',
  showTagline = false,
}) => {
  const sizeClasses = {
    sm: 'h-7',
    md: 'h-9',
    lg: 'h-12',
    xl: 'h-16',
  };

  const textClasses = {
    sm: 'text-base font-bold tracking-tight',
    md: 'text-xl font-bold tracking-tight',
    lg: 'text-2xl font-black tracking-tight',
    xl: 'text-3xl font-black tracking-tight',
  };

  const taglineClasses = {
    sm: 'text-[9px]',
    md: 'text-[10px]',
    lg: 'text-xs',
    xl: 'text-sm',
  };

  const textColor = variant === 'light' ? 'text-white' : variant === 'dark' ? 'text-slate-900' : 'text-slate-900';
  const brandOrange = '#EA580C'; // Tailwind orange-600

  return (
    <div className="flex items-center gap-2.5 select-none">
      {/* House Icon matching Balaji Group branding */}
      <div className={`aspect-square flex items-center justify-center shrink-0 ${sizeClasses[size]}`}>
        <svg
          viewBox="0 0 48 48"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
          className="w-full h-full drop-shadow-sm"
        >
          {/* Outer modern roof eaves */}
          <path
            d="M24 4L4 21H10V42H38V21H44L24 4Z"
            fill={variant === 'light' ? '#FFFFFF' : brandOrange}
            opacity="0.15"
          />
          {/* Main geometric roof rafters */}
          <path
            d="M24 6L5 22H11L24 10.5L37 22H43L24 6Z"
            fill={variant === 'light' ? '#FFFFFF' : brandOrange}
          />
          {/* Inner house frame */}
          <path
            d="M13 23V41H35V23L24 13.5L13 23Z"
            stroke={variant === 'light' ? '#FFFFFF' : brandOrange}
            strokeWidth="3.5"
            strokeLinejoin="round"
          />
          {/* Central sun / plot symbol */}
          <rect
            x="20"
            y="25"
            width="8"
            height="10"
            rx="1.5"
            fill={variant === 'light' ? '#FFFFFF' : brandOrange}
          />
          <path
            d="M16 28H19M29 28H32M16 33H19M29 33H32"
            stroke={variant === 'light' ? '#FFFFFF' : brandOrange}
            strokeWidth="2.5"
            strokeLinecap="round"
          />
        </svg>
      </div>

      <div className="flex flex-col leading-none">
        <span className={`${textClasses[size]} ${textColor} uppercase font-heading tracking-wide`}>
          <span className="text-orange-600">BALAJI</span>{' '}
          <span className={variant === 'light' ? 'text-white' : 'text-slate-900'}>GROUP</span>
        </span>
        {showTagline && (
          <span
            className={`font-medium tracking-wider uppercase mt-0.5 ${taglineClasses[size]} ${
              variant === 'light' ? 'text-orange-200' : 'text-orange-600'
            }`}
          >
            Your Dream Our Priority
          </span>
        )}
      </div>
    </div>
  );
};
