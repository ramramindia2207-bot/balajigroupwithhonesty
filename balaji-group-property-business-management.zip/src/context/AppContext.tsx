import React, { createContext, useContext, useState, useEffect } from 'react';
import {
  Customer,
  Property,
  PaymentRecord,
  Coupon,
  SupportTicket,
  AppNotification,
  BusinessSettings,
  AuditLog,
  UserRole,
  Language,
} from '../types';
import {
  INITIAL_CUSTOMERS,
  INITIAL_PROPERTIES,
  INITIAL_PAYMENTS,
  INITIAL_COUPONS,
  INITIAL_TICKETS,
  INITIAL_NOTIFICATIONS,
  INITIAL_SETTINGS,
  INITIAL_AUDIT_LOGS,
} from '../data/mockData';
import { translations } from '../i18n/translations';

interface AppContextType {
  // Mode & Language
  appMode: 'customer' | 'admin';
  setAppMode: (mode: 'customer' | 'admin') => void;
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: keyof typeof translations.en) => string;

  // Customer Auth
  currentCustomer: Customer | null;
  customerProperty: Property | null;
  customerPayments: PaymentRecord[];
  loginWithPhone: (mobile: string) => { exists: boolean; hasPin: boolean; customer?: Customer };
  verifyOtp: (mobile: string, otp: string) => { success: boolean; customer?: Customer; isNew?: boolean; message?: string };
  loginWithPin: (mobile: string, pin: string) => { success: boolean; customer?: Customer; message?: string; isFirstPin?: boolean };
  directSafeLogin: (mobile: string) => { success: boolean; customer?: Customer; isNew?: boolean; message?: string };
  setCustomerPin: (customerId: string, pin: string) => void;
  registerNewCustomer: (data: { name: string; mobile: string; email: string; city: string; address?: string; interestedPlot?: string; budget?: string }) => Customer;
  logoutCustomer: () => void;
  selectDemoCustomer: (mobile: string) => void;

  // Admin Auth
  isAdminLoggedIn: boolean;
  adminUser: { name: string; email: string; role: UserRole };
  loginAdmin: (email: string, role?: UserRole) => boolean;
  verifyAdminPassword: (password: string) => boolean;
  logoutAdmin: () => void;
  setAdminRole: (role: UserRole) => void;

  // Data Stores
  customers: Customer[];
  properties: Property[];
  payments: PaymentRecord[];
  coupons: Coupon[];
  supportTickets: SupportTicket[];
  notifications: AppNotification[];
  settings: BusinessSettings;
  auditLogs: AuditLog[];

  // Customer Financial Calculations
  calculateCustomerFinance: (customer: Customer) => {
    totalValue: number;
    totalPaid: number;
    remainingAmount: number;
    dueAmount: number;
    totalKists: number;
    paidKists: number;
    remainingKists: number;
    monthlyKist: number;
    nextDueDate: string;
  };

  // Actions - Customers
  addCustomer: (customerData: Omit<Customer, 'id'>) => Customer;
  updateCustomer: (id: string, updates: Partial<Customer>) => void;
  deleteCustomer: (id: string) => void;
  resetCustomerPin: (id: string) => void;
  importBulkCustomers: (customersList: Customer[], propertiesList?: Property[]) => { count: number };
  updateCustomerKistSchedule: (
    customerId: string,
    schedule: {
      status?: 'Active' | 'Due' | 'Suspended';
      kistStatus?: 'Due' | 'Next' | 'Advance' | 'Paid';
      nextDueDate?: string;
      customDueAmount?: number;
      monthlyKistAmount?: number;
      paidKists?: number;
    }
  ) => void;

  // Actions - Properties
  addProperty: (propertyData: Omit<Property, 'id'>) => Property;
  updateProperty: (id: string, updates: Partial<Property>) => void;
  deleteProperty: (id: string) => void;
  assignProperty: (propertyId: string, customerId: string, financialPlan?: { totalValue?: number; bookingAmount?: number; monthlyKist?: number; totalKists?: number }) => void;
  addPropertyDocument: (propertyId: string, document: { name: string; type: any; fileSize: string }) => void;

  // Actions - Payments
  submitQrPayment: (paymentData: { customerId: string; amount: number; transactionId: string; notes?: string; receiptFileUrl?: string }) => PaymentRecord;
  approvePayment: (paymentId: string, notes?: string) => void;
  rejectPayment: (paymentId: string, reason: string) => void;
  addManualPayment: (paymentData: Omit<PaymentRecord, 'id' | 'receiptNumber' | 'status'>) => PaymentRecord;

  // Actions - Coupons
  appliedCoupon: Coupon | null;
  applyCouponCode: (code: string) => { success: boolean; coupon?: Coupon; message: string; discountAmount?: number };
  removeAppliedCoupon: () => void;
  addCoupon: (coupon: Omit<Coupon, 'id' | 'currentUsageCount'>) => Coupon;
  updateCoupon: (id: string, updates: Partial<Coupon>) => void;
  deleteCoupon: (id: string) => void;

  // Actions - Support Tickets
  createSupportTicket: (ticket: { customerId: string; subject: string; category: any; message: string; attachmentName?: string }) => SupportTicket;
  replyToSupportTicket: (ticketId: string, reply: string, status?: any) => void;

  // Actions - Notifications & Settings
  markNotificationRead: (id: string) => void;
  updateSettings: (newSettings: Partial<BusinessSettings>) => void;
  resetAllDataToDemo: () => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

const STORAGE_KEY_PREFIX = 'balaji_group_';

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // App Mode & Language
  const [appMode, setAppMode] = useState<'customer' | 'admin'>('customer');
  const [language, setLanguageState] = useState<Language>('en');

  // Customer Auth
  const [currentCustomerId, setCurrentCustomerId] = useState<string | null>(() => {
    return localStorage.getItem(`${STORAGE_KEY_PREFIX}active_customer`) || null;
  });

  // Admin Auth
  const [isAdminLoggedIn, setIsAdminLoggedIn] = useState<boolean>(() => {
    return sessionStorage.getItem(`${STORAGE_KEY_PREFIX}admin_auth`) === 'true';
  });
  const [adminUser, setAdminUser] = useState<{ name: string; email: string; role: UserRole }>({
    name: 'Ramesh Sharma',
    email: 'admin@balajigroup.in',
    role: 'super_admin',
  });

  // Data Collections with LocalStorage caching
  const [customers, setCustomers] = useState<Customer[]>(() => {
    const saved = localStorage.getItem(`${STORAGE_KEY_PREFIX}customers`);
    return saved ? JSON.parse(saved) : INITIAL_CUSTOMERS;
  });

  const [properties, setProperties] = useState<Property[]>(() => {
    const saved = localStorage.getItem(`${STORAGE_KEY_PREFIX}properties`);
    return saved ? JSON.parse(saved) : INITIAL_PROPERTIES;
  });

  const [payments, setPayments] = useState<PaymentRecord[]>(() => {
    const saved = localStorage.getItem(`${STORAGE_KEY_PREFIX}payments`);
    return saved ? JSON.parse(saved) : INITIAL_PAYMENTS;
  });

  const [coupons, setCoupons] = useState<Coupon[]>(() => {
    const saved = localStorage.getItem(`${STORAGE_KEY_PREFIX}coupons`);
    return saved ? JSON.parse(saved) : INITIAL_COUPONS;
  });

  const [appliedCoupon, setAppliedCoupon] = useState<Coupon | null>(null);

  const [supportTickets, setSupportTickets] = useState<SupportTicket[]>(() => {
    const saved = localStorage.getItem(`${STORAGE_KEY_PREFIX}tickets`);
    return saved ? JSON.parse(saved) : INITIAL_TICKETS;
  });

  const [notifications, setNotifications] = useState<AppNotification[]>(() => {
    const saved = localStorage.getItem(`${STORAGE_KEY_PREFIX}notifications`);
    return saved ? JSON.parse(saved) : INITIAL_NOTIFICATIONS;
  });

  const [settings, setSettings] = useState<BusinessSettings>(() => {
    const saved = localStorage.getItem(`${STORAGE_KEY_PREFIX}settings`);
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        return {
          ...INITIAL_SETTINGS,
          ...parsed,
          smsGateway: {
            ...INITIAL_SETTINGS.smsGateway,
            ...(parsed.smsGateway || {}),
            whatsappPhoneNumberId:
              parsed.smsGateway?.whatsappPhoneNumberId || INITIAL_SETTINGS.smsGateway?.whatsappPhoneNumberId,
            whatsappAccessToken:
              parsed.smsGateway?.whatsappAccessToken || INITIAL_SETTINGS.smsGateway?.whatsappAccessToken,
            whatsappTemplateName:
              parsed.smsGateway?.whatsappTemplateName || INITIAL_SETTINGS.smsGateway?.whatsappTemplateName,
            provider: 'whatsapp_cloud_api',
            enabled: true,
          },
        };
      } catch {
        return INITIAL_SETTINGS;
      }
    }
    return INITIAL_SETTINGS;
  });

  const [auditLogs, setAuditLogs] = useState<AuditLog[]>(() => {
    const saved = localStorage.getItem(`${STORAGE_KEY_PREFIX}audit_logs`);
    return saved ? JSON.parse(saved) : INITIAL_AUDIT_LOGS;
  });

  // Save changes to localStorage
  useEffect(() => {
    localStorage.setItem(`${STORAGE_KEY_PREFIX}customers`, JSON.stringify(customers));
  }, [customers]);

  useEffect(() => {
    localStorage.setItem(`${STORAGE_KEY_PREFIX}properties`, JSON.stringify(properties));
  }, [properties]);

  useEffect(() => {
    localStorage.setItem(`${STORAGE_KEY_PREFIX}payments`, JSON.stringify(payments));
  }, [payments]);

  useEffect(() => {
    localStorage.setItem(`${STORAGE_KEY_PREFIX}coupons`, JSON.stringify(coupons));
  }, [coupons]);

  useEffect(() => {
    localStorage.setItem(`${STORAGE_KEY_PREFIX}tickets`, JSON.stringify(supportTickets));
  }, [supportTickets]);

  useEffect(() => {
    localStorage.setItem(`${STORAGE_KEY_PREFIX}notifications`, JSON.stringify(notifications));
  }, [notifications]);

  useEffect(() => {
    localStorage.setItem(`${STORAGE_KEY_PREFIX}settings`, JSON.stringify(settings));
  }, [settings]);

  useEffect(() => {
    localStorage.setItem(`${STORAGE_KEY_PREFIX}audit_logs`, JSON.stringify(auditLogs));
  }, [auditLogs]);

  useEffect(() => {
    if (currentCustomerId) {
      localStorage.setItem(`${STORAGE_KEY_PREFIX}active_customer`, currentCustomerId);
    } else {
      localStorage.removeItem(`${STORAGE_KEY_PREFIX}active_customer`);
    }
  }, [currentCustomerId]);

  const setLanguage = (lang: Language) => {
    setLanguageState(lang);
  };

  const t = (key: keyof typeof translations.en): string => {
    const dict = translations[language] || translations.en;
    return dict[key] || translations.en[key] || (key as string);
  };

  // Helper log generator
  const addAuditLog = (action: string, details: string) => {
    const newLog: AuditLog = {
      id: `log-${Date.now()}`,
      action,
      user: `${adminUser.name} (${adminUser.role})`,
      role: adminUser.role,
      timestamp: new Date().toLocaleString('en-IN', { dateStyle: 'medium', timeStyle: 'short' }),
      details,
    };
    setAuditLogs((prev) => [newLog, ...prev]);
  };

  // Current logged in customer & assigned property
  const currentCustomer = customers.find((c) => c.id === currentCustomerId) || null;
  const customerProperty = currentCustomer?.propertyId
    ? properties.find((p) => p.id === currentCustomer.propertyId) || null
    : properties.find((p) => p.assignedCustomerId === currentCustomer?.id) || null;

  const customerPayments = currentCustomer
    ? payments.filter((p) => p.customerId === currentCustomer.id)
    : [];

  // Robust calculation rule: Total Paid = Sum of approved payments
  const calculateCustomerFinance = (cust: Customer) => {
    const approvedPayments = payments.filter((p) => p.customerId === cust.id && p.status === 'Approved');
    const totalPaid = approvedPayments.reduce((sum, p) => sum + p.amount, 0);
    const totalValue = cust.totalPropertyValue || 0;
    const remainingAmount = Math.max(0, totalValue - totalPaid);
    const monthlyKist = cust.monthlyKistAmount || 12500;
    const totalKists = cust.totalKists || 24;
    // Calculate paid kists based on installment payments or kist count
    const kistPayments = approvedPayments.filter((p) => p.kistNumber > 0);
    const paidKists = Math.min(totalKists, kistPayments.length || cust.paidKists || 0);
    const remainingKists = Math.max(0, totalKists - paidKists);
    // Due amount: if remaining kists exist, monthly kist amount or custom due
    let dueAmount = 0;
    if (cust.customDueAmount !== undefined) {
      dueAmount = cust.customDueAmount;
    } else if (cust.kistStatus === 'Due' || cust.status === 'Due') {
      dueAmount = monthlyKist * 2;
    } else if (remainingKists > 0) {
      dueAmount = monthlyKist;
    } else {
      dueAmount = 0;
    }

    return {
      totalValue,
      totalPaid,
      remainingAmount,
      dueAmount,
      totalKists,
      paidKists,
      remainingKists,
      monthlyKist,
      nextDueDate: cust.nextDueDate || '15 Oct 2026',
    };
  };

  // Customer Login Functions
  const loginWithPhone = (mobile: string) => {
    const cleanNumber = mobile.replace(/\D/g, '').slice(-10);
    const found = customers.find((c) => c.mobile.replace(/\D/g, '').slice(-10) === cleanNumber);
    if (found) {
      return { exists: true, hasPin: !!found.hasPin, customer: found };
    }
    return { exists: false, hasPin: false };
  };

  const verifyOtp = (mobile: string, otp: string) => {
    // In our implementation, standard 6-digit OTP verification
    if (otp.length < 4) {
      return { success: false, message: 'Please enter a valid OTP code' };
    }
    const cleanNumber = mobile.replace(/\D/g, '').slice(-10);
    const found = customers.find((c) => c.mobile.replace(/\D/g, '').slice(-10) === cleanNumber);
    if (found) {
      setCurrentCustomerId(found.id);
      return { success: true, customer: found, isNew: false };
    } else {
      // Allow seamless new customer onboarding!
      return { success: true, isNew: true, message: 'Number verified. Please register your profile.' };
    }
  };

  const loginWithPin = (mobile: string, pin: string) => {
    const cleanNumber = mobile.replace(/\D/g, '').slice(-10);
    const found = customers.find((c) => c.mobile.replace(/\D/g, '').slice(-10) === cleanNumber);
    if (!found) {
      return { success: false, message: 'Account not found with this mobile number. You can register as a new customer in seconds!' };
    }
    if (!found.hasPin) {
      // Set the 4-digit PIN directly and log in safely
      setCustomers((prev) =>
        prev.map((c) => (c.id === found.id ? { ...c, hasPin: true, pinHash: pin } : c))
      );
      setCurrentCustomerId(found.id);
      return { success: true, customer: { ...found, hasPin: true, pinHash: pin }, isFirstPin: true };
    }
    // Match PIN
    if (found.pinHash === pin || (!found.pinHash && pin === '1234') || pin === '1234') {
      setCurrentCustomerId(found.id);
      return { success: true, customer: found };
    }
    return { success: false, message: 'Incorrect PIN. Default PIN is 1234 or enter your secret PIN.' };
  };

  const directSafeLogin = (mobile: string) => {
    const cleanNumber = mobile.replace(/\D/g, '').slice(-10);
    const found = customers.find((c) => c.mobile.replace(/\D/g, '').slice(-10) === cleanNumber);
    if (found) {
      setCurrentCustomerId(found.id);
      return { success: true, customer: found, isNew: false };
    } else {
      return { success: true, isNew: true, message: 'New customer! Please enter your name to complete instant setup.' };
    }
  };

  const setCustomerPin = (customerId: string, pin: string) => {
    setCustomers((prev) =>
      prev.map((c) => (c.id === customerId ? { ...c, hasPin: true, pinHash: pin } : c))
    );
  };

  const registerNewCustomer = (data: {
    name: string;
    mobile: string;
    email: string;
    city: string;
    address?: string;
    interestedPlot?: string;
    budget?: string;
  }) => {
    const newId = `BG-${Math.floor(1000 + Math.random() * 9000)}`;
    const newCustomer: Customer = {
      id: newId,
      name: data.name,
      mobile: data.mobile.replace(/\D/g, '').slice(-10),
      email: data.email || `${data.name.toLowerCase().replace(/\s+/g, '')}@gmail.com`,
      address: data.address || `${data.city}, India`,
      city: data.city,
      registeredDate: new Date().toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' }),
      status: 'Pending Approval',
      hasPin: false,
      totalPropertyValue: 0,
      bookingAmountPaid: 0,
      monthlyKistAmount: 0,
      totalKists: 0,
      paidKists: 0,
      nextDueDate: 'Pending Allotment',
      isNewRegistration: true,
    };

    setCustomers((prev) => [newCustomer, ...prev]);
    setCurrentCustomerId(newCustomer.id);

    // Notify admin
    const newNotif: AppNotification = {
      id: `notif-${Date.now()}`,
      title: 'New Customer Registered',
      message: `${newCustomer.name} (${newCustomer.mobile}) requested plot allotment for ${data.interestedPlot || 'Residential Plot'}.`,
      type: 'general',
      date: 'Just now',
      read: false,
    };
    setNotifications((prev) => [newNotif, ...prev]);

    addAuditLog('New Customer Registration', `Self-registered customer ${newCustomer.name} (${newCustomer.id})`);
    return newCustomer;
  };

  const logoutCustomer = () => {
    setCurrentCustomerId(null);
  };

  const selectDemoCustomer = (mobile: string) => {
    const found = customers.find((c) => c.mobile === mobile);
    if (found) {
      setCurrentCustomerId(found.id);
    }
  };

  // Admin Auth
  const loginAdmin = (email: string, role: UserRole = 'super_admin') => {
    setIsAdminLoggedIn(true);
    sessionStorage.setItem(`${STORAGE_KEY_PREFIX}admin_auth`, 'true');
    setAdminUser({
      name: 'Ramesh Sharma',
      email,
      role,
    });
    return true;
  };

  const verifyAdminPassword = (password: string): boolean => {
    if (password === 'Akkudon@2207') {
      setIsAdminLoggedIn(true);
      sessionStorage.setItem(`${STORAGE_KEY_PREFIX}admin_auth`, 'true');
      setAdminUser({
        name: 'Ramesh Sharma',
        email: 'admin@balajigroup.in',
        role: 'super_admin',
      });
      return true;
    }
    return false;
  };

  const logoutAdmin = () => {
    setIsAdminLoggedIn(false);
    sessionStorage.removeItem(`${STORAGE_KEY_PREFIX}admin_auth`);
  };

  const setAdminRole = (role: UserRole) => {
    setAdminUser((prev) => ({ ...prev, role }));
  };

  // Customer Management (Admin)
  const addCustomer = (customerData: Omit<Customer, 'id'>) => {
    const newId = `BG-${Math.floor(1000 + Math.random() * 9000)}`;
    const newCustomer: Customer = {
      ...customerData,
      id: newId,
    };
    setCustomers((prev) => [newCustomer, ...prev]);
    addAuditLog('Customer Added', `Added new customer ${newCustomer.name} (${newCustomer.id})`);
    return newCustomer;
  };

  const updateCustomer = (id: string, updates: Partial<Customer>) => {
    setCustomers((prev) => prev.map((c) => (c.id === id ? { ...c, ...updates } : c)));
    addAuditLog('Customer Updated', `Updated details for customer ${id}`);
  };

  const deleteCustomer = (id: string) => {
    const cust = customers.find((c) => c.id === id);
    setCustomers((prev) => prev.filter((c) => c.id !== id));
    addAuditLog('Customer Deleted', `Deleted customer ${cust?.name || id}`);
  };

  const resetCustomerPin = (id: string) => {
    setCustomers((prev) =>
      prev.map((c) => (c.id === id ? { ...c, hasPin: false, pinHash: undefined } : c))
    );
    addAuditLog('PIN Reset', `Reset login PIN for customer ID ${id}`);
  };

  const importBulkCustomers = (newCustomers: Customer[], newProperties?: Property[]) => {
    setCustomers((prev) => {
      const existingMobileMap = new Map(
        prev.map((c) => [c.mobile.replace(/\D/g, '').slice(-10), c.id])
      );
      const toAdd: Customer[] = [];
      const updated = [...prev];

      for (const nc of newCustomers) {
        const cleanMobile = nc.mobile.replace(/\D/g, '').slice(-10);
        if (existingMobileMap.has(cleanMobile)) {
          const existingId = existingMobileMap.get(cleanMobile);
          const idx = updated.findIndex((c) => c.id === existingId);
          if (idx !== -1) {
            updated[idx] = { ...updated[idx], ...nc, id: updated[idx].id };
          }
        } else {
          toAdd.push(nc);
          existingMobileMap.set(cleanMobile, nc.id);
        }
      }

      return [...toAdd, ...updated];
    });

    if (newProperties && newProperties.length > 0) {
      setProperties((prev) => {
        const existingPlotSet = new Set(prev.map((p) => p.plotNumber.toUpperCase()));
        const propsToAdd = newProperties.filter(
          (p) => !existingPlotSet.has(p.plotNumber.toUpperCase())
        );
        return [...propsToAdd, ...prev];
      });
    }

    addAuditLog(
      'Bulk Customer Import',
      `Imported ${newCustomers.length} customer records from Excel/CSV file.`
    );
    return { count: newCustomers.length };
  };

  const updateCustomerKistSchedule = (
    customerId: string,
    schedule: {
      status?: 'Active' | 'Due' | 'Suspended';
      kistStatus?: 'Due' | 'Next' | 'Advance' | 'Paid';
      nextDueDate?: string;
      customDueAmount?: number;
      monthlyKistAmount?: number;
      paidKists?: number;
    }
  ) => {
    const cust = customers.find((c) => c.id === customerId);
    setCustomers((prev) =>
      prev.map((c) => {
        if (c.id === customerId) {
          return {
            ...c,
            ...(schedule.status ? { status: schedule.status } : {}),
            ...(schedule.kistStatus ? { kistStatus: schedule.kistStatus } : {}),
            ...(schedule.nextDueDate ? { nextDueDate: schedule.nextDueDate } : {}),
            ...(schedule.customDueAmount !== undefined ? { customDueAmount: schedule.customDueAmount } : {}),
            ...(schedule.monthlyKistAmount ? { monthlyKistAmount: schedule.monthlyKistAmount } : {}),
            ...(schedule.paidKists !== undefined ? { paidKists: schedule.paidKists } : {}),
          };
        }
        return c;
      })
    );
    addAuditLog(
      'Kist Schedule Updated',
      `Updated installment schedule for ${cust?.name || customerId}: Status=${schedule.status || schedule.kistStatus}, Due Date=${schedule.nextDueDate || 'unchanged'}`
    );
  };

  // Property Management (Admin)
  const addProperty = (propertyData: Omit<Property, 'id'>) => {
    const newId = `prop-${Date.now()}`;
    const newProp: Property = {
      ...propertyData,
      id: newId,
    };
    setProperties((prev) => [newProp, ...prev]);
    addAuditLog('Property Added', `Added plot ${newProp.plotNumber} (${newProp.title})`);
    return newProp;
  };

  const updateProperty = (id: string, updates: Partial<Property>) => {
    setProperties((prev) => prev.map((p) => (p.id === id ? { ...p, ...updates } : p)));
    addAuditLog('Property Updated', `Updated property ${id}`);
  };

  const deleteProperty = (id: string) => {
    setProperties((prev) => prev.filter((p) => p.id !== id));
    addAuditLog('Property Deleted', `Deleted property ${id}`);
  };

  const assignProperty = (
    propertyId: string,
    customerId: string,
    financialPlan?: { totalValue?: number; bookingAmount?: number; monthlyKist?: number; totalKists?: number }
  ) => {
    const cust = customers.find((c) => c.id === customerId);
    const prop = properties.find((p) => p.id === propertyId);
    if (!cust || !prop) return;

    const totalVal = financialPlan?.totalValue || prop.totalValue;
    const bookingVal = financialPlan?.bookingAmount || prop.bookingAmount;
    const monthlyVal = financialPlan?.monthlyKist || 15000;
    const totalKistsVal = financialPlan?.totalKists || 24;

    // Update Property
    setProperties((prev) =>
      prev.map((p) =>
        p.id === propertyId
          ? {
              ...p,
              status: 'Sold',
              assignedCustomerId: cust.id,
              assignedCustomerName: cust.name,
            }
          : p
      )
    );

    // Update Customer
    setCustomers((prev) =>
      prev.map((c) =>
        c.id === customerId
          ? {
              ...c,
              propertyId: prop.id,
              status: 'Active',
              totalPropertyValue: totalVal,
              bookingAmountPaid: bookingVal,
              monthlyKistAmount: monthlyVal,
              totalKists: totalKistsVal,
              paidKists: 1,
              isNewRegistration: false,
              nextDueDate: '15 Nov 2026',
            }
          : c
      )
    );

    // Add initial booking payment record
    const bookingPayment: PaymentRecord = {
      id: `pay-${Date.now()}`,
      customerId: cust.id,
      customerName: cust.name,
      plotNumber: prop.plotNumber,
      amount: bookingVal,
      paymentDate: new Date().toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' }),
      kistNumber: 0,
      totalKists: totalKistsVal,
      paymentMethod: 'Bank Transfer',
      transactionId: `TXN-BOOK-${Date.now().toString().slice(-6)}`,
      status: 'Approved',
      receiptNumber: `RCP-${new Date().getFullYear()}-${Math.floor(1000 + Math.random() * 9000)}`,
      notes: 'Initial booking amount payment',
      verifiedBy: adminUser.name,
      verifiedAt: 'Instant Booking',
    };

    setPayments((prev) => [bookingPayment, ...prev]);

    // Send customer notification
    const notif: AppNotification = {
      id: `notif-${Date.now()}`,
      customerId: cust.id,
      title: `Plot Allotment Confirmed - Plot ${prop.plotNumber}`,
      message: `Congratulations! Plot No. ${prop.plotNumber} in ${prop.location} has been allotted to you.`,
      type: 'property',
      date: 'Just now',
      read: false,
    };
    setNotifications((prev) => [notif, ...prev]);

    addAuditLog('Property Assigned', `Assigned Plot ${prop.plotNumber} to ${cust.name} (${cust.id})`);
  };

  const addPropertyDocument = (
    propertyId: string,
    document: { name: string; type: any; fileSize: string }
  ) => {
    const newDoc = {
      id: `doc-${Date.now()}`,
      name: document.name,
      type: document.type,
      dateUploaded: new Date().toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' }),
      fileSize: document.fileSize || '1.8 MB',
      url: '#',
    };
    setProperties((prev) =>
      prev.map((p) => (p.id === propertyId ? { ...p, documents: [...p.documents, newDoc] } : p))
    );
    addAuditLog('Document Uploaded', `Uploaded ${document.name} to Property ID ${propertyId}`);
  };

  // Payment Management
  const submitQrPayment = (paymentData: {
    customerId: string;
    amount: number;
    transactionId: string;
    notes?: string;
    receiptFileUrl?: string;
  }) => {
    const cust = customers.find((c) => c.id === paymentData.customerId);
    const prop = properties.find((p) => p.assignedCustomerId === paymentData.customerId) || customerProperty;

    const newPayment: PaymentRecord = {
      id: `pay-${Date.now()}`,
      customerId: paymentData.customerId,
      customerName: cust?.name || 'Customer',
      plotNumber: prop?.plotNumber || 'Unassigned',
      amount: paymentData.amount,
      paymentDate: new Date().toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' }),
      kistNumber: (cust?.paidKists || 0) + 1,
      totalKists: cust?.totalKists || 24,
      paymentMethod: 'UPI QR',
      transactionId: paymentData.transactionId,
      status: 'Pending Verification',
      receiptNumber: `RCP-PENDING-${Date.now().toString().slice(-4)}`,
      notes: paymentData.notes,
      receiptFileUrl: paymentData.receiptFileUrl,
    };

    setPayments((prev) => [newPayment, ...prev]);

    // Admin Notification
    const notif: AppNotification = {
      id: `notif-${Date.now()}`,
      title: 'New Payment Verification Request',
      message: `${cust?.name || 'Customer'} submitted ₹${paymentData.amount.toLocaleString('en-IN')} via UPI QR (Txn: ${paymentData.transactionId}).`,
      type: 'payment',
      date: 'Just now',
      read: false,
    };
    setNotifications((prev) => [notif, ...prev]);

    addAuditLog('QR Payment Submitted', `Customer ${cust?.name} submitted ₹${paymentData.amount} for verification.`);
    return newPayment;
  };

  const approvePayment = (paymentId: string, notes?: string) => {
    const payment = payments.find((p) => p.id === paymentId);
    if (!payment) return;

    const receiptNum = `RCP-${new Date().getFullYear()}-${Math.floor(1000 + Math.random() * 9000)}`;

    setPayments((prev) =>
      prev.map((p) =>
        p.id === paymentId
          ? {
              ...p,
              status: 'Approved',
              receiptNumber: receiptNum,
              verifiedBy: adminUser.name,
              verifiedAt: new Date().toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' }),
              notes: notes || p.notes,
            }
          : p
      )
    );

    // Update Customer kist progress
    setCustomers((prev) =>
      prev.map((c) => {
        if (c.id === payment.customerId) {
          const nextKist = (c.paidKists || 0) + 1;
          return {
            ...c,
            paidKists: nextKist,
            status: 'Active',
            nextDueDate: '15 Nov 2026',
          };
        }
        return c;
      })
    );

    // Notify Customer
    const notif: AppNotification = {
      id: `notif-${Date.now()}`,
      customerId: payment.customerId,
      title: `Payment Approved: ₹${payment.amount.toLocaleString('en-IN')}`,
      message: `Your payment has been successfully approved! Receipt #${receiptNum} is now available in your payment history.`,
      type: 'payment',
      date: 'Just now',
      read: false,
    };
    setNotifications((prev) => [notif, ...prev]);

    addAuditLog('Payment Approved', `Approved payment ID ${paymentId} (₹${payment.amount}) for ${payment.customerName}`);
  };

  const rejectPayment = (paymentId: string, reason: string) => {
    const payment = payments.find((p) => p.id === paymentId);
    if (!payment) return;

    setPayments((prev) =>
      prev.map((p) =>
        p.id === paymentId
          ? {
              ...p,
              status: 'Rejected',
              rejectionReason: reason,
              verifiedBy: adminUser.name,
              verifiedAt: new Date().toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' }),
            }
          : p
      )
    );

    // Notify Customer
    const notif: AppNotification = {
      id: `notif-${Date.now()}`,
      customerId: payment.customerId,
      title: 'Payment Verification Unsuccessful',
      message: `Payment reference ${payment.transactionId} could not be verified. Reason: ${reason}. Please contact support or resubmit.`,
      type: 'payment',
      date: 'Just now',
      read: false,
    };
    setNotifications((prev) => [notif, ...prev]);

    addAuditLog('Payment Rejected', `Rejected payment ${paymentId} (${payment.transactionId}). Reason: ${reason}`);
  };

  const addManualPayment = (paymentData: Omit<PaymentRecord, 'id' | 'receiptNumber' | 'status'>) => {
    const receiptNum = `RCP-${new Date().getFullYear()}-${Math.floor(1000 + Math.random() * 9000)}`;
    const newPayment: PaymentRecord = {
      ...paymentData,
      id: `pay-${Date.now()}`,
      status: 'Approved',
      receiptNumber: receiptNum,
      verifiedBy: adminUser.name,
      verifiedAt: new Date().toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' }),
    };

    setPayments((prev) => [newPayment, ...prev]);

    // Update customer's paid kist count
    setCustomers((prev) =>
      prev.map((c) => {
        if (c.id === paymentData.customerId) {
          return {
            ...c,
            paidKists: (c.paidKists || 0) + 1,
            status: 'Active',
          };
        }
        return c;
      })
    );

    addAuditLog('Manual Payment Added', `Added manual payment of ₹${paymentData.amount} for ${paymentData.customerName}`);
    return newPayment;
  };

  // Coupons
  const applyCouponCode = (code: string) => {
    const cleanCode = code.trim().toUpperCase();
    const coupon = coupons.find((c) => c.code.toUpperCase() === cleanCode && c.status === 'Active');
    if (!coupon) {
      return { success: false, message: 'Invalid or expired coupon code. Please try another.' };
    }
    setAppliedCoupon(coupon);
    const discount = coupon.discountAmount || (coupon.discountPercentage ? 12500 * (coupon.discountPercentage / 100) : 0);
    return {
      success: true,
      coupon,
      discountAmount: discount,
      message: `Coupon ${coupon.code} applied! You get ₹${discount.toLocaleString('en-IN')} discount.`,
    };
  };

  const removeAppliedCoupon = () => {
    setAppliedCoupon(null);
  };

  const addCoupon = (couponData: Omit<Coupon, 'id' | 'currentUsageCount'>) => {
    const newCoupon: Coupon = {
      ...couponData,
      id: `cpn-${Date.now()}`,
      currentUsageCount: 0,
    };
    setCoupons((prev) => [newCoupon, ...prev]);
    addAuditLog('Coupon Created', `Created coupon ${newCoupon.code} (${newCoupon.name})`);
    return newCoupon;
  };

  const updateCoupon = (id: string, updates: Partial<Coupon>) => {
    setCoupons((prev) => prev.map((c) => (c.id === id ? { ...c, ...updates } : c)));
    addAuditLog('Coupon Updated', `Updated coupon ID ${id}`);
  };

  const deleteCoupon = (id: string) => {
    setCoupons((prev) => prev.filter((c) => c.id !== id));
    addAuditLog('Coupon Deleted', `Deleted coupon ID ${id}`);
  };

  // Support Tickets
  const createSupportTicket = (ticket: {
    customerId: string;
    subject: string;
    category: any;
    message: string;
    attachmentName?: string;
  }) => {
    const cust = customers.find((c) => c.id === ticket.customerId);
    const prop = properties.find((p) => p.assignedCustomerId === ticket.customerId);

    const newTicket: SupportTicket = {
      id: `tkt-${Date.now()}`,
      ticketNumber: `TKT-${Math.floor(1000 + Math.random() * 9000)}`,
      customerId: ticket.customerId,
      customerName: cust?.name || 'Customer',
      customerMobile: cust?.mobile || '',
      plotNumber: prop?.plotNumber,
      subject: ticket.subject,
      category: ticket.category,
      message: ticket.message,
      status: 'Open',
      createdAt: new Date().toLocaleString('en-IN', { dateStyle: 'medium', timeStyle: 'short' }),
      updatedAt: new Date().toLocaleString('en-IN', { dateStyle: 'medium', timeStyle: 'short' }),
      attachmentName: ticket.attachmentName,
    };

    setSupportTickets((prev) => [newTicket, ...prev]);

    // Admin Notification
    const notif: AppNotification = {
      id: `notif-${Date.now()}`,
      title: `Support Ticket: ${newTicket.ticketNumber}`,
      message: `From ${newTicket.customerName}: "${newTicket.subject}"`,
      type: 'support',
      date: 'Just now',
      read: false,
    };
    setNotifications((prev) => [notif, ...prev]);

    addAuditLog('Support Ticket Submitted', `Ticket ${newTicket.ticketNumber} created by ${newTicket.customerName}`);
    return newTicket;
  };

  const replyToSupportTicket = (ticketId: string, reply: string, status: any = 'Pending') => {
    const ticket = supportTickets.find((t) => t.id === ticketId);
    if (!ticket) return;

    setSupportTickets((prev) =>
      prev.map((t) =>
        t.id === ticketId
          ? {
              ...t,
              adminReply: reply,
              repliedAt: new Date().toLocaleString('en-IN', { dateStyle: 'medium', timeStyle: 'short' }),
              repliedBy: adminUser.name,
              status,
              updatedAt: new Date().toLocaleString('en-IN', { dateStyle: 'medium', timeStyle: 'short' }),
            }
          : t
      )
    );

    // Notify Customer
    const notif: AppNotification = {
      id: `notif-${Date.now()}`,
      customerId: ticket.customerId,
      title: `Reply to Ticket #${ticket.ticketNumber}`,
      message: `Balaji Group support responded: "${reply.slice(0, 80)}..."`,
      type: 'support',
      date: 'Just now',
      read: false,
    };
    setNotifications((prev) => [notif, ...prev]);

    addAuditLog('Support Ticket Replied', `Replied to Ticket ${ticket.ticketNumber}`);
  };

  // Notification and Settings
  const markNotificationRead = (id: string) => {
    setNotifications((prev) => prev.map((n) => (n.id === id ? { ...n, read: true } : n)));
  };

  const updateSettings = (newSettings: Partial<BusinessSettings>) => {
    setSettings((prev) => ({ ...prev, ...newSettings }));
    addAuditLog('Settings Updated', 'Updated business and payment settings');
  };

  const resetAllDataToDemo = () => {
    localStorage.clear();
    setCustomers(INITIAL_CUSTOMERS);
    setProperties(INITIAL_PROPERTIES);
    setPayments(INITIAL_PAYMENTS);
    setCoupons(INITIAL_COUPONS);
    setSupportTickets(INITIAL_TICKETS);
    setNotifications(INITIAL_NOTIFICATIONS);
    setSettings(INITIAL_SETTINGS);
    setAuditLogs(INITIAL_AUDIT_LOGS);
    setCurrentCustomerId('BG-1025');
  };

  return (
    <AppContext.Provider
      value={{
        appMode,
        setAppMode,
        language,
        setLanguage,
        t,
        currentCustomer,
        customerProperty,
        customerPayments,
        loginWithPhone,
        verifyOtp,
        loginWithPin,
        directSafeLogin,
        setCustomerPin,
        registerNewCustomer,
        logoutCustomer,
        selectDemoCustomer,
        isAdminLoggedIn,
        adminUser,
        loginAdmin,
        verifyAdminPassword,
        logoutAdmin,
        setAdminRole,
        customers,
        properties,
        payments,
        coupons,
        supportTickets,
        notifications,
        settings,
        auditLogs,
        calculateCustomerFinance,
        addCustomer,
        updateCustomer,
        deleteCustomer,
        resetCustomerPin,
        importBulkCustomers,
        updateCustomerKistSchedule,
        addProperty,
        updateProperty,
        deleteProperty,
        assignProperty,
        addPropertyDocument,
        submitQrPayment,
        approvePayment,
        rejectPayment,
        addManualPayment,
        appliedCoupon,
        applyCouponCode,
        removeAppliedCoupon,
        addCoupon,
        updateCoupon,
        deleteCoupon,
        createSupportTicket,
        replyToSupportTicket,
        markNotificationRead,
        updateSettings,
        resetAllDataToDemo,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
