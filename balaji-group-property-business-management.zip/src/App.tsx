import React, { useState } from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { SplashScreen } from './components/customer/SplashScreen';
import { CustomerAuth } from './components/customer/CustomerAuth';
import { CustomerHeader } from './components/common/CustomerHeader';
import { CustomerBottomNav } from './components/customer/CustomerBottomNav';
import { CustomerHome } from './components/customer/CustomerHome';
import { CustomerProperty } from './components/customer/CustomerProperty';
import { CustomerPayments } from './components/customer/CustomerPayments';
import { CustomerCoupons } from './components/customer/CustomerCoupons';
import { CustomerHelp } from './components/customer/CustomerHelp';
import { CustomerSettings } from './components/customer/CustomerSettings';
import { AdminLayout } from './components/admin/AdminLayout';
import { OfflineIndicator } from './components/common/OfflineIndicator';
import { PWAInstallButton } from './components/common/PWAInstallButton';
import { Shield, Smartphone, Lock, Eye, EyeOff, AlertCircle, ArrowRight } from 'lucide-react';

const AppContent: React.FC = () => {
  const { appMode, setAppMode, currentCustomer, isAdminLoggedIn, verifyAdminPassword } = useApp();
  const [customerScreen, setCustomerScreen] = useState<'splash' | 'auth' | 'app'>('splash');
  const [activeCustomerTab, setActiveCustomerTab] = useState<string>('home');
  const [adminPassInput, setAdminPassInput] = useState<string>('');
  const [adminPassError, setAdminPassError] = useState<string>('');
  const [showAdminPass, setShowAdminPass] = useState<boolean>(false);

  // If customer is not logged in, show splash or auth
  if (appMode === 'customer' && !currentCustomer) {
    if (customerScreen === 'splash') {
      return <SplashScreen onStart={() => setCustomerScreen('auth')} />;
    }
    return (
      <CustomerAuth
        onSuccess={() => setCustomerScreen('app')}
        onBackToSplash={() => setCustomerScreen('splash')}
      />
    );
  }

  // Admin Portal Mode
  if (appMode === 'admin') {
    if (!isAdminLoggedIn) {
      return (
        <div className="min-h-screen bg-slate-900 flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-sm rounded-3xl p-6 shadow-2xl text-center">
            <div className="w-12 h-12 rounded-2xl bg-orange-600 text-white flex items-center justify-center mx-auto mb-3">
              <Lock className="w-6 h-6" />
            </div>
            <h3 className="font-bold text-lg text-slate-900 mb-1">Administrative Access</h3>
            <p className="text-xs text-slate-500 mb-4">Please enter security access password</p>

            {adminPassError && (
              <div className="mb-4 p-3 bg-rose-50 border border-rose-200 rounded-xl text-xs text-rose-700 flex items-center gap-2 text-left">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{adminPassError}</span>
              </div>
            )}

            <form
              onSubmit={(e) => {
                e.preventDefault();
                const isValid = verifyAdminPassword(adminPassInput.trim());
                if (isValid) {
                  setAdminPassError('');
                  setAdminPassInput('');
                } else {
                  setAdminPassError('Incorrect password. Access denied.');
                }
              }}
              className="space-y-4"
            >
              <div className="relative flex items-center">
                <Lock className="w-4 h-4 text-slate-400 absolute left-3.5" />
                <input
                  type={showAdminPass ? 'text' : 'password'}
                  placeholder="Enter password"
                  value={adminPassInput}
                  onChange={(e) => {
                    setAdminPassInput(e.target.value);
                    setAdminPassError('');
                  }}
                  autoFocus
                  required
                  className="w-full pl-10 pr-10 py-3 bg-slate-50 border border-slate-300 rounded-xl text-xs font-mono text-slate-900 focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-orange-500"
                />
                <button
                  type="button"
                  onClick={() => setShowAdminPass(!showAdminPass)}
                  className="absolute right-3.5 text-slate-400 hover:text-slate-600 cursor-pointer"
                >
                  {showAdminPass ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>

              <button
                type="submit"
                className="w-full py-3 bg-orange-600 hover:bg-orange-700 text-white font-bold rounded-xl text-xs transition-colors flex items-center justify-center gap-1.5 shadow-md shadow-orange-600/20 cursor-pointer"
              >
                <span>Verify & Access</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </form>

            <button
              onClick={() => {
                setAdminPassError('');
                setAdminPassInput('');
                setAppMode('customer');
              }}
              className="w-full mt-3 py-2 text-xs text-slate-500 hover:text-slate-800 cursor-pointer"
            >
              Return to Customer App
            </button>
          </div>
        </div>
      );
    }
    return <AdminLayout />;
  }

  // Customer Portal Mode (Logged in)
  const renderCustomerTab = () => {
    switch (activeCustomerTab) {
      case 'home':
        return <CustomerHome onNavigateTab={setActiveCustomerTab} />;
      case 'property':
        return <CustomerProperty />;
      case 'payments':
        return <CustomerPayments />;
      case 'coupons':
        return <CustomerCoupons onNavigateTab={setActiveCustomerTab} />;
      case 'help':
        return <CustomerHelp />;
      case 'settings':
        return <CustomerSettings onNavigateTab={setActiveCustomerTab} />;
      default:
        return <CustomerHome onNavigateTab={setActiveCustomerTab} />;
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 flex flex-col antialiased">
      {/* Top Customer Header */}
      <CustomerHeader onNavigateTab={setActiveCustomerTab} />

      {/* Main Customer Viewport */}
      <main className="flex-1 max-w-md w-full mx-auto px-4 pt-4 pb-20 sm:pb-24">
        {renderCustomerTab()}
      </main>

      {/* Bottom Navigation */}
      <CustomerBottomNav
        activeTab={activeCustomerTab}
        onTabChange={setActiveCustomerTab}
      />

      {/* PWA Floating Install & Offline Status */}
      <OfflineIndicator />
      <PWAInstallButton variant="floating" />
    </div>
  );
};

export default function App() {
  return (
    <AppProvider>
      <AppContent />
    </AppProvider>
  );
}
