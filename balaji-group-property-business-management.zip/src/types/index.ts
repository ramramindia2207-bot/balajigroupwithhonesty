export type UserRole = 'super_admin' | 'admin' | 'staff' | 'customer';

export type PropertyType = 'Residential Plot' | 'Commercial Plot' | 'Farmhouse' | 'Villa Plot';
export type PropertyStatus = 'Available' | 'Booked' | 'Sold' | 'Registered' | 'Cancelled';
export type PaymentStatus = 'Approved' | 'Pending Verification' | 'Rejected';
export type PaymentMethod = 'UPI QR' | 'Direct Gateway' | 'Bank Transfer' | 'Cheque' | 'Cash';
export type TicketStatus = 'Open' | 'Pending' | 'Resolved';
export type Language = 'en' | 'hi';

export interface PropertyDocument {
  id: string;
  name: string;
  type: 'Registry Copy' | 'Allotment Letter' | 'Payment Receipt' | 'Possession Deed' | 'Site Plan' | 'Agreement';
  dateUploaded: string;
  fileSize: string;
  url: string;
}

export interface Property {
  id: string;
  plotNumber: string;
  title: string;
  location: string;
  propertyType: PropertyType;
  propertySize: string; // e.g. "1000 Sq. Ft."
  dimensions: string; // e.g. "25 x 40 Ft."
  totalValue: number;
  bookingAmount: number;
  bookingDate: string;
  registrationDate: string;
  registryNumber: string;
  status: PropertyStatus;
  imageUrl: string;
  assignedCustomerId?: string;
  assignedCustomerName?: string;
  documents: PropertyDocument[];
  features?: string[];
}

export interface PaymentRecord {
  id: string;
  customerId: string;
  customerName: string;
  plotNumber: string;
  amount: number;
  paymentDate: string;
  kistNumber: number; // e.g. 1, 2, 3...
  totalKists: number;
  paymentMethod: PaymentMethod;
  transactionId: string;
  status: PaymentStatus;
  receiptNumber: string;
  rejectionReason?: string;
  receiptFileUrl?: string;
  verifiedBy?: string;
  verifiedAt?: string;
  notes?: string;
}

export interface Customer {
  id: string; // e.g. "BG-1025"
  name: string;
  mobile: string;
  email: string;
  address: string;
  city: string;
  registeredDate: string;
  status: 'Active' | 'Due' | 'Suspended' | 'Pending Approval';
  hasPin: boolean;
  pinHash?: string; // Simulated secure hashed PIN
  propertyId?: string;
  // Financial calculation fields
  totalPropertyValue: number;
  bookingAmountPaid: number;
  monthlyKistAmount: number;
  totalKists: number;
  paidKists: number;
  nextDueDate: string;
  isNewRegistration?: boolean;
  customDueAmount?: number; // Admin override for exact due amount
  kistStatus?: 'Due' | 'Next' | 'Advance' | 'Paid'; // Admin power to set whether kist is Due or Next
}

export interface Coupon {
  id: string;
  code: string;
  name: string;
  category: 'Special' | 'Festive' | 'Referral' | 'General';
  discountAmount?: number; // Flat discount
  discountPercentage?: number; // Percentage discount
  validFrom: string;
  validUntil: string;
  conditions: string;
  status: 'Active' | 'Inactive' | 'Expired';
  maxUsageLimit: number;
  currentUsageCount: number;
  assignedCustomerIds?: string[]; // If empty, open to all
}

export interface SupportTicket {
  id: string;
  ticketNumber: string; // e.g. "TKT-8492"
  customerId: string;
  customerName: string;
  customerMobile: string;
  plotNumber?: string;
  subject: string;
  category: 'Payment Issue' | 'Registry & Documents' | 'Plot Visit' | 'Kist Inquiry' | 'General';
  message: string;
  status: TicketStatus;
  createdAt: string;
  updatedAt: string;
  attachmentName?: string;
  adminReply?: string;
  repliedAt?: string;
  repliedBy?: string;
}

export interface AppNotification {
  id: string;
  customerId?: string; // If undefined, broadcast to all
  title: string;
  message: string;
  type: 'payment' | 'due' | 'coupon' | 'property' | 'support' | 'general';
  date: string;
  read: boolean;
  actionUrl?: string;
}

export type SmsProvider = 'demo' | 'fast2sms' | '2factor' | 'textlocal' | 'msg91' | 'twilio' | 'whatsapp_cloud_api' | 'custom_webhook';

export interface SmsGatewayConfig {
  provider: SmsProvider;
  enabled: boolean; // whether real SMS delivery is active
  apiKey?: string;
  senderId?: string;
  templateId?: string;
  webhookUrl?: string;
  twilioAccountSid?: string;
  twilioAuthToken?: string;
  twilioPhoneNumber?: string;
  whatsappPhoneNumberId?: string;
  whatsappAccessToken?: string;
  whatsappBusinessAccountId?: string;
  whatsappTemplateName?: string;
}

export interface BusinessSettings {
  businessName: string;
  tagline: string;
  logoUrl?: string;
  address: string;
  phone: string;
  email: string;
  whatsapp: string;
  officeHours: string;
  upiId: string;
  qrCodeUrl: string;
  qrPaymentEnabled: boolean;
  paymentInstructions: string;
  enableOtpLogin: boolean;
  enablePasswordLogin: boolean;
  otpExpiryMinutes: number;
  requirePinSetup: boolean;
  enableHindi: boolean;
  defaultLanguage: Language;
  smsGateway?: SmsGatewayConfig;
}

export interface AuditLog {
  id: string;
  action: string;
  user: string;
  role: string;
  timestamp: string;
  details: string;
}
